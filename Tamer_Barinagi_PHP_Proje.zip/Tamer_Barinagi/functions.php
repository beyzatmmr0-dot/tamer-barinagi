<?php
/*
 * functions.php
 * Projenin bütün ortak fonksiyonları bu dosyada bulunur.
 * Diğer sayfalar (index.php, ekle.php, sil.php) bu dosyayı require_once ile çağırır.
 */

// Oturumu başlatıyoruz. $_SESSION sayesinde kayıtlar sayfa yenilendiğinde kaybolmaz.
// Çerez ömrü 30 gün: tarayıcı kapatılsa bile kayıtlar oturumda kalır.
session_set_cookie_params(['lifetime' => 60 * 60 * 24 * 30, 'path' => '/', 'samesite' => 'Lax']);
ini_set('session.gc_maxlifetime', (string) (60 * 60 * 24 * 30));
session_start();

// Formda ve filtrede kullanılan sabit seçenekler (dizi olarak tutuluyor)
$TURLER     = ['Kedi', 'Köpek', 'Kuş', 'Tavşan', 'Balık', 'Hamster', 'Kaplumbağa', 'Gine domuzu', 'Kirpi', 'Şinşilla', 'Ferret', 'Diğer'];
$DURUMLAR   = ['Yuva arıyor', 'Görüşülüyor', 'Sahiplendirildi'];
$CINSIYETLER = ['Dişi', 'Erkek'];
$ASI_DURUMLARI = ['Aşıları tam', 'Kısmen aşılı', 'Aşısız', 'Aşı gerekmiyor'];

/*
 * Türe göre yapılması gereken aşılar: anahtar => ekranda görünen ad.
 * Hayvanın aşı durumu ("Aşıları tam" vb.) artık elle seçilmiyor,
 * bu listeye göre PHP tarafından hesaplanıyor (asiDurumu fonksiyonu).
 * Listede olmayan türler (Kuş, Diğer) için "Aşı gerekmiyor" yazılır.
 */
$ASI_LISTESI = [
    'Kedi'   => ['kedi_karma' => 'Karma aşı (FVRCP)', 'kedi_kuduz' => 'Kuduz aşısı', 'kedi_losemi' => 'Lösemi aşısı (FeLV)'],
    'Köpek'  => ['kopek_karma' => 'Karma aşı (DHPP)', 'kopek_kuduz' => 'Kuduz aşısı', 'kopek_bronsit' => 'Bronşit aşısı (KC)'],
    'Tavşan' => ['tavsan_miksomatozis' => 'Miksomatozis aşısı', 'tavsan_rhd' => 'RHD aşısı'],
];
const ASI_ARALIGI = 365; // aşıların tekrarı (rapel) yılda bir hatırlatılır

// Görüşme sonuçları ve sahiplenme sonrası durum
$GORUSME_SONUCLARI = ['Olumlu', 'Düşünüyor', 'Olumsuz'];

/*
 * Hayvan fotoğrafları (assets/img/foto/ klasöründe).
 * Hepsi Unsplash'ten alındı. Unsplash lisansı fotoğrafların ücretsiz kullanılmasına izin verir
 * (https://unsplash.com/license). Saygı gereği fotoğrafçının adı ve fotoğraf sayfası da tutulur.
 * Anahtar = dosya adı (uzantısız). 'tur' fotoğraftaki hayvanın türüdür.
 */
$FOTO_KAYNAKLARI = [
    'pamuk'   => ['tur' => 'Kedi',   'etiket' => 'Beyaz kedi',          'fotografci' => 'AcidFern',                     'sayfa' => 'https://unsplash.com/photos/white-cat-in-close-up-photography-5AmkWHXlkO0'],
    'duman'   => ['tur' => 'Kedi',   'etiket' => 'Gri kedi',            'fotografci' => 'Milada Vigerova',              'sayfa' => 'https://unsplash.com/photos/russian-blue-cat-on-white-floor-0TPAlZ87mzk'],
    'boncuk'  => ['tur' => 'Kedi',   'etiket' => 'Üç renkli kedi',      'fotografci' => 'Tim van der Kuip',             'sayfa' => 'https://unsplash.com/photos/calico-cat-on-gray-textile-mdRJhxlsuGM'],
    'karabas' => ['tur' => 'Köpek',  'etiket' => 'Golden köpek',        'fotografci' => 'Samantha Fortney',             'sayfa' => 'https://unsplash.com/photos/a-golden-retriever-dog-lies-on-a-brick-patio-IdYm0gyohkw'],
    'zeytin'  => ['tur' => 'Köpek',  'etiket' => 'Yavru köpek',         'fotografci' => 'mtsjrdl',                      'sayfa' => 'https://unsplash.com/photos/white-and-brown-long-coated-dog-5yAhL8ViUVg'],
    'pasa'    => ['tur' => 'Köpek',  'etiket' => 'Yaşlı, sakin köpek',  'fotografci' => 'Linoleum Creative Collective', 'sayfa' => 'https://unsplash.com/photos/brown-and-white-long-coated-dog-lying-on-floor-ZQu-3viOINA'],
    'mavis'   => ['tur' => 'Kuş',    'etiket' => 'Muhabbet kuşu',       'fotografci' => 'Tawhid Khan',                  'sayfa' => 'https://unsplash.com/photos/white-yellow-and-blue-bird-5f8uEucFP6w'],
    'findik'  => ['tur' => 'Tavşan', 'etiket' => 'Kahverengi tavşan',   'fotografci' => 'Waranya Mooldee',              'sayfa' => 'https://unsplash.com/photos/brown-rabbit-Efj0HGPdPKs'],
    'tosbik'  => ['tur' => 'Kaplumbağa',  'etiket' => 'Kaplumbağa',          'fotografci' => 'Wexor Tmg',                    'sayfa' => 'https://unsplash.com/photos/brown-turtle-swimming-underwater-L-2p8fapOA8'],
    'mirmir'  => ['tur' => 'Kedi', 'etiket' => 'Gri tekir yavru', 'fotografci' => 'Loan', 'sayfa' => 'https://unsplash.com/photos/7AIDE8PrvA0'],
    'tarcin'  => ['tur' => 'Kedi', 'etiket' => 'Turuncu-beyaz kedi', 'fotografci' => 'Amber Kipp', 'sayfa' => 'https://unsplash.com/photos/75715CVEJhI'],
    'limon'   => ['tur' => 'Kedi', 'etiket' => 'Uzun tüylü kedi', 'fotografci' => 'Alvan Nee', 'sayfa' => 'https://unsplash.com/photos/ZCHj_2lJP00'],
    'comar'   => ['tur' => 'Köpek', 'etiket' => 'Siyah-beyaz köpek', 'fotografci' => 'Victor G', 'sayfa' => 'https://unsplash.com/photos/N04FIfHhv_k'],
    'fistik'  => ['tur' => 'Köpek', 'etiket' => 'Golden yavru', 'fotografci' => 'Florian Schindler', 'sayfa' => 'https://unsplash.com/photos/2LHLhMLqeIQ'],
    'max'     => ['tur' => 'Köpek', 'etiket' => 'Siyah-beyaz tüylü köpek', 'fotografci' => 'Baptist Standaert', 'sayfa' => 'https://unsplash.com/photos/mx0DEnfYxic'],
    'lokum'   => ['tur' => 'Köpek', 'etiket' => 'Kahverengi-beyaz yavru', 'fotografci' => 'Alvan Nee', 'sayfa' => 'https://unsplash.com/photos/eoqnr8ikwFE'],
    'pirpir'  => ['tur' => 'Kuş', 'etiket' => 'Sarı kanarya', 'fotografci' => 'Ray Hennessy', 'sayfa' => 'https://unsplash.com/photos/MH_psben7HE'],
    'civil'   => ['tur' => 'Kuş', 'etiket' => 'Sarı papağan', 'fotografci' => 'FloatFlower Huang', 'sayfa' => 'https://unsplash.com/photos/6GHL995JYNU'],
    'pofuduk' => ['tur' => 'Tavşan', 'etiket' => 'Gri tavşan', 'fotografci' => 'Janan', 'sayfa' => 'https://unsplash.com/photos/302xfiIGOfE'],
    'bulut'   => ['tur' => 'Tavşan', 'etiket' => 'Beyaz tavşan', 'fotografci' => 'Satyabratasm', 'sayfa' => 'https://unsplash.com/photos/u_kMWN-BWyU'],
    'gidik'   => ['tur' => 'Hamster', 'etiket' => 'Hamster', 'fotografci' => 'Ricky Kharawala', 'sayfa' => 'https://unsplash.com/photos/adK3Vu70DEQ'],
    'kirpi'   => ['tur' => 'Kirpi', 'etiket' => 'Beyaz kirpi', 'fotografci' => 'Sierra NiCole Narvaeth', 'sayfa' => 'https://unsplash.com/photos/D09Nooc3XQw'],
    'zipzip'  => ['tur' => 'Gine domuzu', 'etiket' => 'Gine domuzu', 'fotografci' => 'Jaroslaw Slodkiewicz', 'sayfa' => 'https://unsplash.com/photos/SDIIfq6nhFU'],
    'pamuk2'  => ['tur' => 'Kedi', 'etiket' => 'Beyaz yavru kedi', 'fotografci' => 'hang niu', 'sayfa' => 'https://unsplash.com/photos/Tn8DLxwuDMA'],    'lord'     => ['tur' => 'Kedi', 'etiket' => 'British Shorthair yavru', 'fotografci' => 'Sergey Semin', 'sayfa' => 'https://unsplash.com/photos/ff6MD1lIMaQ'],
    'prenses'  => ['tur' => 'Kedi', 'etiket' => 'British Shorthair yavru (kahverengi)', 'fotografci' => 'Sergey Semin', 'sayfa' => 'https://unsplash.com/photos/Y0WXj3xqJz0'],
    'baypasa'  => ['tur' => 'Kedi', 'etiket' => 'British Shorthair (gri)', 'fotografci' => 'Lukáš Parničan', 'sayfa' => 'https://unsplash.com/photos/XnIi9M6__is'],
    'karamel'  => ['tur' => 'Kedi', 'etiket' => 'British Shorthair (mavi-gri)', 'fotografci' => 'Lukáš Parničan', 'sayfa' => 'https://unsplash.com/photos/WI5OBsJoXEc'],
    'sutlac'   => ['tur' => 'Kedi', 'etiket' => 'Scottish Fold', 'fotografci' => 'ello', 'sayfa' => 'https://unsplash.com/photos/--jx3LMBlWY'],
    'aslan'    => ['tur' => 'Kedi', 'etiket' => 'Maine Coon', 'fotografci' => 'Mikhail Volkov', 'sayfa' => 'https://unsplash.com/photos/YqcVdYpjgLo'],
    'mia'      => ['tur' => 'Kedi', 'etiket' => 'Siyam kedisi', 'fotografci' => 'Alex Meier', 'sayfa' => 'https://unsplash.com/photos/KGiQFgF7dkc'],
    'sirin'    => ['tur' => 'Kedi', 'etiket' => 'İran kedisi (Persian)', 'fotografci' => 'Rana Sawalha', 'sayfa' => 'https://unsplash.com/photos/X7UR0BDz-UY'],
    'fino'     => ['tur' => 'Köpek', 'etiket' => 'Fino (Rus Toy Terrier)', 'fotografci' => 'Morgan Marinoni', 'sayfa' => 'https://unsplash.com/photos/_fFUW-ScTok'],
    'minnos'   => ['tur' => 'Köpek', 'etiket' => 'Fino (Rus Toy Terrier) 2', 'fotografci' => 'Kateryna Kamenieva', 'sayfa' => 'https://unsplash.com/photos/cBbd4KskaEQ'],
    'rex'      => ['tur' => 'Köpek', 'etiket' => 'Husky', 'fotografci' => 'Ash', 'sayfa' => 'https://unsplash.com/photos/v0_MCllHY9M'],
    'boo'      => ['tur' => 'Köpek', 'etiket' => 'Pomeranian', 'fotografci' => 'Mariia Novikova', 'sayfa' => 'https://unsplash.com/photos/TQzvZJzIUMw'],
    'ciko'     => ['tur' => 'Köpek', 'etiket' => 'Labrador', 'fotografci' => 'Noémi Macavei-Katócz', 'sayfa' => 'https://unsplash.com/photos/c7bUIRBqapA'],
    'pako'     => ['tur' => 'Köpek', 'etiket' => 'Pug', 'fotografci' => 'OSMAN ESPINOZA FRANCO', 'sayfa' => 'https://unsplash.com/photos/85XqQOx4dyg'],
    'seker'    => ['tur' => 'Köpek', 'etiket' => 'Beagle', 'fotografci' => 'Lesya Tyutrina, Andrey Biyanov', 'sayfa' => 'https://unsplash.com/photos/HR5p3Ve6IkI'],
    'sosis'    => ['tur' => 'Köpek', 'etiket' => 'Dachshund (Sosis köpek)', 'fotografci' => 'Max Bvp', 'sayfa' => 'https://unsplash.com/photos/ohwEkkpuNms'],
    'altin'    => ['tur' => 'Balık', 'etiket' => 'Japon balığı', 'fotografci' => 'fishy fishy', 'sayfa' => 'https://unsplash.com/photos/zxdn0PGevRo'],
    'kizil'    => ['tur' => 'Balık', 'etiket' => 'Beta balığı', 'fotografci' => 'Likhith Raj', 'sayfa' => 'https://unsplash.com/photos/GQG-cBPcmGs'],
    'pembe'    => ['tur' => 'Balık', 'etiket' => 'Koi balığı', 'fotografci' => 'Nellie Adamyan', 'sayfa' => 'https://unsplash.com/photos/zJD6UVVW_Ck'],
    'melek'    => ['tur' => 'Balık', 'etiket' => 'Melek balığı', 'fotografci' => 'Luan Fonseca', 'sayfa' => 'https://unsplash.com/photos/kWAxFa--bLU'],    'cevizli'  => ['tur' => 'Hamster', 'etiket' => 'Suriye hamsteri', 'fotografci' => 'Juliya Sidorova', 'sayfa' => 'https://unsplash.com/photos/FOxMZK1VQS8'],
    'misir'    => ['tur' => 'Hamster', 'etiket' => 'Beyaz cüce hamster', 'fotografci' => 'Zhaoli JIN', 'sayfa' => 'https://unsplash.com/photos/ntpFNTy_XzY'],
    'kara'     => ['tur' => 'Kaplumbağa', 'etiket' => 'Kara kaplumbağası', 'fotografci' => 'Chandler Cruttenden', 'sayfa' => 'https://unsplash.com/photos/sqyMHTeaW84'],
    'kabak'    => ['tur' => 'Gine domuzu', 'etiket' => 'Tüylü gine domuzu', 'fotografci' => 'Smithsonian', 'sayfa' => 'https://unsplash.com/photos/bWNkJGOPPfE'],
    'diken'    => ['tur' => 'Kirpi', 'etiket' => 'Afrika cüce kirpisi', 'fotografci' => 'Nikola Tomašić', 'sayfa' => 'https://unsplash.com/photos/A8nXliyqWKs'],
    'tuylu'    => ['tur' => 'Şinşilla', 'etiket' => 'Gri şinşilla', 'fotografci' => 'Nikolett Emmert', 'sayfa' => 'https://unsplash.com/photos/OXHJlKPrnBY'],
    'fisilti'  => ['tur' => 'Şinşilla', 'etiket' => 'Şinşilla (ikinci)', 'fotografci' => 'Nikolett Emmert', 'sayfa' => 'https://unsplash.com/photos/WP8KvAMjCxs'],
    'cin'      => ['tur' => 'Ferret', 'etiket' => 'Ferret', 'fotografci' => 'Nikolett Emmert', 'sayfa' => 'https://unsplash.com/photos/0wb-NhKMupk'],
    'misil'    => ['tur' => 'Ferret', 'etiket' => 'Açık tüylü ferret', 'fotografci' => 'Nikolett Emmert', 'sayfa' => 'https://unsplash.com/photos/BLjhfYyfyIk'],
];

// Örnek veriler her değiştirildiğinde bu sayı bir artırılır
const VERI_SURUMU = 10;

// Oturum kaybolursa (tarayıcı/çerez temizlenirse) kayıtları geri yüklemek için yedek dosya
const YEDEK_DOSYA = __DIR__ . '/data/kayitlar.json';
const ORNEK_SAYISI = 53; // 1-53 arası id'ler örnek ilanlara ayrılmıştır

// Bakım hatırlatma aralıkları (gün). Genel bir örnek kuraldır; gerçek takvimi veteriner belirler.
const PARAZIT_ARALIGI = 90;   // parazit bakımı yaklaşık 3 ayda bir
const KONTROL_ARALIGI = 365;  // veteriner kontrolü yılda bir

// Bakım türleri: anahtar => [başlık, simge] (form, kartlar ve filtrede kullanılır)
$BAKIMLAR = [
    'parazit' => ['baslik' => 'Parazit bakımı', 'simge' => '🐛'],
    'kisir'   => ['baslik' => 'Kısırlaştırma',  'simge' => '✂️'],
    'kontrol' => ['baslik' => 'Veteriner kontrolü', 'simge' => '🩺'],
];

/*
 * Oturumda hiç kayıt yoksa 9 örnek kaydı yükler.
 * Bakım tarihleri bugüne göre hesaplanır (gunOnce), böylece durumlar her gün anlamlı kalır.
 * Sadece ilk açılışta çalışır; sonra kayıtlar $_SESSION'dan okunur.
 */
function ornekKayitlariYukle()
{
    // VERI_SURUMU: örnek veriler değiştiğinde eski oturumların da yeni örnekleri alması için
    yedektenYukle();
    if (!isset($_SESSION['hayvanlar']) || !isset($_SESSION['surum']) || $_SESSION['surum'] < VERI_SURUMU) {
        // Daha önce kullanıcının eklediği ilanlar varsa SIFIRLANMAZ, korunur (aşağıda geri eklenir)
        $eskiKayitlar = isset($_SESSION['hayvanlar']) ? $_SESSION['hayvanlar'] : [];
        $eskiSurum = isset($_SESSION['surum']) ? $_SESSION['surum'] : 0;
        $eskiOrnekSayisi = $eskiSurum >= 10 ? 53 : ($eskiSurum >= 9 ? 44 : ($eskiSurum >= 7 ? 24 : 9)); // her sürümdeki örnek sayısı
        $eskiGorusmeId = isset($_SESSION['sonGorusmeId']) ? $_SESSION['sonGorusmeId'] : 0;
        /*
         * Her kayıtta:
         *  yasAy      : hayvanın yaşı AY cinsinden (ör. 27 = 2 yıl 3 ay). Ekranda yasYaz() ile gösterilir.
         *  asilar     : yapılan aşılar, aşı anahtarı => tarih. Boş dizi = hiç aşı yapılmadı.
         *  gorusmeler : hayvanla görüşmeye gelen kişiler (her biri bir dizi).
         *  sahiplenen : sahiplenen kişinin bilgileri; sahiplenilmediyse null.
         */
        $_SESSION['hayvanlar'] = [
            1 => ['id' => 1, 'foto' => 'pamuk', 'ad' => 'Pamuk',  'tur' => 'Kedi',   'yasAy' => 26, 'cinsiyet' => 'Dişi',  'sehir' => 'Tokat',   'aciklama' => 'Çok uysal, kum kabı alışkanlığı var.', 'durum' => 'Yuva arıyor',
                  'asilar' => ['kedi_karma' => gunOnce(60), 'kedi_kuduz' => gunOnce(55), 'kedi_losemi' => gunOnce(50)],
                  'parazit' => gunOnce(20), 'kisir' => '', 'kontrol' => gunOnce(40), 'tarih' => '2026-10-21',
                  'gorusmeler' => [], 'sahiplenen' => null],
            2 => ['id' => 2, 'foto' => 'karabas', 'ad' => 'Karabaş','tur' => 'Köpek',  'yasAy' => 50, 'cinsiyet' => 'Erkek', 'sehir' => 'Sivas',   'aciklama' => 'Bahçeli eve uygun, çocuklarla arası çok iyi.', 'durum' => 'Görüşülüyor',
                  'asilar' => ['kopek_karma' => gunOnce(200), 'kopek_kuduz' => gunOnce(400), 'kopek_bronsit' => gunOnce(190)],
                  'parazit' => gunOnce(120), 'kisir' => gunOnce(400), 'kontrol' => gunOnce(200), 'tarih' => '2026-10-22',
                  'gorusmeler' => [
                      ['id' => 1, 'ad' => 'Mehmet Kaya', 'telefon' => '0532 111 22 33', 'tarih' => gunOnce(9), 'sonuc' => 'Düşünüyor', 'not' => 'Bahçeli evi var, eşiyle konuşup dönecek.'],
                      ['id' => 2, 'ad' => 'Elif Arslan', 'telefon' => '0545 222 33 44', 'tarih' => gunOnce(3), 'sonuc' => 'Olumlu',    'not' => 'Karabaş ile çok iyi anlaştı, hafta sonu tekrar gelecek.'],
                  ],
                  'sahiplenen' => null],
            3 => ['id' => 3, 'foto' => 'mavis', 'ad' => 'Maviş',  'tur' => 'Kuş',    'yasAy' => 8,  'cinsiyet' => 'Erkek', 'sehir' => 'Amasya',  'aciklama' => 'Muhabbet kuşu, kafesiyle birlikte veriliyor.', 'durum' => 'Yuva arıyor',
                  'asilar' => [],
                  'parazit' => '', 'kisir' => '', 'kontrol' => gunOnce(30), 'tarih' => '2026-10-25',
                  'gorusmeler' => [], 'sahiplenen' => null],
            4 => ['id' => 4, 'foto' => 'findik', 'ad' => 'Fındık', 'tur' => 'Tavşan', 'yasAy' => 14, 'cinsiyet' => 'Dişi',  'sehir' => 'Tokat',   'aciklama' => 'Hollanda lop cinsi, sakin ve temiz.', 'durum' => 'Sahiplendirildi',
                  'asilar' => ['tavsan_miksomatozis' => gunOnce(80)],
                  'parazit' => gunOnce(60), 'kisir' => gunOnce(90), 'kontrol' => gunOnce(90), 'tarih' => '2026-10-27',
                  'gorusmeler' => [
                      ['id' => 3, 'ad' => 'Zeynep Demir', 'telefon' => '0555 333 44 55', 'tarih' => gunOnce(14), 'sonuc' => 'Olumlu', 'not' => 'Daha önce tavşan bakmış, deneyimli.'],
                  ],
                  'sahiplenen' => ['adSoyad' => 'Zeynep Demir', 'telefon' => '0555 333 44 55', 'eposta' => 'zeynep.demir@ornek.com', 'sehir' => 'Tokat',
                                   'adres' => 'Yeşilırmak Mah. Gül Sok. No:5 Merkez', 'tarih' => gunOnce(10), 'not' => 'İlk ay sonunda kontrol için arayacağız.']],
            5 => ['id' => 5, 'foto' => 'duman', 'ad' => 'Duman',  'tur' => 'Kedi',   'yasAy' => 63, 'cinsiyet' => 'Erkek', 'sehir' => 'Samsun',  'aciklama' => 'Kısırlaştırılmış, sessiz bir ev arıyor.', 'durum' => 'Yuva arıyor',
                  'asilar' => ['kedi_karma' => gunOnce(30), 'kedi_kuduz' => gunOnce(25)],
                  'parazit' => gunOnce(10), 'kisir' => gunOnce(700), 'kontrol' => gunOnce(15), 'tarih' => '2026-11-01',
                  'gorusmeler' => [
                      ['id' => 4, 'ad' => 'Can Yıldız', 'telefon' => '0533 444 55 66', 'tarih' => gunOnce(5), 'sonuc' => 'Olumsuz', 'not' => 'Evde alerjisi olan biri varmış.'],
                  ],
                  'sahiplenen' => null],
            6 => ['id' => 6, 'foto' => 'zeytin', 'ad' => 'Zeytin', 'tur' => 'Köpek',  'yasAy' => 5,  'cinsiyet' => 'Dişi',  'sehir' => 'Ankara',  'aciklama' => 'Yavru, enerjik ve oyuncu. Tasma eğitimine başlandı.', 'durum' => 'Sahiplendirildi',
                  'asilar' => ['kopek_karma' => gunOnce(40), 'kopek_kuduz' => gunOnce(20)],
                  'parazit' => gunOnce(45), 'kisir' => '', 'kontrol' => gunOnce(20), 'tarih' => '2026-11-03',
                  'gorusmeler' => [
                      ['id' => 5, 'ad' => 'Ayşe Koç',     'telefon' => '0542 555 66 77', 'tarih' => gunOnce(8), 'sonuc' => 'Düşünüyor', 'not' => 'Apartmanda oturuyor, yönetimle konuşacak.'],
                      ['id' => 6, 'ad' => 'Burak Şahin',  'telefon' => '0506 666 77 88', 'tarih' => gunOnce(6), 'sonuc' => 'Olumlu',    'not' => 'Bahçeli müstakil ev, iki çocuğu var.'],
                  ],
                  'sahiplenen' => ['adSoyad' => 'Burak Şahin', 'telefon' => '0506 666 77 88', 'eposta' => '', 'sehir' => 'Ankara',
                                   'adres' => 'Bahçelievler Mah. 7. Cad. No:12 Çankaya', 'tarih' => gunOnce(4), 'not' => 'Bronşit aşısını yeni sahibi yaptıracak.']],
            7 => ['id' => 7, 'foto' => 'boncuk', 'ad' => 'Boncuk', 'tur' => 'Kedi',   'yasAy' => 38, 'cinsiyet' => 'Dişi',  'sehir' => 'İstanbul','aciklama' => 'Apartman dairesine çok uygun, kucak sever.', 'durum' => 'Görüşülüyor',
                  'asilar' => ['kedi_karma' => gunOnce(420), 'kedi_kuduz' => gunOnce(410), 'kedi_losemi' => gunOnce(400)],
                  'parazit' => gunOnce(150), 'kisir' => gunOnce(300), 'kontrol' => gunOnce(500), 'tarih' => '2026-11-04',
                  'gorusmeler' => [
                      ['id' => 7, 'ad' => 'Selin Aydın', 'telefon' => '0536 777 88 99', 'tarih' => gunOnce(2), 'sonuc' => 'Olumlu', 'not' => 'Daha önce kedi sahiplenmiş, referansı var.'],
                  ],
                  'sahiplenen' => null],
            8 => ['id' => 8, 'foto' => 'pasa', 'ad' => 'Paşa',   'tur' => 'Köpek',  'yasAy' => 75, 'cinsiyet' => 'Erkek', 'sehir' => 'Tokat',   'aciklama' => 'Sakin, yaşlıca bir dost. Bahçeli bir ev arıyor.', 'durum' => 'Yuva arıyor',
                  'asilar' => [],
                  'parazit' => '', 'kisir' => '', 'kontrol' => '', 'tarih' => '2026-11-05',
                  'gorusmeler' => [], 'sahiplenen' => null],
            9 => ['id' => 9, 'foto' => 'tosbik', 'ad' => 'Tosbik', 'tur' => 'Kaplumbağa',  'yasAy' => 96, 'cinsiyet' => 'Erkek', 'sehir' => 'Samsun',  'aciklama' => 'Su kaplumbağası, akvaryumuyla birlikte veriliyor.', 'durum' => 'Sahiplendirildi',
                  'asilar' => [],
                  'parazit' => '', 'kisir' => '', 'kontrol' => gunOnce(100), 'tarih' => '2026-11-06',
                  'gorusmeler' => [],
                  'sahiplenen' => ['adSoyad' => 'Hasan Çelik', 'telefon' => '0538 888 99 00', 'eposta' => 'hasan.celik@ornek.com', 'sehir' => 'Samsun',
                                   'adres' => 'Atakum Mah. Deniz Sok. No:3 Atakum', 'tarih' => gunOnce(3), 'not' => ''],],
        ];
        $_SESSION['hayvanlar'] += ekOrnekKayitlar();
        foreach (ornekCinsleri() as $oid => $ocins) {
            if (isset($_SESSION['hayvanlar'][$oid])) {
                $_SESSION['hayvanlar'][$oid]['cins'] = $ocins;
            }
        }
        $_SESSION['sonId'] = ORNEK_SAYISI;   // Yeni kayıtlar 54'ten başlayarak numaralanacak
        $_SESSION['sonGorusmeId'] = max(7, $eskiGorusmeId);

        // Eski oturumdaki kayıtları geri koy: örnekler (1-9) kullanıcı değişikliğiyle korunur,
        // kullanıcının eklediği ilanlar (örneklerden sonraki id'ler) yeni numaralarla örneklerin ardına eklenir.
        foreach ($eskiKayitlar as $eskiId => $kayit) {
            if ($eskiId <= $eskiOrnekSayisi) {
                $ornekFoto = isset($_SESSION['hayvanlar'][$eskiId]) ? $_SESSION['hayvanlar'][$eskiId]['foto'] : '';
                // Eskiden "Diğer" olan örnek hayvanlar (hamster, kaplumbağa vb.) artık kendi türünde
                if ($kayit['tur'] === 'Diğer' && isset($_SESSION['hayvanlar'][$eskiId]) && $_SESSION['hayvanlar'][$eskiId]['tur'] !== 'Diğer') {
                    $kayit['tur'] = $_SESSION['hayvanlar'][$eskiId]['tur'];
                }
                if (!isset($kayit['cins'])) {
                    $kayit['cins'] = isset($_SESSION['hayvanlar'][$eskiId]['cins']) ? $_SESSION['hayvanlar'][$eskiId]['cins'] : '';
                }
                if (empty($kayit['foto'])) {
                    $kayit['foto'] = $ornekFoto; // örnek ilanın fotoğrafı sonradan eklendiyse tamamlanır
                }
                $_SESSION['hayvanlar'][$eskiId] = $kayit;
            } else {
                $_SESSION['sonId']++;
                $kayit['id'] = $_SESSION['sonId'];
                $_SESSION['hayvanlar'][$_SESSION['sonId']] = $kayit;
            }
        }
        $_SESSION['surum'] = VERI_SURUMU;
    }
}


/*
 * Yedek dosyadan yükleme / dosyaya yazma.
 * Asıl depo yine $_SESSION'dır. Yedek yalnızca oturum kaybolduğunda
 * (çerez silindi, tarayıcı yeniden kuruldu vb.) kayıtların sıfırlanmasını önler.
 */
function yedektenYukle()
{
    if (isset($_SESSION['hayvanlar']) || !is_readable(YEDEK_DOSYA)) {
        return;
    }
    $veri = json_decode((string) file_get_contents(YEDEK_DOSYA), true);
    if (!is_array($veri) || !isset($veri['hayvanlar']) || !is_array($veri['hayvanlar'])) {
        return;
    }
    $hayvanlar = [];
    foreach ($veri['hayvanlar'] as $k) {
        if (isset($k['id'])) {
            $hayvanlar[(int) $k['id']] = $k;
        }
    }
    $_SESSION['hayvanlar']    = $hayvanlar;
    $_SESSION['sonId']        = isset($veri['sonId']) ? (int) $veri['sonId'] : ORNEK_SAYISI;
    $_SESSION['sonGorusmeId'] = isset($veri['sonGorusmeId']) ? (int) $veri['sonGorusmeId'] : 7;
    $_SESSION['surum']        = isset($veri['surum']) ? (int) $veri['surum'] : 0;
}

function yedegeYaz()
{
    if (!isset($_SESSION['hayvanlar'])) {
        return;
    }
    $paket = [
        'surum'        => isset($_SESSION['surum']) ? $_SESSION['surum'] : VERI_SURUMU,
        'sonId'        => $_SESSION['sonId'],
        'sonGorusmeId' => isset($_SESSION['sonGorusmeId']) ? $_SESSION['sonGorusmeId'] : 7,
        'hayvanlar'    => array_values($_SESSION['hayvanlar']),
    ];
    $json = json_encode($paket, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $klasor = dirname(YEDEK_DOSYA);
    if (!is_dir($klasor)) {
        @mkdir($klasor, 0775, true);
    }
    if (!is_file(YEDEK_DOSYA) || md5_file(YEDEK_DOSYA) !== md5($json)) {
        @file_put_contents(YEDEK_DOSYA, $json, LOCK_EX);
    }
}
// Her istek bittiğinde güncel kayıtlar yedeğe yazılır
register_shutdown_function('yedegeYaz');


/* Hayvanın cinsini döndürür (eski kayıtlarda alan yoksa boş metin). */
function cinsiGetir($hayvan)
{
    return isset($hayvan['cins']) ? $hayvan['cins'] : '';
}

/* Formda önerilen cins listesi (serbest yazıma da izin verilir). */
function cinsOnerileri()
{
    return ['British Shorthair', 'Scottish Fold', 'Maine Coon', 'Siyam', 'İran kedisi (Persian)', 'Van kedisi', 'Ankara kedisi', 'Tekir', 'Sarman', 'Rus mavisi',
            'Fino (Rus Toy Terrier)', 'Husky', 'Pomeranian', 'Labrador', 'Golden Retriever', 'Pug', 'Beagle', 'Dachshund (Sosis köpek)', 'Kangal', 'Border Collie', 'Melez',
            'Japon balığı', 'Beta balığı', 'Koi balığı', 'Melek balığı', 'Muhabbet kuşu', 'Kanarya', 'Hollanda Lop', 'Suriye hamsteri', 'Cüce hamster', 'Kara kaplumbağası', 'Su kaplumbağası', 'Abyssinian (gine domuzu)', 'Afrika cüce kirpisi', 'Şinşilla', 'Ferret'];
}

/* Örnek ilanların cinsleri (id => cins). */
function ornekCinsleri()
{
    return [
        1 => 'Van kedisi', 2 => 'Golden Retriever', 3 => 'Muhabbet kuşu', 4 => 'Hollanda Lop', 5 => 'Rus mavisi',
        6 => 'Melez', 7 => 'Üç renkli (Calico)', 8 => 'Melez', 9 => 'Su kaplumbağası',
        10 => 'Gri tekir', 11 => 'Sarman', 12 => 'Uzun tüylü', 13 => 'Melez', 14 => 'Golden Retriever',
        15 => 'Border Collie', 16 => 'Melez', 17 => 'Kanarya', 18 => 'Sarı papağan', 19 => 'Cüce tavşan',
        20 => 'Beyaz tavşan', 21 => 'Suriye hamsteri', 22 => 'Kirpi', 23 => 'Gine domuzu', 24 => 'Beyaz kedi',
        25 => 'British Shorthair', 26 => 'British Shorthair', 27 => 'British Shorthair', 28 => 'British Shorthair',
        29 => 'Scottish Fold', 30 => 'Maine Coon', 31 => 'Siyam', 32 => 'İran kedisi (Persian)',
        33 => 'Fino (Rus Toy Terrier)', 34 => 'Fino (Rus Toy Terrier)', 35 => 'Husky', 36 => 'Pomeranian',
        37 => 'Labrador', 38 => 'Pug', 39 => 'Beagle', 40 => 'Dachshund (Sosis köpek)',
        41 => 'Japon balığı', 42 => 'Beta balığı', 43 => 'Koi balığı', 44 => 'Melek balığı',
        45 => 'Suriye hamsteri', 46 => 'Cüce hamster', 47 => 'Kara kaplumbağası', 48 => 'Abyssinian', 49 => 'Afrika cüce kirpisi',
        50 => 'Şinşilla', 51 => 'Şinşilla', 52 => 'Ferret', 53 => 'Ferret',
    ];
}

/* Kısa yazım için yardımcı: ek örnek ilan satırı üretir. */
function ornekSatir($id, $foto, $ad, $tur, $yasAy, $cins, $sehir, $acik, $durum, $asilar, $parazit, $kisir, $kontrol, $gun)
{
    return ['id' => $id, 'foto' => $foto, 'ad' => $ad, 'tur' => $tur, 'yasAy' => $yasAy, 'cinsiyet' => $cins,
            'sehir' => $sehir, 'aciklama' => $acik, 'durum' => $durum, 'asilar' => $asilar,
            'parazit' => $parazit, 'kisir' => $kisir, 'kontrol' => $kontrol,
            'tarih' => date('Y-m-d', strtotime("-$gun days")), 'gorusmeler' => [], 'sahiplenen' => null];
}

/* 10-44 numaralı ek örnek ilanlar. */
function ekOrnekKayitlar()
{
    $k = gunOnce(30); $m = ['kedi_karma' => gunOnce(70), 'kedi_kuduz' => gunOnce(65)];
    $d = ['kopek_karma' => gunOnce(100), 'kopek_kuduz' => gunOnce(95)];
    $liste = [
        ornekSatir(10, 'mirmir', 'Mırmır',  'Kedi',   4,  'Erkek', 'Ankara',   'Yavru, oyuncu ve çok sevecen.', 'Yuva arıyor', ['kedi_karma' => gunOnce(20)], gunOnce(15), '', gunOnce(20), 30),
        ornekSatir(11, 'tarcin', 'Tarçın',  'Kedi',   18, 'Dişi',  'İzmir',    'Sarman, kucağa gelmeyi sever.', 'Yuva arıyor', $m, gunOnce(40), gunOnce(200), $k, 28),
        ornekSatir(12, 'limon', 'Limon',   'Kedi',   72, 'Erkek', 'Tokat',    'Yaşlı ama enerjik, tek kedi olmak istiyor.', 'Görüşülüyor', $m, gunOnce(30), gunOnce(900), gunOnce(60), 26),
        ornekSatir(13, 'comar', 'Çomar',   'Köpek',  36, 'Erkek', 'Sivas',    'Çiftlik için ideal, güçlü ve sadık.', 'Yuva arıyor', $d, gunOnce(50), '', gunOnce(90), 25),
        ornekSatir(14, 'fistik', 'Fıstık',  'Köpek',  7,  'Dişi',  'Bursa',    'Yavru, tuvalet eğitimi başladı.', 'Yuva arıyor', ['kopek_karma' => gunOnce(30)], gunOnce(25), '', gunOnce(30), 24),
        ornekSatir(15, 'max', 'Max',     'Köpek',  60, 'Erkek', 'İstanbul', 'Eğitimli, apartman hayatına alışkın.', 'Görüşülüyor', $d, gunOnce(70), gunOnce(500), gunOnce(100), 22),
        ornekSatir(16, 'lokum', 'Lokum',   'Köpek',  22, 'Dişi',  'Samsun',   'Çocuklarla çok iyi anlaşıyor.', 'Yuva arıyor', $d, gunOnce(35), gunOnce(150), gunOnce(60), 21),
        ornekSatir(17, 'pirpir', 'Pırpır',  'Kuş',    12, 'Dişi',  'Tokat',    'Sarı kanarya, güzel ötüyor.', 'Yuva arıyor', [], '', '', gunOnce(45), 19),
        ornekSatir(18, 'civil', 'Cıvıl',   'Kuş',    24, 'Erkek', 'Ordu',     'El üstünde yemek yiyebilen sevimli papağan.', 'Yuva arıyor', [], '', '', gunOnce(80), 17),
        ornekSatir(19, 'pofuduk', 'Pofuduk', 'Tavşan', 9,  'Erkek', 'Ankara',   'Cüce tavşan, havuç delisi.', 'Yuva arıyor', ['tavsan_miksomatozis' => gunOnce(40)], gunOnce(30), '', gunOnce(50), 15),
        ornekSatir(20, 'bulut', 'Bulut',   'Tavşan', 30, 'Dişi',  'Tokat',    'Sakin, kafesinden çıkıp gezmeyi sever.', 'Görüşülüyor', ['tavsan_miksomatozis' => gunOnce(120), 'tavsan_rhd' => gunOnce(110)], gunOnce(80), gunOnce(250), gunOnce(130), 13),
        ornekSatir(21, 'gidik', 'Gıdık',   'Hamster',  14, 'Erkek', 'Eskişehir','Hamster, kafesi ve çarkı ile birlikte.', 'Yuva arıyor', [], '', '', '', 11),
        ornekSatir(22, 'kirpi', 'Kirpi',   'Kirpi',  20, 'Dişi',  'Sivas',    'Gece aktif, sessiz bir ev arıyor.', 'Yuva arıyor', [], gunOnce(60), '', gunOnce(75), 9),
        ornekSatir(23, 'zipzip', 'Zıpzıp',  'Gine domuzu',  18, 'Erkek', 'Antalya',  'Gine domuzu, sebze sever.', 'Yuva arıyor', [], '', '', gunOnce(40), 7),
        ornekSatir(24, 'pamuk2', 'Pamuk 2', 'Kedi',   10, 'Dişi',  'Kayseri',  'Beyaz tüylü, mavi gözlü yavru.', 'Yuva arıyor', ['kedi_karma' => gunOnce(25)], gunOnce(20), '', gunOnce(25), 5),
        // ---- 25-44: cinse göre çeşitlendirilmiş ilanlar (British Shorthair yavru ve yetişkin, Fino, balıklar...) ----
        ornekSatir(25, 'lord',    'Lord',     'Kedi',   3,  'Erkek', 'İstanbul', 'British Shorthair yavru, yuvarlak yüzlü ve çok oyuncu. Mama ve kum alışkanlığı oturdu.', 'Yuva arıyor', ['kedi_karma' => gunOnce(14)], gunOnce(10), '', gunOnce(14), 4),
        ornekSatir(26, 'prenses', 'Prenses',  'Kedi',   4,  'Dişi',  'Ankara',   'British Shorthair yavru, tombul ve sevecen. İlk aşısı yapıldı.', 'Yuva arıyor', ['kedi_karma' => gunOnce(20)], gunOnce(15), '', gunOnce(20), 6),
        ornekSatir(27, 'baypasa', 'Bay Paşa', 'Kedi',   36, 'Erkek', 'İzmir',    'British Shorthair yetişkin, vakur ve sakin. Kısırlaştırılmış, apartman kedisi.', 'Yuva arıyor', ['kedi_karma' => gunOnce(100), 'kedi_kuduz' => gunOnce(95)], gunOnce(40), gunOnce(500), gunOnce(60), 8),
        ornekSatir(28, 'karamel', 'Karamel',  'Kedi',   60, 'Dişi',  'Bursa',    'British Shorthair yetişkin, kucakta durmayı sever ama sessizliği tercih eder.', 'Görüşülüyor', ['kedi_karma' => gunOnce(300), 'kedi_kuduz' => gunOnce(290), 'kedi_losemi' => gunOnce(280)], gunOnce(70), gunOnce(900), gunOnce(200), 10),
        ornekSatir(29, 'sutlac',  'Sütlaç',   'Kedi',   12, 'Dişi',  'Antalya',  'Katlanmış kulaklı Scottish Fold, merak dolu ve uysal.', 'Yuva arıyor', ['kedi_karma' => gunOnce(50), 'kedi_kuduz' => gunOnce(45)], gunOnce(30), '', gunOnce(45), 12),
        ornekSatir(30, 'aslan',   'Aslan',    'Kedi',   30, 'Erkek', 'Tokat',    'Maine Coon, iri yapılı ama çok yumuşak huylu. Tüy bakımı ister.', 'Yuva arıyor', ['kedi_karma' => gunOnce(120), 'kedi_kuduz' => gunOnce(115)], gunOnce(35), gunOnce(400), gunOnce(90), 14),
        ornekSatir(31, 'mia',     'Mia',      'Kedi',   20, 'Dişi',  'Eskişehir','Mavi gözlü Siyam, konuşkan ve ilgi seven.', 'Yuva arıyor', ['kedi_karma' => gunOnce(80), 'kedi_kuduz' => gunOnce(75)], gunOnce(20), '', gunOnce(70), 16),
        ornekSatir(32, 'sirin',   'Şirin',    'Kedi',   48, 'Dişi',  'Samsun',   'İran kedisi, uzun tüylü. Düzenli tarama gerekir, sakin bir ev arıyor.', 'Yuva arıyor', ['kedi_karma' => gunOnce(60), 'kedi_kuduz' => gunOnce(55), 'kedi_losemi' => gunOnce(50)], gunOnce(25), gunOnce(700), gunOnce(40), 18),
        ornekSatir(33, 'fino',    'Fino',     'Köpek',  18, 'Erkek', 'İstanbul', 'Rus Toy Terrier (Fino), minik ve çevik. Küçük dairelere çok uygun.', 'Yuva arıyor', ['kopek_karma' => gunOnce(60), 'kopek_kuduz' => gunOnce(55)], gunOnce(30), '', gunOnce(50), 20),
        ornekSatir(34, 'minnos',  'Minnoş',   'Köpek',  8,  'Dişi',  'Ankara',   'Rus Toy Terrier yavru, kulakları iri, enerjisi bol.', 'Görüşülüyor', ['kopek_karma' => gunOnce(25)], gunOnce(20), '', gunOnce(25), 22),
        ornekSatir(35, 'rex',     'Rex',      'Köpek',  28, 'Erkek', 'Sivas',    'Husky, mavi gözlü ve çok aktif. Geniş bahçe ve uzun yürüyüşler ister.', 'Yuva arıyor', ['kopek_karma' => gunOnce(150), 'kopek_kuduz' => gunOnce(145), 'kopek_bronsit' => gunOnce(140)], gunOnce(45), gunOnce(300), gunOnce(100), 24),
        ornekSatir(36, 'boo',     'Boo',      'Köpek',  14, 'Dişi',  'İzmir',    'Pomeranian, pofuduk tüylü ve neşeli. Düzenli tarama gerekir.', 'Yuva arıyor', ['kopek_karma' => gunOnce(90), 'kopek_kuduz' => gunOnce(85)], gunOnce(30), '', gunOnce(60), 26),
        ornekSatir(37, 'ciko',    'Çiko',     'Köpek',  40, 'Erkek', 'Tokat',    'Labrador, çocuklarla ve diğer hayvanlarla çok iyi anlaşır.', 'Yuva arıyor', ['kopek_karma' => gunOnce(200), 'kopek_kuduz' => gunOnce(195), 'kopek_bronsit' => gunOnce(190)], gunOnce(60), gunOnce(600), gunOnce(130), 28),
        ornekSatir(38, 'pako',    'Pako',     'Köpek',  24, 'Erkek', 'Bursa',    'Pug, horlayan ve kucak seven bir apartman köpeği.', 'Görüşülüyor', ['kopek_karma' => gunOnce(110), 'kopek_kuduz' => gunOnce(105)], gunOnce(25), gunOnce(200), gunOnce(80), 30),
        ornekSatir(39, 'seker',   'Şeker',    'Köpek',  34, 'Dişi',  'Ankara',   'Beagle, koku alma yeteneği harika; yürüyüşü ve oyunu çok sever.', 'Yuva arıyor', ['kopek_karma' => gunOnce(250), 'kopek_kuduz' => gunOnce(245)], gunOnce(70), gunOnce(400), gunOnce(150), 32),
        ornekSatir(40, 'sosis',   'Sosis',    'Köpek',  50, 'Erkek', 'Samsun',   'Dachshund (sosis köpek), uzun gövdeli ve cesur. Merdivenden sakınılmalı.', 'Yuva arıyor', ['kopek_karma' => gunOnce(180), 'kopek_kuduz' => gunOnce(175)], gunOnce(50), gunOnce(500), gunOnce(110), 34),
        ornekSatir(41, 'altin',   'Altın',    'Balık',  18, 'Dişi',  'Ankara',   'Japon balığı, en az 60 litrelik akvaryum ve filtre gerekir.', 'Yuva arıyor', [], '', '', gunOnce(40), 36),
        ornekSatir(42, 'kizil',   'Kızıl',    'Balık',  10, 'Erkek', 'Tokat',    'Beta balığı, tek başına tutulmalı. Küçük, ısıtıcılı akvaryumla verilecek.', 'Yuva arıyor', [], '', '', gunOnce(25), 38),
        ornekSatir(43, 'pembe',   'Pembe',    'Balık',  36, 'Dişi',  'Antalya',  'Koi balığı, havuzlu bir bahçe ya da büyük bir hacim ister.', 'Görüşülüyor', [], '', '', gunOnce(60), 40),
        ornekSatir(44, 'melek',   'Melek',    'Balık',  16, 'Dişi',  'İzmir',    'Melek balığı, sakin ve zarif; uzun boylu bir akvaryum ister.', 'Yuva arıyor', [], '', '', gunOnce(35), 42),
        // ---- 45-53: yeni türler (hamster, kaplumbağa, gine domuzu, kirpi, şinşilla, ferret) ----
        ornekSatir(45, 'cevizli', 'Cevizli', 'Hamster',     6,   'Erkek', 'Ankara',   'Suriye hamsteri, geceleri çarkta koşmayı sever. Kafesiyle verilecek.', 'Yuva arıyor', [], '', '', gunOnce(20), 3),
        ornekSatir(46, 'misir',   'Mısır',   'Hamster',     4,   'Dişi',  'İzmir',    'Beyaz cüce hamster, çok küçük ve hareketli.', 'Yuva arıyor', [], '', '', gunOnce(15), 2),
        ornekSatir(47, 'kara',    'Kara',    'Kaplumbağa',  240, 'Dişi',  'Antalya',  'Kara kaplumbağası, 20 yaşında. Bahçeli bir yuva ve güneşli bir köşe ister.', 'Yuva arıyor', [], '', '', gunOnce(120), 5),
        ornekSatir(48, 'kabak',   'Kabak',   'Gine domuzu', 16,  'Erkek', 'Bursa',    'Abyssinian gine domuzu, tüyleri kıvırcık. Taze sebze ve ot sever.', 'Görüşülüyor', [], gunOnce(60), '', gunOnce(45), 4),
        ornekSatir(49, 'diken',   'Diken',   'Kirpi',       18,  'Dişi',  'Eskişehir','Afrika cüce kirpisi, geceleri aktif. Isıtmalı ve sessiz bir ortam gerekir.', 'Yuva arıyor', [], gunOnce(50), '', gunOnce(60), 6),
        ornekSatir(50, 'tuylu',   'Tüylü',   'Şinşilla',    24,  'Dişi',  'İstanbul', 'Gri şinşilla, tüyü yumuşacık. Toz banyosu yapmayı çok sever.', 'Yuva arıyor', [], gunOnce(80), '', gunOnce(90), 7),
        ornekSatir(51, 'fisilti', 'Fısıltı', 'Şinşilla',    10,  'Erkek', 'Ankara',   'Genç şinşilla, çok meraklı ve hızlı. Serin bir oda gerekir.', 'Yuva arıyor', [], '', '', gunOnce(40), 8),
        ornekSatir(52, 'cin',     'Cin',     'Ferret',      20,  'Erkek', 'Samsun',   'Ferret, oyuncu ve haylaz. Her gün oyun ve gezinti için zaman ister.', 'Yuva arıyor', [], gunOnce(90), gunOnce(300), gunOnce(100), 9),
        ornekSatir(53, 'misil',   'Mısıl',   'Ferret',      9,   'Dişi',  'İzmir',    'Açık tüylü genç ferret, insanlara çabuk alışıyor.', 'Yuva arıyor', [], gunOnce(30), '', gunOnce(35), 11),
    ];
    $sonuc = [];
    foreach ($liste as $h) { $sonuc[$h['id']] = $h; }
    return $sonuc;
}

/* Oturumdaki bütün hayvan kayıtlarını döndürür. */
function hayvanlariGetir()
{
    return $_SESSION['hayvanlar'];
}

/*
 * Formdan gelen verileri kontrol eder.
 * Hata yoksa boş dizi, hata varsa hata mesajlarının dizisini döndürür.
 */
function formuDogrula($veri)
{
    global $TURLER, $DURUMLAR, $CINSIYETLER, $ASI_DURUMLARI;
    $hatalar = [];

    // Zorunlu metin alanları boş mu?
    if ($veri['ad'] === '') {
        $hatalar[] = 'Hayvanın adı boş bırakılamaz.';
    } elseif (mb_strlen($veri['ad']) > 30) {
        $hatalar[] = 'Hayvanın adı en fazla 30 karakter olabilir.';
    }

    if (mb_strlen($veri['cins']) > 40) {
        $hatalar[] = 'Cins en fazla 40 karakter olabilir.';
    }

    if ($veri['sehir'] === '') {
        $hatalar[] = 'Şehir boş bırakılamaz.';
    }

    if ($veri['aciklama'] === '') {
        $hatalar[] = 'Açıklama boş bırakılamaz.';
    } elseif (mb_strlen($veri['aciklama']) < 10) {
        $hatalar[] = 'Açıklama en az 10 karakter olmalıdır.';
    }

    // Yaş: yıl (0–30) ve ay (0–11) ayrı girilir. Ay boşsa 0 sayılır.
    if ($veri['yasYil'] === '') {
        $hatalar[] = 'Yaşın yıl kısmı boş bırakılamaz (1 yaşından küçükse 0 yazın).';
    } elseif (!ctype_digit($veri['yasYil']) || (int)$veri['yasYil'] > 30) {
        $hatalar[] = 'Yaş (yıl) 0 ile 30 arasında bir tam sayı olmalıdır.';
    }
    if ($veri['yasAy'] !== '' && (!ctype_digit($veri['yasAy']) || (int)$veri['yasAy'] > 11)) {
        $hatalar[] = 'Yaş (ay) 0 ile 11 arasında bir tam sayı olmalıdır.';
    }
    if ($veri['yasYil'] === '0' && (int)$veri['yasAy'] === 0) {
        $hatalar[] = 'Yaş en az 1 ay olmalıdır.';
    }

    // Seçim alanları listedeki değerlerden biri mi? (formu elle değiştirmeye karşı kontrol)
    if (!in_array($veri['tur'], $TURLER)) {
        $hatalar[] = 'Lütfen geçerli bir tür seçiniz.';
    }
    if (!in_array($veri['cinsiyet'], $CINSIYETLER)) {
        $hatalar[] = 'Lütfen cinsiyet seçiniz.';
    }
    // Fotoğraf isteğe bağlı: seçildiyse listede olmalı ve hayvanın türüne uymalı
    global $FOTO_KAYNAKLARI;
    if ($veri['foto'] !== '') {
        if (!isset($FOTO_KAYNAKLARI[$veri['foto']])) {
            $hatalar[] = 'Seçilen fotoğraf listede yok.';
        } elseif ($FOTO_KAYNAKLARI[$veri['foto']]['tur'] !== $veri['tur']) {
            $hatalar[] = 'Seçilen fotoğraf ' . $veri['tur'] . ' türüne uymuyor. Lütfen türe uygun bir fotoğraf seçin ya da boş bırakın.';
        }
    }

    // Aşı tarihleri: işaretlenen her aşının tarihi geçerli olmalı
    global $ASI_LISTESI;
    foreach ($veri['asilar'] as $anahtar => $tarih) {
        if ($tarih === '' || !tarihGecerliMi($tarih)) {
            $asiAdi = isset($ASI_LISTESI[$veri['tur']][$anahtar]) ? $ASI_LISTESI[$veri['tur']][$anahtar] : 'Aşı';
            $hatalar[] = $asiAdi . ' tarihi geçerli bir tarih olmalı ve bugünden ileri olamaz.';
        }
    }
    // Bakım tarihleri boş bırakılabilir (yapılmadı demek), doluysa geçerli olmalı
    global $BAKIMLAR;
    foreach ($BAKIMLAR as $alan => $bilgi) {
        if (!tarihGecerliMi($veri[$alan])) {
            $hatalar[] = $bilgi['baslik'] . ' tarihi geçerli bir tarih olmalı ve bugünden ileri olamaz.';
        }
    }
    if (!in_array($veri['durum'], $DURUMLAR)) {
        $hatalar[] = 'Lütfen geçerli bir durum seçiniz.';
    }

    return $hatalar;
}

/* Yeni hayvan kaydını oturuma ekler. */
function hayvanEkle($veri)
{
    $_SESSION['sonId']++;
    $id = $_SESSION['sonId'];

    $_SESSION['hayvanlar'][$id] = [
        'id'         => $id,
        'foto'       => $veri['foto'],
        'cins'       => $veri['cins'],
        'ad'         => $veri['ad'],
        'tur'        => $veri['tur'],
        'yasAy'      => toplamAy($veri['yasYil'], $veri['yasAy']),
        'cinsiyet'   => $veri['cinsiyet'],
        'sehir'      => sehirDuzenle($veri['sehir']),
        'aciklama'   => $veri['aciklama'],
        'durum'      => $veri['durum'],
        'asilar'     => $veri['asilar'],
        'parazit'    => $veri['parazit'],
        'kisir'      => $veri['kisir'],
        'kontrol'    => $veri['kontrol'],
        'tarih'      => date('Y-m-d'),
        'gorusmeler' => [],
        'sahiplenen' => null,
    ];
    return $id;
}

/* Verilen id'ye sahip kaydı siler. Kayıt varsa true, yoksa false döndürür. */
function hayvanSil($id)
{
    if (isset($_SESSION['hayvanlar'][$id])) {
        unset($_SESSION['hayvanlar'][$id]);
        return true;
    }
    return false;
}

/* Verilen id'ye sahip kaydı döndürür. Kayıt yoksa null döndürür. */
function hayvanBul($id)
{
    if (isset($_SESSION['hayvanlar'][$id])) {
        return $_SESSION['hayvanlar'][$id];
    }
    return null;
}

/*
 * Var olan kaydı formdan gelen yeni bilgilerle günceller.
 * id ve ilan tarihi değişmez, diğer alanlar yenilenir.
 */
function hayvanGuncelle($id, $veri)
{
    if (!isset($_SESSION['hayvanlar'][$id])) {
        return false;
    }
    $eski = $_SESSION['hayvanlar'][$id];

    $_SESSION['hayvanlar'][$id] = [
        'id'         => $id,
        'foto'       => $veri['foto'],
        'cins'       => $veri['cins'],
        'ad'         => $veri['ad'],
        'tur'        => $veri['tur'],
        'yasAy'      => toplamAy($veri['yasYil'], $veri['yasAy']),
        'cinsiyet'   => $veri['cinsiyet'],
        'sehir'      => sehirDuzenle($veri['sehir']),
        'aciklama'   => $veri['aciklama'],
        'durum'      => $veri['durum'],
        'asilar'     => $veri['asilar'],
        'parazit'    => $veri['parazit'],
        'kisir'      => $veri['kisir'],
        'kontrol'    => $veri['kontrol'],
        'tarih'      => $eski['tarih'],
        // Görüşmeler ve sahiplenen bilgisi bu formda değişmez, eskisi korunur
        'gorusmeler' => gorusmeleriGetir($eski),
        'sahiplenen' => sahiplenenGetir($eski),
    ];
    return true;
}

/*
 * Kayıtlarda kelime araması yapar (ad, tür, şehir ve açıklama alanlarında).
 * mb_stripos büyük/küçük harf duyarsız arar ve Türkçe karakterleri destekler.
 */
function hayvanlariAra($liste, $kelime)
{
    if ($kelime === '') {
        return $liste; // arama boşsa hepsini döndür
    }
    $sonuc = [];
    foreach ($liste as $hayvan) {
        $metin = $hayvan['ad'] . ' ' . $hayvan['tur'] . ' ' . cinsiGetir($hayvan) . ' ' . $hayvan['sehir'] . ' ' . $hayvan['aciklama'];
        // Sahiplenen ve görüşen kişilerin adlarıyla da arama yapılabilsin
        $sahip = sahiplenenGetir($hayvan);
        if ($sahip !== null) {
            $metin .= ' ' . $sahip['adSoyad'];
        }
        foreach (gorusmeleriGetir($hayvan) as $gorusme) {
            $metin .= ' ' . $gorusme['ad'];
        }
        if (mb_stripos($metin, $kelime, 0, 'UTF-8') !== false) {
            $sonuc[] = $hayvan;
        }
    }
    return $sonuc;
}

/*
 * Kayıtları seçilen ölçüte göre sıralar.
 * usort, iki kaydı karşılaştıran bir fonksiyona göre diziyi sıralar.
 * <=> (spaceship) operatörü: soldaki küçükse -1, eşitse 0, büyükse 1 döndürür.
 */
function hayvanlariSirala($liste, $siralama)
{
    if ($siralama === 'eski') {
        usort($liste, function ($a, $b) { return $a['id'] <=> $b['id']; });
    } elseif ($siralama === 'genc') {
        usort($liste, function ($a, $b) { return yasAyGetir($a) <=> yasAyGetir($b); });
    } elseif ($siralama === 'ad') {
        usort($liste, function ($a, $b) { return strcmp(mb_strtolower($a['ad']), mb_strtolower($b['ad'])); });
    } else { // varsayılan: en yeni ilan en üstte
        usort($liste, function ($a, $b) { return $b['id'] <=> $a['id']; });
    }
    return $liste;
}

/* Her türden kaç ilan olduğunu sayar (istatistik grafiği için). */
function turleriSay($liste)
{
    global $TURLER;
    $sayilar = [];
    foreach ($TURLER as $tur) {
        $sayilar[$tur] = 0; // önce her türü 0'dan başlat
    }
    foreach ($liste as $hayvan) {
        $sayilar[$hayvan['tur']]++;
    }
    return $sayilar;
}

/*
 * Kayıtları türe, duruma, şehre ve aşı durumuna göre filtreler.
 * Boş gelen filtre "hepsi" anlamına gelir. $sehir verilmezse şehir filtresi uygulanmaz.
 */
function hayvanlariFiltrele($liste, $tur, $durum, $sehir = '', $asi = '')
{
    $sonuc = [];
    foreach ($liste as $hayvan) {
        if ($tur !== '' && $hayvan['tur'] !== $tur) {
            continue; // tür uymuyorsa bu kaydı atla
        }
        if ($durum !== '' && $hayvan['durum'] !== $durum) {
            continue; // durum uymuyorsa bu kaydı atla
        }
        if ($sehir !== '' && $hayvan['sehir'] !== $sehir) {
            continue; // şehir uymuyorsa bu kaydı atla
        }
        if ($asi !== '' && asiDurumu($hayvan) !== $asi) {
            continue; // aşı durumu uymuyorsa bu kaydı atla
        }
        $sonuc[] = $hayvan;
    }
    return $sonuc;
}

/*
 * Şehir adını düzgün yazar: ilk harf büyük, diğerleri küçük ("tokat" → "Tokat").
 * Türkçedeki i/İ ve ı/I harfleri PHP'de doğru çevrilmediği için elle düzeltiliyor.
 * Böylece "tokat", "TOKAT" ve "Tokat" aynı şehir sayılır.
 */
function sehirDuzenle($sehir)
{
    $sehir = trim($sehir);
    if ($sehir === '') {
        return '';
    }
    $ilk  = mb_substr($sehir, 0, 1, 'UTF-8');
    $kalan = mb_substr($sehir, 1, null, 'UTF-8');

    // Kalan harfleri küçült (önce Türkçe I/İ harflerini elle çeviriyoruz)
    $kalan = str_replace(['I', 'İ'], ['ı', 'i'], $kalan);
    $kalan = mb_strtolower($kalan, 'UTF-8');

    // İlk harfi büyüt (i → İ, ı → I)
    if ($ilk === 'i') {
        $ilk = 'İ';
    } elseif ($ilk === 'ı') {
        $ilk = 'I';
    } else {
        $ilk = mb_strtoupper($ilk, 'UTF-8');
    }
    return $ilk . $kalan;
}

/*
 * Her şehir için ilan sayılarını hesaplar.
 * Dönen dizi örneği: ['Tokat' => ['toplam' => 3, 'Yuva arıyor' => 2, 'Görüşülüyor' => 0, 'Sahiplendirildi' => 1], ...]
 * Şehirler en çok ilanı olandan en aza doğru sıralanır.
 */
function sehirleriSay($liste)
{
    global $DURUMLAR;
    $sehirler = [];
    foreach ($liste as $hayvan) {
        $sehir = $hayvan['sehir'];
        // Bu şehir ilk kez görülüyorsa sayaçlarını sıfırla
        if (!isset($sehirler[$sehir])) {
            $sehirler[$sehir] = ['toplam' => 0];
            foreach ($DURUMLAR as $durum) {
                $sehirler[$sehir][$durum] = 0;
            }
        }
        $sehirler[$sehir]['toplam']++;
        $sehirler[$sehir][$hayvan['durum']]++;
    }
    // Toplam ilan sayısına göre büyükten küçüğe sırala (anahtarlar, yani şehir adları korunur)
    uasort($sehirler, function ($a, $b) { return $b['toplam'] <=> $a['toplam']; });
    return $sehirler;
}

/*
 * Hayvanın aşı durumunu yapılan aşılara bakarak HESAPLAR:
 *  - Türü için aşı listesi yoksa (Kuş, Diğer) → "Aşı gerekmiyor"
 *  - Gerekli aşıların hepsi yapıldıysa      → "Aşıları tam"
 *  - Bir kısmı yapıldıysa                   → "Kısmen aşılı"
 *  - Hiçbiri yapılmadıysa                   → "Aşısız"
 */
function asiDurumu($hayvan)
{
    $gerekli = gerekliAsilar($hayvan['tur']);
    if (count($gerekli) === 0) {
        return 'Aşı gerekmiyor';
    }
    $yapilan = count(yapilanAsilar($hayvan));
    if ($yapilan === count($gerekli)) {
        return 'Aşıları tam';
    } elseif ($yapilan > 0) {
        return 'Kısmen aşılı';
    }
    return 'Aşısız';
}

/* Türe göre yapılması gereken aşıların listesini döndürür (anahtar => ad). */
function gerekliAsilar($tur)
{
    global $ASI_LISTESI;
    return isset($ASI_LISTESI[$tur]) ? $ASI_LISTESI[$tur] : [];
}

/*
 * Hayvana yapılmış aşıları döndürür (anahtar => tarih).
 * Sadece hayvanın türüne ait aşılar sayılır.
 */
function yapilanAsilar($hayvan)
{
    $asilar  = isset($hayvan['asilar']) ? $hayvan['asilar'] : [];
    $gerekli = gerekliAsilar($hayvan['tur']);
    $sonuc = [];
    foreach ($asilar as $anahtar => $tarih) {
        if (isset($gerekli[$anahtar]) && $tarih !== '') {
            $sonuc[$anahtar] = $tarih;
        }
    }
    return $sonuc;
}

/*
 * Aşı kartı için her aşının durumunu hazırlar.
 * Dönen dizi: [ ['ad' => 'Kuduz aşısı', 'tarih' => '2026-05-01', 'sonraki' => '2027-05-01', 'kod' => guncel|gecikmis|yapilmadi, 'yazi' => ...], ... ]
 */
function asiKarti($hayvan)
{
    $yapilan = yapilanAsilar($hayvan);
    $kart = [];
    foreach (gerekliAsilar($hayvan['tur']) as $anahtar => $ad) {
        if (!isset($yapilan[$anahtar])) {
            $kart[] = ['ad' => $ad, 'tarih' => '', 'sonraki' => '', 'kod' => 'yapilmadi', 'yazi' => 'Yapılmadı'];
            continue;
        }
        $tarih   = $yapilan[$anahtar];
        $sonraki = date('Y-m-d', strtotime($tarih . ' +' . ASI_ARALIGI . ' days'));
        if (gecenGun($tarih) > ASI_ARALIGI) {
            $kart[] = ['ad' => $ad, 'tarih' => $tarih, 'sonraki' => $sonraki, 'kod' => 'gecikmis', 'yazi' => 'Rapel zamanı geçti'];
        } else {
            $kart[] = ['ad' => $ad, 'tarih' => $tarih, 'sonraki' => $sonraki, 'kod' => 'guncel', 'yazi' => 'Güncel'];
        }
    }
    return $kart;
}

/* Rapel (tekrar) zamanı geçmiş aşı sayısını döndürür. */
function rapelGecenSay($hayvan)
{
    $sayac = 0;
    foreach (asiKarti($hayvan) as $asi) {
        if ($asi['kod'] === 'gecikmis') {
            $sayac++;
        }
    }
    return $sayac;
}

/*
 * Formdan gelen aşı tarihlerini alır.
 * Sadece seçilen türe ait ve tarihi doldurulmuş aşılar alınır.
 * Böylece kullanıcı türü değiştirirse başka türün aşıları kayda girmez.
 */
function asilariFormdanAl($tur)
{
    $gelen  = (isset($_POST['asilar']) && is_array($_POST['asilar'])) ? $_POST['asilar'] : [];
    $sonuc = [];
    foreach (gerekliAsilar($tur) as $anahtar => $ad) {
        $tarih = isset($gelen[$anahtar]) ? trim((string)$gelen[$anahtar]) : '';
        if ($tarih !== '') {
            $sonuc[$anahtar] = $tarih;
        }
    }
    return $sonuc;
}

/* ===================== YAŞ FONKSİYONLARI ===================== */

/* Yıl ve ayı toplam aya çevirir: (2, 3) → 27 */
function toplamAy($yil, $ay)
{
    return (int)$yil * 12 + (int)$ay;
}

/* Kayıttaki yaşı ay cinsinden döndürür. Eski kayıtlarda 'yas' (yıl) varsa aya çevrilir. */
function yasAyGetir($hayvan)
{
    if (isset($hayvan['yasAy'])) {
        return (int)$hayvan['yasAy'];
    }
    return isset($hayvan['yas']) ? (int)$hayvan['yas'] * 12 : 0;
}

/* Ayı okunur yaşa çevirir: 27 → "2 yıl 3 ay", 8 → "8 aylık", 24 → "2 yaşında" */
function yasYaz($toplamAy)
{
    $yil = intdiv($toplamAy, 12);
    $ay  = $toplamAy % 12;
    if ($yil === 0) {
        return $ay . ' aylık';
    } elseif ($ay === 0) {
        return $yil . ' yaşında';
    }
    return $yil . ' yıl ' . $ay . ' ay';
}

/* Yaşa göre dönem: yavru (< 1 yıl), genç (1–2 yıl), yetişkin (3–7 yıl), yaşlı (8+ yıl) */
function yasDonemi($toplamAy)
{
    if ($toplamAy < 12) {
        return 'Yavru';
    } elseif ($toplamAy < 36) {
        return 'Genç';
    } elseif ($toplamAy < 96) {
        return 'Yetişkin';
    }
    return 'Yaşlı';
}

/* ===================== GÖRÜŞME VE SAHİPLENME FONKSİYONLARI ===================== */

/* Hayvanın görüşme listesini döndürür (alan yoksa boş dizi). */
function gorusmeleriGetir($hayvan)
{
    return isset($hayvan['gorusmeler']) ? $hayvan['gorusmeler'] : [];
}

/* Hayvanı sahiplenen kişinin bilgilerini döndürür, yoksa null. */
function sahiplenenGetir($hayvan)
{
    return isset($hayvan['sahiplenen']) ? $hayvan['sahiplenen'] : null;
}

/*
 * Telefon numarası geçerli mi? Boşluk, tire ve parantez temizlendikten sonra
 * sadece rakam kalmalı ve 10 ya da 11 haneli olmalı (5321112233 veya 05321112233).
 */
function telefonGecerliMi($telefon)
{
    $rakamlar = str_replace([' ', '-', '(', ')'], '', $telefon);
    return ctype_digit($rakamlar) && (strlen($rakamlar) === 10 || strlen($rakamlar) === 11);
}

/* Görüşme formunu kontrol eder, hata mesajlarını döndürür. */
function gorusmeDogrula($veri)
{
    global $GORUSME_SONUCLARI;
    $hatalar = [];
    if ($veri['ad'] === '') {
        $hatalar[] = 'Görüşen kişinin adı boş bırakılamaz.';
    } elseif (mb_strlen($veri['ad']) < 3) {
        $hatalar[] = 'Görüşen kişinin adı en az 3 karakter olmalıdır.';
    }
    if ($veri['telefon'] === '') {
        $hatalar[] = 'Telefon numarası boş bırakılamaz.';
    } elseif (!telefonGecerliMi($veri['telefon'])) {
        $hatalar[] = 'Telefon numarası 10 veya 11 haneli olmalıdır (ör. 0532 111 22 33).';
    }
    if ($veri['tarih'] === '') {
        $hatalar[] = 'Görüşme tarihi boş bırakılamaz.';
    } elseif (!tarihGecerliMi($veri['tarih'])) {
        $hatalar[] = 'Görüşme tarihi geçerli olmalı ve bugünden ileri olamaz.';
    }
    if (!in_array($veri['sonuc'], $GORUSME_SONUCLARI)) {
        $hatalar[] = 'Lütfen görüşme sonucunu seçiniz.';
    }
    if (mb_strlen($veri['not']) > 200) {
        $hatalar[] = 'Not en fazla 200 karakter olabilir.';
    }
    return $hatalar;
}

/*
 * Hayvana yeni görüşme ekler.
 * Hayvan "Yuva arıyor" durumundaysa otomatik olarak "Görüşülüyor" olur.
 */
function gorusmeEkle($hayvanId, $veri)
{
    if (!isset($_SESSION['hayvanlar'][$hayvanId])) {
        return false;
    }
    if (!isset($_SESSION['sonGorusmeId'])) {
        $_SESSION['sonGorusmeId'] = 0;
    }
    $_SESSION['sonGorusmeId']++;

    $_SESSION['hayvanlar'][$hayvanId]['gorusmeler'][] = [
        'id'      => $_SESSION['sonGorusmeId'],
        'ad'      => $veri['ad'],
        'telefon' => $veri['telefon'],
        'tarih'   => $veri['tarih'],
        'sonuc'   => $veri['sonuc'],
        'not'     => $veri['not'],
    ];

    if ($_SESSION['hayvanlar'][$hayvanId]['durum'] === 'Yuva arıyor') {
        $_SESSION['hayvanlar'][$hayvanId]['durum'] = 'Görüşülüyor';
    }
    return true;
}

/* Hayvanın görüşme listesinden id'si verilen görüşmeyi siler. */
function gorusmeSil($hayvanId, $gorusmeId)
{
    if (!isset($_SESSION['hayvanlar'][$hayvanId])) {
        return false;
    }
    $liste = gorusmeleriGetir($_SESSION['hayvanlar'][$hayvanId]);
    foreach ($liste as $sira => $gorusme) {
        if ($gorusme['id'] === $gorusmeId) {
            unset($liste[$sira]);
            $_SESSION['hayvanlar'][$hayvanId]['gorusmeler'] = array_values($liste); // sıra numaralarını düzelt
            return true;
        }
    }
    return false;
}

/* Sahiplenme formunu kontrol eder, hata mesajlarını döndürür. */
function sahiplenmeDogrula($veri)
{
    $hatalar = [];
    if ($veri['adSoyad'] === '') {
        $hatalar[] = 'Sahiplenen kişinin adı soyadı boş bırakılamaz.';
    } elseif (mb_strlen($veri['adSoyad']) < 5 || strpos($veri['adSoyad'], ' ') === false) {
        $hatalar[] = 'Lütfen ad ve soyadı birlikte yazınız (ör. Ayşe Yılmaz).';
    }
    if ($veri['telefon'] === '') {
        $hatalar[] = 'Telefon numarası boş bırakılamaz.';
    } elseif (!telefonGecerliMi($veri['telefon'])) {
        $hatalar[] = 'Telefon numarası 10 veya 11 haneli olmalıdır (ör. 0532 111 22 33).';
    }
    // E-posta isteğe bağlı; yazıldıysa geçerli biçimde olmalı
    if ($veri['eposta'] !== '' && filter_var($veri['eposta'], FILTER_VALIDATE_EMAIL) === false) {
        $hatalar[] = 'E-posta adresi geçerli değil (ör. ad@ornek.com).';
    }
    if ($veri['sehir'] === '') {
        $hatalar[] = 'Sahiplenen kişinin şehri boş bırakılamaz.';
    }
    if ($veri['adres'] === '') {
        $hatalar[] = 'Adres boş bırakılamaz.';
    } elseif (mb_strlen($veri['adres']) < 10) {
        $hatalar[] = 'Adres en az 10 karakter olmalıdır.';
    }
    if ($veri['tarih'] === '') {
        $hatalar[] = 'Sahiplenme tarihi boş bırakılamaz.';
    } elseif (!tarihGecerliMi($veri['tarih'])) {
        $hatalar[] = 'Sahiplenme tarihi geçerli olmalı ve bugünden ileri olamaz.';
    }
    if (mb_strlen($veri['not']) > 200) {
        $hatalar[] = 'Not en fazla 200 karakter olabilir.';
    }
    return $hatalar;
}

/* Sahiplenen bilgisini kaydeder ve hayvanın durumunu "Sahiplendirildi" yapar. */
function sahiplendir($hayvanId, $veri)
{
    if (!isset($_SESSION['hayvanlar'][$hayvanId])) {
        return false;
    }
    $_SESSION['hayvanlar'][$hayvanId]['sahiplenen'] = [
        'adSoyad' => $veri['adSoyad'],
        'telefon' => $veri['telefon'],
        'eposta'  => $veri['eposta'],
        'sehir'   => sehirDuzenle($veri['sehir']),
        'adres'   => $veri['adres'],
        'tarih'   => $veri['tarih'],
        'not'     => $veri['not'],
    ];
    $_SESSION['hayvanlar'][$hayvanId]['durum'] = 'Sahiplendirildi';
    return true;
}

/* Sahiplenmeyi iptal eder (ör. hayvan geri döndü). Görüşme varsa "Görüşülüyor", yoksa "Yuva arıyor" olur. */
function sahiplenmeIptal($hayvanId)
{
    if (!isset($_SESSION['hayvanlar'][$hayvanId])) {
        return false;
    }
    $hayvan = $_SESSION['hayvanlar'][$hayvanId];
    $_SESSION['hayvanlar'][$hayvanId]['sahiplenen'] = null;
    $_SESSION['hayvanlar'][$hayvanId]['durum'] = count(gorusmeleriGetir($hayvan)) > 0 ? 'Görüşülüyor' : 'Yuva arıyor';
    return true;
}

/*
 * Bütün hayvanlardaki görüşmeleri tek listede toplar (kişiler sayfası için).
 * Her satıra hangi hayvanla görüşüldüğü de eklenir. En yeni görüşme en üstte.
 */
function tumGorusmeler($liste)
{
    $sonuc = [];
    foreach ($liste as $hayvan) {
        foreach (gorusmeleriGetir($hayvan) as $gorusme) {
            $gorusme['hayvanId']  = $hayvan['id'];
            $gorusme['hayvanAd']  = $hayvan['ad'];
            $gorusme['hayvanTur'] = $hayvan['tur'];
            $sonuc[] = $gorusme;
        }
    }
    usort($sonuc, function ($a, $b) { return strcmp($b['tarih'], $a['tarih']); });
    return $sonuc;
}

/* Bütün sahiplenenleri hayvan bilgisiyle birlikte tek listede toplar. En yeni en üstte. */
function tumSahiplenenler($liste)
{
    $sonuc = [];
    foreach ($liste as $hayvan) {
        $sahip = sahiplenenGetir($hayvan);
        if ($sahip !== null) {
            $sahip['hayvanId']  = $hayvan['id'];
            $sahip['hayvanAd']  = $hayvan['ad'];
            $sahip['hayvanTur'] = $hayvan['tur'];
            $sonuc[] = $sahip;
        }
    }
    usort($sonuc, function ($a, $b) { return strcmp($b['tarih'], $a['tarih']); });
    return $sonuc;
}

/* Görüşme sonucuna göre CSS sınıfı döndürür. */
function sonucSinifi($sonuc)
{
    if ($sonuc === 'Olumlu') {
        return 'sonuc-olumlu';
    } elseif ($sonuc === 'Düşünüyor') {
        return 'sonuc-dusunuyor';
    }
    return 'sonuc-olumsuz';
}

/* Belirli aşı durumundaki hayvan sayısını hesaplar. */
function asiSay($liste, $asi)
{
    $sayac = 0;
    foreach ($liste as $hayvan) {
        if (asiDurumu($hayvan) === $asi) {
            $sayac++;
        }
    }
    return $sayac;
}

/* Aşı durumuna göre CSS sınıfı döndürür (etiket rengi için). */
function asiSinifi($asi)
{
    if ($asi === 'Aşıları tam') {
        return 'asi-tam';
    } elseif ($asi === 'Kısmen aşılı') {
        return 'asi-kismen';
    } elseif ($asi === 'Aşısız') {
        return 'asi-yok';
    } elseif ($asi === 'Aşı gerekmiyor') {
        return 'asi-gerekmiyor';
    }
    return 'asi-bilinmiyor';
}

/* Aşı durumuna göre simge döndürür. */
function asiSimgesi($asi)
{
    if ($asi === 'Aşıları tam') {
        return '✅';
    } elseif ($asi === 'Kısmen aşılı') {
        return '⏳';
    } elseif ($asi === 'Aşısız') {
        return '❌';
    } elseif ($asi === 'Aşı gerekmiyor') {
        return '➖';
    }
    return '❔';
}

/* ===================== BAKIM TAKVİMİ FONKSİYONLARI ===================== */

/* Bugünden $gun gün önceki tarihi "YYYY-AA-GG" biçiminde döndürür (örnek veriler için). */
function gunOnce($gun)
{
    return date('Y-m-d', strtotime("-$gun days"));
}

/*
 * Tarih geçerli mi? Boş tarih geçerlidir ("yapılmadı" anlamına gelir).
 * Doluysa YYYY-AA-GG biçiminde, gerçek bir tarih (checkdate) ve bugünden ileri olmamalı.
 */
function tarihGecerliMi($tarih)
{
    if ($tarih === '') {
        return true;
    }
    $parcalar = explode('-', $tarih);
    if (count($parcalar) !== 3) {
        return false;
    }
    list($yil, $ay, $gun) = $parcalar;
    if (!ctype_digit($yil) || !ctype_digit($ay) || !ctype_digit($gun)) {
        return false;
    }
    if (!checkdate((int)$ay, (int)$gun, (int)$yil)) {
        return false; // 31 Şubat gibi olmayan tarihler
    }
    return $tarih <= date('Y-m-d'); // gelecekteki tarih kabul edilmez
}

/* Kayıttaki bakım tarihini döndürür; alan yoksa boş metin döner. */
function bakimTarihi($hayvan, $alan)
{
    return isset($hayvan[$alan]) ? $hayvan[$alan] : '';
}

/* Tarihin üzerinden kaç gün geçtiğini hesaplar. */
function gecenGun($tarih)
{
    $fark = strtotime(date('Y-m-d')) - strtotime($tarih);
    return (int)round($fark / 86400); // 86400 = bir gündeki saniye sayısı
}

/* "2026-11-08" tarihini "08.11.2026" biçiminde yazar. */
function tarihYaz($tarih)
{
    if ($tarih === '') {
        return '—';
    }
    return date('d.m.Y', strtotime($tarih));
}

/* Gün sayısını okunur metne çevirir: "Bugün", "12 gün önce", "3 ay önce", "1 yıl önce". */
function neZamanOnce($tarih)
{
    $gun = gecenGun($tarih);
    if ($gun === 0) {
        return 'Bugün';
    } elseif ($gun < 30) {
        return $gun . ' gün önce';
    } elseif ($gun < 365) {
        return floor($gun / 30) . ' ay önce';
    }
    return floor($gun / 365) . ' yıl önce';
}

/*
 * Bir hayvanın tek bir bakım türündeki durumunu hesaplar.
 * Dönen dizi: ['kod' => guncel|gecikmis|yapilmadi|yapildi, 'yazi' => ekranda görünen yazı, 'sonraki' => tarih veya '']
 */
function bakimDurumu($hayvan, $alan)
{
    $tarih = bakimTarihi($hayvan, $alan);

    if ($tarih === '') {
        return ['kod' => 'yapilmadi', 'yazi' => 'Yapılmadı', 'sonraki' => ''];
    }

    // Kısırlaştırma bir kez yapılır, tekrarı yoktur
    if ($alan === 'kisir') {
        return ['kod' => 'yapildi', 'yazi' => 'Yapıldı', 'sonraki' => ''];
    }

    $aralik  = ($alan === 'parazit') ? PARAZIT_ARALIGI : KONTROL_ARALIGI;
    $sonraki = date('Y-m-d', strtotime($tarih . " +$aralik days"));

    if (gecenGun($tarih) > $aralik) {
        return ['kod' => 'gecikmis', 'yazi' => 'Zamanı geçti', 'sonraki' => $sonraki];
    }
    return ['kod' => 'guncel', 'yazi' => 'Güncel', 'sonraki' => $sonraki];
}

/* Bir bakımın "tamam" sayılıp sayılmadığı: güncel ya da (kısırlaştırmada) yapıldı. */
function bakimTamamMi($hayvan, $alan)
{
    $kod = bakimDurumu($hayvan, $alan)['kod'];
    return $kod === 'guncel' || $kod === 'yapildi';
}

/* Her bakım türü için kaç hayvanın bakımının tamam olduğunu sayar. */
function bakimOzeti($liste)
{
    global $BAKIMLAR;
    $ozet = [];
    foreach ($BAKIMLAR as $alan => $bilgi) {
        $ozet[$alan] = ['tamam' => 0, 'gecikmis' => 0, 'yapilmadi' => 0];
    }
    foreach ($liste as $hayvan) {
        foreach ($BAKIMLAR as $alan => $bilgi) {
            $kod = bakimDurumu($hayvan, $alan)['kod'];
            if ($kod === 'guncel' || $kod === 'yapildi') {
                $ozet[$alan]['tamam']++;
            } else {
                $ozet[$alan][$kod]++;
            }
        }
    }
    return $ozet;
}

/* Seçilen bakım türü tamam OLMAYAN hayvanları döndürür (bakım takvimi filtresi). */
function bakimGerekenler($liste, $alan)
{
    global $BAKIMLAR;
    if (!isset($BAKIMLAR[$alan])) {
        return $liste; // filtre yoksa hepsi
    }
    $sonuc = [];
    foreach ($liste as $hayvan) {
        if (!bakimTamamMi($hayvan, $alan)) {
            $sonuc[] = $hayvan;
        }
    }
    return $sonuc;
}

/* Belirli durumdaki kayıt sayısını hesaplar (özet sayaçları için). */
function durumSay($liste, $durum)
{
    $sayac = 0;
    foreach ($liste as $hayvan) {
        if ($hayvan['durum'] === $durum) {
            $sayac++;
        }
    }
    return $sayac;
}

/* Kullanıcı girdisini HTML'de güvenle göstermek için htmlspecialchars kullanır. */
function guvenli($metin)
{
    return htmlspecialchars($metin, ENT_QUOTES, 'UTF-8');
}

/* Duruma göre CSS sınıfı döndürür (etiket rengi için). */
function durumSinifi($durum)
{
    if ($durum === 'Yuva arıyor') {
        return 'etiket-ariyor';
    } elseif ($durum === 'Görüşülüyor') {
        return 'etiket-gorusuluyor';
    } else {
        return 'etiket-sahiplendi';
    }
}

/* Türe göre küçük bir simge döndürür. */
function turSimgesi($tur)
{
    switch ($tur) {
        case 'Kedi':   return '🐱';
        case 'Köpek':  return '🐶';
        case 'Kuş':    return '🐦';
        case 'Tavşan': return '🐰';
        case 'Balık':  return '🐟';
        case 'Hamster':     return '🐹';
        case 'Kaplumbağa':  return '🐢';
        case 'Gine domuzu': return '🐹';
        case 'Kirpi':       return '🦔';
        case 'Şinşilla':    return '🐭';
        case 'Ferret':      return '🦦';
        default:       return '🐾';
    }
}

/*
 * Hayvanın fotoğrafını döndürür. Fotoğraf seçilmemişse ya da dosya yoksa null döner
 * (o zaman kartta türün emoji çizimi gösterilir).
 * Dönen dizi: ['dosya' => 'assets/img/foto/pamuk.jpg', 'etiket' => ..., 'fotografci' => ..., 'sayfa' => ...]
 */
function hayvanFotosu($hayvan)
{
    global $FOTO_KAYNAKLARI;
    $anahtar = isset($hayvan['foto']) ? $hayvan['foto'] : '';
    if ($anahtar === '' || !isset($FOTO_KAYNAKLARI[$anahtar])) {
        return null;
    }
    $dosya = 'assets/img/foto/' . $anahtar . '.jpg';
    if (!file_exists(__DIR__ . '/' . $dosya)) {
        return null;
    }
    return ['dosya' => $dosya] + $FOTO_KAYNAKLARI[$anahtar];
}

/* Türe göre CSS sınıfı döndürür (kartın üst rengini belirler). */
function turSinifi($tur)
{
    switch ($tur) {
        case 'Kedi':   return 'tur-kedi';
        case 'Köpek':  return 'tur-kopek';
        case 'Kuş':    return 'tur-kus';
        case 'Tavşan': return 'tur-tavsan';
        case 'Balık':  return 'tur-balik';
        case 'Hamster':
        case 'Gine domuzu':
        case 'Kirpi':
        case 'Şinşilla':
        case 'Ferret': return 'tur-kemirgen';
        default:       return 'tur-diger';
    }
}

/* Bir sonraki sayfada gösterilecek tek seferlik mesajı kaydeder. */
function mesajKaydet($metin, $tip = 'basarili')
{
    $_SESSION['mesaj'] = ['metin' => $metin, 'tip' => $tip];
}

/* Kayıtlı mesajı bir kez gösterir ve siler. */
function mesajGoster()
{
    if (isset($_SESSION['mesaj'])) {
        $m = $_SESSION['mesaj'];
        unset($_SESSION['mesaj']);
        echo '<div class="mesaj mesaj-' . guvenli($m['tip']) . '">' . guvenli($m['metin']) . '</div>';
    }
}

// Bu dosya her çağrıldığında örnek kayıtların yüklü olduğundan emin oluyoruz
ornekKayitlariYukle();
