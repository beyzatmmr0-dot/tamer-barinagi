<?php
/*
 * duzenle.php — İlan düzenleme (güncelleme) sayfası
 * 1) Sayfa ilk açıldığında id adres çubuğundan (GET) gelir, kayıt bulunur ve form doldurulur.
 * 2) Form gönderildiğinde id gizli alanla (POST) gelir, veriler doğrulanır ve kayıt güncellenir.
 */
require_once 'functions.php';

$hatalar = [];

// id önce POST'ta, yoksa GET'te aranır
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
} else {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
}

$hayvan = hayvanBul($id);

// Kayıt yoksa ana sayfaya dön
if ($hayvan === null) {
    mesajKaydet('Düzenlenecek ilan bulunamadı.', 'hata');
    header('Location: index.php');
    exit;
}

// Form ilk açıldığında mevcut bilgilerle dolu gelir
$veri = [
    'ad'       => $hayvan['ad'],
    'tur'      => $hayvan['tur'],
    'yasYil'   => (string)intdiv(yasAyGetir($hayvan), 12), // toplam ay → yıl
    'yasAy'    => (string)(yasAyGetir($hayvan) % 12),      // kalan ay
    'cinsiyet' => $hayvan['cinsiyet'],
    'cins'     => cinsiGetir($hayvan),
    'sehir'    => $hayvan['sehir'],
    'aciklama' => $hayvan['aciklama'],
    'durum'    => $hayvan['durum'],
    'foto'     => isset($hayvan['foto']) ? $hayvan['foto'] : '',
    'parazit'  => bakimTarihi($hayvan, 'parazit'),
    'kisir'    => bakimTarihi($hayvan, 'kisir'),
    'kontrol'  => bakimTarihi($hayvan, 'kontrol'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($veri as $alan => $eskiDeger) {
        $veri[$alan] = isset($_POST[$alan]) ? trim((string)$_POST[$alan]) : '';
    }
    $veri['asilar'] = asilariFormdanAl($veri['tur']);

    $hatalar = formuDogrula($veri);

    if (count($hatalar) === 0) {
        hayvanGuncelle($id, $veri);
        mesajKaydet($veri['ad'] . ' adlı ilan güncellendi.');
        header('Location: detay.php?id=' . $id);
        exit;
    }
} else {
    // Form ilk açıldığında yapılmış aşılar tarihleriyle dolu gelsin
    $veri['asilar'] = yapilanAsilar($hayvan);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İlanı Düzenle — Tamer Barınağı</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?php include 'tema_head.php'; ?>
</head>
<body>

<?php $aktifSayfa = ''; include 'ust_alan.php'; ?>

<main class="kapsayici form-duzen">
<div class="form-sol">

    <div class="form-baslik">
        <span class="form-simge"><?= turSimgesi($hayvan['tur']) ?></span>
        <div>
            <h1>İlanı düzenle: <?= guvenli($hayvan['ad']) ?></h1>
            <p class="alt-baslik">Bilgileri güncelleyip kaydet. Sahiplendirildiyse durumu değiştirmeyi unutma.</p>
        </div>
    </div>

    <?php if (count($hatalar) > 0): ?>
        <div class="mesaj mesaj-hata">
            <strong>Lütfen aşağıdaki hataları düzeltin:</strong>
            <ul>
                <?php foreach ($hatalar as $hata): ?>
                    <li><?= guvenli($hata) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="duzenle.php" class="form" novalidate>
        <!-- Hangi kaydın güncelleneceğini bildiren gizli alan -->
        <input type="hidden" name="id" value="<?= (int)$id ?>">

        <?php include 'form_alanlari.php'; ?>

        <div class="form-butonlar">
            <button type="submit" class="buton">Değişiklikleri Kaydet</button>
            <a href="detay.php?id=<?= (int)$id ?>" class="buton buton-ikincil">Vazgeç</a>
        </div>
    </form>
</div>

    <aside class="ipucu">
        <img src="assets/img/hero.svg" alt="">
        <h3>İlan bilgileri</h3>
        <ul>
            <li><i>🆔</i> İlan numarası: <?= (int)$hayvan['id'] ?></li>
            <li><i>📅</i> İlan tarihi: <?= guvenli($hayvan['tarih']) ?></li>
            <li><i>📌</i> Şu anki durum: <?= guvenli($hayvan['durum']) ?></li>
            <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                <?php $bd = bakimDurumu($hayvan, $alan); ?>
                <li><i><?= $bilgi['simge'] ?></i> <?= guvenli($bilgi['baslik']) ?>: <?= tarihYaz(bakimTarihi($hayvan, $alan)) ?> (<?= $bd['yazi'] ?>)</li>
            <?php endforeach; ?>
            <li><i>💉</i> Aşı durumu: <?= asiSimgesi(asiDurumu($hayvan)) ?> <?= guvenli(asiDurumu($hayvan)) ?></li>
            <li><i>💬</i> Görüşme sayısı: <?= count(gorusmeleriGetir($hayvan)) ?></li>
            <li><i>✏️</i> İlan tarihi düzenlemede değişmez. Görüşmeler ve sahiplenen bilgisi <a href="detay.php?id=<?= (int)$hayvan['id'] ?>">detay sayfasından</a> yönetilir.</li>
        </ul>
    </aside>

</main>

<footer class="alt">
    <strong>🐾 Tamer Barınağı</strong>
    <p>Her pati bir yuvayı hak eder.</p>
    <small>İnternet Programcılığı I PHP Projesi · 2026</small>
    <small class="foto-not">Hayvan fotoğrafları <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash</a> üzerinden ücretsiz lisansla kullanılmıştır. Fotoğrafçı bilgisi hayvanın detay sayfasında.</small>
</footer>

</body>
</html>
