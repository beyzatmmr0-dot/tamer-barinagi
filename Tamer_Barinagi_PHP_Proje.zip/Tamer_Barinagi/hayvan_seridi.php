<?php
/*
 * hayvan_seridi.php — Sitenin en üstündeki hayvan şeridi
 * Bütün sayfalarda <header>'dan önce include edilir.
 *
 * Her hayvanın iki resmi var: normal hâli ve mutlu hâli.
 * Fare hayvanın üstüne gelince CSS ile normal resim gizlenir, mutlu resim görünür
 * ve hayvanın "sesi" konuşma balonunda çıkar. Hayvanlar ayrıca kendi kendine
 * hafifçe zıplar ve göz kırpar (CSS animasyonu, SVG dosyalarının içinde).
 * Hayvana tıklayınca ana sayfada o türdeki ilanlar filtrelenir (GET).
 */
$SERIT_HAYVANLARI = [
    ['dosya' => 'kedi',       'foto' => 'pamuk',   'ad' => 'Kedi',        'ses' => 'Miyav! 💜',      'tur' => 'Kedi'],
    ['dosya' => 'kopek',      'foto' => 'karabas', 'ad' => 'Köpek',       'ses' => 'Hav hav! 🦴',    'tur' => 'Köpek'],
    ['dosya' => 'tavsan',     'foto' => 'findik',  'ad' => 'Tavşan',      'ses' => 'Havuç var mı? 🥕', 'tur' => 'Tavşan'],
    ['dosya' => 'kus',        'foto' => 'mavis',   'ad' => 'Kuş',         'ses' => 'Cik cik! 🎵',    'tur' => 'Kuş'],
    ['dosya' => 'balik',      'foto' => 'altin',   'ad' => 'Balık',       'ses' => 'Blup blup! 🫧',  'tur' => 'Balık'],
    ['dosya' => 'hamster',    'foto' => 'gidik',   'ad' => 'Hamster',     'ses' => 'Çarkta koşuyorum! 🎡', 'tur' => 'Hamster'],
    ['dosya' => 'ginedomuzu', 'foto' => 'zipzip',  'ad' => 'Gine domuzu', 'ses' => 'Vik vik! 🥬',    'tur' => 'Gine domuzu'],
    ['dosya' => 'kirpi',      'foto' => 'kirpi',   'ad' => 'Kirpi',       'ses' => 'Dikenlerim yumuşak! 🌿', 'tur' => 'Kirpi'],
    ['dosya' => 'sinsilla',   'foto' => 'tuylu',   'ad' => 'Şinşilla',    'ses' => 'Toz banyosu zamanı! ✨', 'tur' => 'Şinşilla'],
    ['dosya' => 'ferret',     'foto' => 'cin',     'ad' => 'Ferret',      'ses' => 'Oyun oynayalım! 🎈', 'tur' => 'Ferret'],
    ['dosya' => 'kaplumbaga', 'foto' => 'tosbik',  'ad' => 'Kaplumbağa',  'ses' => 'Yavaş ama geliyorum! 🐢', 'tur' => 'Kaplumbağa'],
];
?>
<?php
/*
 * Şerit sonsuz döngüyle soldan sağa kayar. Kesintisiz görünmesi için liste iki kez yazdırılır:
 * ikinci kopya ekran okuyuculardan gizlenir (aria-hidden) ve Tab ile seçilemez.
 */
?>
<div class="hayvan-serit" aria-label="Hayvan çeşitleri">
    <div class="hs-kaydir">
        <div class="hs-iz">
        <?php foreach ([false, true] as $kopya): ?>
            <?php foreach ($SERIT_HAYVANLARI as $sira => $h): ?>
                <!-- Her hayvan sırayla farklı zamanda zıplasın diye gecikme veriliyor -->
                <a href="index.php?tur=<?= urlencode($h['tur']) ?>#ilanlar" class="hs-hayvan"
                   style="--gecikme: <?= $sira * 0.35 ?>s" title="<?= guvenli($h['ad']) ?> ilanlarını göster"
                   <?= $kopya ? 'aria-hidden="true" tabindex="-1"' : '' ?>>
                    <span class="hs-balon"><?= guvenli($h['ses']) ?></span>
                    <span class="hs-resimler">
                        <img class="hs-normal" src="assets/img/hayvanlar/<?= $h['dosya'] ?>.svg" alt="<?= $kopya ? '' : guvenli($h['ad']) ?>">
                        <img class="hs-mutlu" src="assets/img/hayvanlar/<?= $h['dosya'] ?>_mutlu.svg" alt="" aria-hidden="true">
                    </span>
                    <?php if (file_exists(__DIR__ . '/assets/img/foto/' . $h['foto'] . '.jpg')): ?>
                        <img class="hs-foto" src="assets/img/foto/<?= $h['foto'] ?>.jpg" alt="<?= $kopya ? '' : guvenli($h['ad']) . ' fotoğrafı' ?>" loading="lazy">
                    <?php endif; ?>
                    <span class="hs-ad"><?= guvenli($h['ad']) ?></span>
                </a>
            <?php endforeach; ?>
        <?php endforeach; ?>
        </div>
    </div>
</div>
