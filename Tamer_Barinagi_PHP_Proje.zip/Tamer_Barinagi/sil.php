<?php
/*
 * sil.php — Kayıt silme işlemi
 * Sadece POST isteğini kabul eder. Ekranda bir şey göstermez;
 * işlemi yapar, mesajı kaydeder ve ana sayfaya geri döner.
 */
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Adres çubuğundan doğrudan açılırsa silme yapılmaz
    mesajKaydet('Silme işlemi yalnızca form üzerinden yapılabilir.', 'hata');
    header('Location: index.php');
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

// Silmeden önce adı alıyoruz ki mesajda gösterebilelim
$hayvanlar = hayvanlariGetir();
$ad = isset($hayvanlar[$id]) ? $hayvanlar[$id]['ad'] : '';

if (hayvanSil($id)) {
    mesajKaydet($ad . ' adlı ilan silindi.');
} else {
    mesajKaydet('Silinecek ilan bulunamadı.', 'hata');
}

header('Location: index.php');
exit;
