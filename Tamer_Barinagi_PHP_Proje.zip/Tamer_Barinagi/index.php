<?php
/*
 * index.php — Ana sayfa
 * Özet sayaçları, filtreleme formunu (GET) ve hayvan listesini gösterir.
 */
require_once 'functions.php';

$tumHayvanlar = hayvanlariGetir();

// Filtre değerleri adres çubuğundan (GET) okunuyor. Yoksa boş = hepsi.
$secilenTur   = isset($_GET['tur'])   ? $_GET['tur']   : '';
$secilenDurum = isset($_GET['durum']) ? $_GET['durum'] : '';
$aramaKelime  = isset($_GET['ara'])   ? trim($_GET['ara']) : '';
$siralama     = isset($_GET['sirala']) ? $_GET['sirala'] : 'yeni';
$secilenSehir = isset($_GET['sehir']) ? $_GET['sehir'] : '';
$secilenAsi   = isset($_GET['asi'])   ? $_GET['asi']   : '';

// Sırasıyla: filtrele → ara → sırala
$listelenecek = hayvanlariFiltrele($tumHayvanlar, $secilenTur, $secilenDurum, $secilenSehir, $secilenAsi);
$listelenecek = hayvanlariAra($listelenecek, $aramaKelime);
$listelenecek = hayvanlariSirala($listelenecek, $siralama);

// Sıralama seçenekleri (değer => ekranda görünen yazı)
$SIRALAMALAR = ['yeni' => 'En yeni ilan', 'eski' => 'En eski ilan', 'genc' => 'En genç', 'ad' => 'İsme göre (A-Z)'];

// İstatistik: türlere göre ilan sayıları ve grafik için en büyük değer
$turSayilari = turleriSay($tumHayvanlar);
$enBuyuk = max(1, max($turSayilari)); // 0'a bölmeyi önlemek için en az 1

// Şehirlere göre ilan sayıları (en çok ilanı olan şehir en başta)
$sehirSayilari = sehirleriSay($tumHayvanlar);
$sehirAdlari   = array_keys($sehirSayilari);
sort($sehirAdlari); // filtre listesinde alfabetik görünsün

// Sağlık rehberi kartları (başlık, simge, açıklama) — foreach ile ekrana basılır
$SAGLIK_KARTLARI = [
    ['simge' => '💉', 'baslik' => 'Aşılar',          'metin' => 'Karma ve kuduz aşıları yavruluk döneminde başlar, veteriner hekimin belirlediği takvimle tekrarlanır.'],
    ['simge' => '🐛', 'baslik' => 'Parazit bakımı',  'metin' => 'İç ve dış parazit uygulamaları (pire, kene, kurt) düzenli aralıklarla yapılmalıdır.'],
    ['simge' => '✂️', 'baslik' => 'Kısırlaştırma',  'metin' => 'Sokakta kontrolsüz çoğalmayı önler ve bazı hastalık risklerini azaltır.'],
    ['simge' => '🩺', 'baslik' => 'Düzenli kontrol', 'metin' => 'Sahiplendikten sonra ilk iş bir veteriner kontrolü; sonrasında yılda en az bir kez.'],
];

// Türe göre temel aşılar: functions.php'deki $ASI_LISTESI kullanılır (tek yerden yönetilir)
$TEMEL_ASILAR = $ASI_LISTESI;

// Görüşme ve sahiplenme sayıları (bilgi şeridi için)
$gorusmeSayisi   = count(tumGorusmeler($tumHayvanlar));
$sahiplenenSayisi = count(tumSahiplenenler($tumHayvanlar));

// Üstteki bilgi şeridi için canlı sayılar
$sehirSayisi = count($sehirSayilari);
$turSayisi   = 0;
foreach ($turSayilari as $sayi) {
    if ($sayi > 0) {
        $turSayisi++; // en az bir ilanı olan türleri say
    }
}

// Aşı durumu sayıları (sağlık bölümü ve bilgi şeridi için)
$asiSayilari = [];
foreach ($ASI_DURUMLARI as $asiAdi) {
    $asiSayilari[$asiAdi] = asiSay($tumHayvanlar, $asiAdi);
}
// Aşı tablosunda hayvanlar isme göre sıralı görünsün
$asiTablosu = hayvanlariSirala($tumHayvanlar, 'ad');

// Özet bilgiler
$toplam      = count($tumHayvanlar);
$ariyor      = durumSay($tumHayvanlar, 'Yuva arıyor');
$gorusuluyor = durumSay($tumHayvanlar, 'Görüşülüyor');
$sahiplendi  = durumSay($tumHayvanlar, 'Sahiplendirildi');

// ---- Bakım takvimi ----
$bakimOzeti   = bakimOzeti($tumHayvanlar);
$secilenBakim = isset($_GET['bakim']) ? $_GET['bakim'] : '';
if (!isset($BAKIMLAR[$secilenBakim])) {
    $secilenBakim = ''; // geçersiz değer gelirse filtreyi kapat
}
$bakimListesi = hayvanlariSirala(bakimGerekenler($tumHayvanlar, $secilenBakim), 'ad');

// Sağlık kartlarına canlı istatistik ve link ekleniyor
// tamam: bakımı güncel olan hayvan sayısı, link: tıklanınca gidilecek yer
$kartIstatistik = [
    ['tamam' => $asiSayilari['Aşıları tam'],     'yazi' => 'hayvanın aşıları tam',          'link' => '#asi-durum'],
    ['tamam' => $bakimOzeti['parazit']['tamam'], 'yazi' => 'hayvanın parazit bakımı güncel', 'link' => 'index.php?bakim=parazit#bakim'],
    ['tamam' => $bakimOzeti['kisir']['tamam'],   'yazi' => 'hayvan kısırlaştırılmış',        'link' => 'index.php?bakim=kisir#bakim'],
    ['tamam' => $bakimOzeti['kontrol']['tamam'], 'yazi' => 'hayvanın kontrolü güncel',       'link' => 'index.php?bakim=kontrol#bakim'],
];
foreach ($SAGLIK_KARTLARI as $no => $kart) {
    $SAGLIK_KARTLARI[$no]['tamam'] = $kartIstatistik[$no]['tamam'];
    $SAGLIK_KARTLARI[$no]['yazi']  = $kartIstatistik[$no]['yazi'];
    $SAGLIK_KARTLARI[$no]['link']  = $kartIstatistik[$no]['link'];
    $SAGLIK_KARTLARI[$no]['oran']  = round($kartIstatistik[$no]['tamam'] / max(1, $toplam) * 100);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tamer Barınağı — Evcil Hayvan Sahiplendirme</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?php include 'tema_head.php'; ?>
</head>
<body>

<?php $aktifSayfa = 'index'; include 'ust_alan.php'; ?>

<main class="kapsayici">

    <section class="tanitim">
        <div class="tanitim-metin">
            <span class="rozet">💛 Sahiplen, satın alma</span>
            <h1>Bir dost, <em>bir yuva</em> bekliyor</h1>
            <p>Tamer Barınağı; kedi, köpek, kuş ve diğer evcil hayvanlar için sahiplendirme ilanlarının
               kaydedildiği ve takip edildiği bir sistemdir. İlan ekleyebilir, türe ve duruma göre
               filtreleyebilir, yuvasını bulan hayvanları takip edebilirsiniz.</p>
            <div class="tanitim-butonlar">
                <a href="#ilanlar" class="buton">İlanları Gör</a>
                <a href="ekle.php" class="buton buton-beyaz">+ İlan Ver</a>
            </div>
        </div>
        <div class="tanitim-gorsel" aria-hidden="true">
            <img src="assets/img/hero.svg" alt="">
            <span class="yuzen y1">🐰</span>
            <span class="yuzen y2">🐦</span>
            <span class="yuzen y3">💕</span>
        </div>
    </section>

    <!-- Kısa özellik şeridi -->
    <!-- Bilgi şeridi: her kart sayfanın ilgili bölümüne götürür. Alt yazılar PHP ile hesaplanır. -->
    <section class="serit">
        <a href="#saglik" class="serit-kart s-saglik">
            <i>🩺</i>
            <span><b>Aşı ve sağlık bilgisi</b><small><?= $asiSayilari['Aşıları tam'] ?> dostun aşıları tam</small></span>
        </a>
        <a href="#sehirler" class="serit-kart s-sehir">
            <i>📍</i>
            <span><b>Şehre göre ilanlar</b><small><?= $sehirSayisi ?> şehirde ilan var</small></span>
        </a>
        <a href="#ilanlar" class="serit-kart s-filtre">
            <i>🔎</i>
            <span><b>Türe ve duruma göre filtre</b><small><?= $turSayisi ?> tür · <?= count($DURUMLAR) ?> durum</small></span>
        </a>
        <a href="kisiler.php" class="serit-kart s-ucretsiz">
            <i>💛</i>
            <span><b>Sahiplenenler &amp; görüşenler</b><small><?= $sahiplenenSayisi ?> sahiplenen · <?= $gorusmeSayisi ?> görüşme</small></span>
        </a>
    </section>

    <?php mesajGoster(); ?>

    <!-- Özet sayaçlar -->
    <!-- Kutular link: tıklanınca o duruma göre filtreleyip ilan listesine iner (GET).
         Seçili olan kutuya "secili" sınıfı eklenir. -->
    <section class="ozet">
        <a href="index.php#ilanlar" class="ozet-kutu <?= $secilenDurum === '' ? 'secili' : '' ?>">
            <i>📋</i><div><span><?= $toplam ?></span>Toplam ilan</div>
        </a>
        <a href="index.php?durum=<?= urlencode('Yuva arıyor') ?>#ilanlar" class="ozet-kutu ariyor <?= $secilenDurum === 'Yuva arıyor' ? 'secili' : '' ?>">
            <i>🏠</i><div><span><?= $ariyor ?></span>Yuva arıyor</div>
        </a>
        <a href="index.php?durum=<?= urlencode('Görüşülüyor') ?>#ilanlar" class="ozet-kutu gorusuluyor <?= $secilenDurum === 'Görüşülüyor' ? 'secili' : '' ?>">
            <i>💬</i><div><span><?= $gorusuluyor ?></span>Görüşülüyor</div>
        </a>
        <a href="index.php?durum=<?= urlencode('Sahiplendirildi') ?>#ilanlar" class="ozet-kutu sahiplendi <?= $secilenDurum === 'Sahiplendirildi' ? 'secili' : '' ?>">
            <i>💚</i><div><span><?= $sahiplendi ?></span>Sahiplendirildi</div>
        </a>
    </section>

    <!-- Nasıl çalışır? -->
    <section class="adimlar">
        <h2 class="bolum-baslik ortali">Nasıl çalışır?</h2>
        <p class="bolum-alt">Üç adımda bir dostu yeni yuvasına kavuştur.</p>
        <div class="adim-liste">
            <div class="adim a1"><b>1</b><i>📝</i><h3>İlanını ekle</h3><p>Hayvanın adını, türünü, yaşını ve hikâyesini yaz.</p></div>
            <div class="adim a2"><b>2</b><i>🔍</i><h3>Filtrele ve bul</h3><p>Türe ve duruma göre ilanları süz, sana uygun dostu bul.</p></div>
            <div class="adim a3"><b>3</b><i>🏡</i><h3>Yuvaya kavuştur</h3><p>Görüşmeleri takip et, sahiplendirilince durumu güncelle.</p></div>
        </div>
    </section>

    <!-- Sağlık rehberi -->
    <section class="saglik" id="saglik">
        <div class="saglik-ust">
            <div>
                <span class="rozet">🩺 Sağlık rehberi</span>
                <h2>Yeni dostunun <em>sağlığı</em> için</h2>
                <p>Sahiplendirmeden önce ve sonra dikkat edilmesi gereken temel sağlık konuları.</p>
            </div>
            <div class="asi-kutulari">
                <?php foreach ($TEMEL_ASILAR as $tur => $asilar): ?>
                    <div class="asi-kutu">
                        <h3><?= turSimgesi($tur) ?> <?= guvenli($tur) ?> için temel aşılar</h3>
                        <ul>
                            <?php foreach ($asilar as $asi): /* anahtar gerekmediği için sadece ad alınır */ ?>
                                <li>✔ <?= guvenli($asi) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="saglik-kartlar">
            <?php foreach ($SAGLIK_KARTLARI as $no => $kart): ?>
                <a href="<?= $kart['link'] ?>" class="saglik-kart sk<?= $no + 1 ?>">
                    <i><?= $kart['simge'] ?></i>
                    <h3><?= guvenli($kart['baslik']) ?></h3>
                    <p><?= guvenli($kart['metin']) ?></p>
                    <div class="kart-istatistik">
                        <div class="ki-ust"><b><?= $kart['tamam'] ?>/<?= $toplam ?></b> <span><?= $kart['yazi'] ?></span></div>
                        <div class="ki-yol"><div style="width: <?= $kart['oran'] ?>%"></div></div>
                    </div>
                    <span class="ki-link">Detayları gör →</span>
                </a>
            <?php endforeach; ?>
        </div>
        <!-- Hangi dostun aşısı var? Sayaçlar + tablo -->
        <div class="asi-durum" id="asi-durum">
            <div class="asi-durum-ust">
                <h3>💉 Hangi dostun aşısı var?</h3>
                <div class="asi-sayaclar">
                    <?php foreach ($asiSayilari as $asiAdi => $sayi): ?>
                        <a href="index.php?asi=<?= urlencode($asiAdi) ?>#ilanlar" class="asi-sayac <?= asiSinifi($asiAdi) ?>">
                            <b><?= $sayi ?></b>
                            <span><?= asiSimgesi($asiAdi) ?> <?= guvenli($asiAdi) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Aşı oranı çubuğu: üç renk yan yana, genişlikleri yüzdeye göre -->
            <div class="asi-cubuk">
                <?php foreach ($asiSayilari as $asiAdi => $sayi): ?>
                    <?php if ($sayi > 0): ?>
                        <div class="<?= asiSinifi($asiAdi) ?>" style="width: <?= round($sayi / max(1, $toplam) * 100) ?>%"
                             title="<?= guvenli($asiAdi) ?>: <?= $sayi ?>"></div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <div class="tablo-kap">
                <table class="asi-tablo">
                    <thead>
                        <tr><th>Dost</th><th>Tür</th><th>Yaş</th><th>Şehir</th><th>Yapılan aşılar</th><th>Aşı durumu</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($asiTablosu as $hayvan): ?>
                            <?php $asi = asiDurumu($hayvan); ?>
                            <tr>
                                <td><span class="tablo-simge"><?= turSimgesi($hayvan['tur']) ?></span> <b><?= guvenli($hayvan['ad']) ?></b></td>
                                <td><?= guvenli($hayvan['tur']) ?></td>
                                <td><?= yasYaz(yasAyGetir($hayvan)) ?></td>
                                <td><?= guvenli($hayvan['sehir']) ?></td>
                                <td>
                                    <?php $gerekliSayi = count(gerekliAsilar($hayvan['tur'])); ?>
                                    <?php if ($gerekliSayi === 0): ?>
                                        —
                                    <?php else: ?>
                                        <?= count(yapilanAsilar($hayvan)) ?>/<?= $gerekliSayi ?>
                                        <?php if (rapelGecenSay($hayvan) > 0): ?>
                                            <span class="rapel-uyari" title="Tekrar (rapel) zamanı geçmiş aşı var">⚠️ rapel</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td><span class="asi-rozet <?= asiSinifi($asi) ?>"><?= asiSimgesi($asi) ?> <?= guvenli($asi) ?></span></td>
                                <td><a href="detay.php?id=<?= (int)$hayvan['id'] ?>#asi-karti" class="tablo-link">Aşı kartı →</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <p class="saglik-not">ℹ️ Bu bilgiler genel bir rehberdir. Aşı takvimini ve tedaviyi her zaman veteriner hekim belirler.</p>
    </section>

    <!-- Bakım takvimi: her hayvanın parazit bakımı, kısırlaştırma ve kontrol tarihleri -->
    <section class="bakim" id="bakim">
        <div class="bakim-baslik">
            <div>
                <span class="rozet">📅 Bakım takvimi</span>
                <h2>Kimin bakımı <em>ne zaman</em> yapıldı?</h2>
                <p>Parazit bakımı yaklaşık <?= PARAZIT_ARALIGI ?> günde, veteriner kontrolü <?= KONTROL_ARALIGI ?> günde bir hatırlatılır.
                   Süresi geçenler "Zamanı geçti" olarak işaretlenir.</p>
            </div>
            <!-- Özet kutuları: her bakım türü için güncel / geçmiş / yapılmadı sayıları -->
            <div class="bakim-ozet">
                <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                    <div class="bo-kutu">
                        <span class="bo-simge"><?= $bilgi['simge'] ?></span>
                        <div>
                            <b><?= guvenli($bilgi['baslik']) ?></b>
                            <small>
                                <span class="yesil"><?= $bakimOzeti[$alan]['tamam'] ?> tamam</span>
                                <?php if ($bakimOzeti[$alan]['gecikmis'] > 0): ?>
                                    · <span class="turuncu"><?= $bakimOzeti[$alan]['gecikmis'] ?> geçmiş</span>
                                <?php endif; ?>
                                · <span class="pembe"><?= $bakimOzeti[$alan]['yapilmadi'] ?> yapılmadı</span>
                            </small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Filtre sekmeleri (GET): sadece o bakımı eksik olanları gösterir -->
        <div class="bakim-sekmeler">
            <a href="index.php#bakim" class="<?= $secilenBakim === '' ? 'secili' : '' ?>">🐾 Hepsi (<?= $toplam ?>)</a>
            <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                <?php $eksik = $toplam - $bakimOzeti[$alan]['tamam']; ?>
                <a href="index.php?bakim=<?= $alan ?>#bakim" class="<?= $secilenBakim === $alan ? 'secili' : '' ?>">
                    <?= $bilgi['simge'] ?> <?= guvenli($bilgi['baslik']) ?> gerekenler (<?= $eksik ?>)
                </a>
            <?php endforeach; ?>
        </div>

        <?php if (count($bakimListesi) === 0): ?>
            <div class="bos">Harika! Bu bakımı eksik olan hayvan yok. 🎉</div>
        <?php else: ?>
            <div class="bakim-liste">
                <?php foreach ($bakimListesi as $hayvan): ?>
                    <article class="bakim-kart">
                        <div class="bk-ust <?= turSinifi($hayvan['tur']) ?>">
                            <span class="bk-simge"><?= turSimgesi($hayvan['tur']) ?></span>
                            <div>
                                <h3><?= guvenli($hayvan['ad']) ?></h3>
                                <small><?= guvenli($hayvan['tur']) ?><?= cinsiGetir($hayvan) !== '' ? ' (' . guvenli(cinsiGetir($hayvan)) . ')' : '' ?> · <?= yasYaz(yasAyGetir($hayvan)) ?> · <?= guvenli($hayvan['sehir']) ?></small>
                            </div>
                        </div>
                        <ul class="bk-satirlar">
                            <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                                <?php
                                    $tarih = bakimTarihi($hayvan, $alan);
                                    $bd    = bakimDurumu($hayvan, $alan);
                                ?>
                                <li class="bk-<?= $bd['kod'] ?>">
                                    <span class="bk-ikon"><?= $bilgi['simge'] ?></span>
                                    <div class="bk-bilgi">
                                        <b><?= guvenli($bilgi['baslik']) ?></b>
                                        <?php if ($tarih === ''): ?>
                                            <small>Henüz yapılmadı</small>
                                        <?php else: ?>
                                            <small><?= tarihYaz($tarih) ?> · <?= neZamanOnce($tarih) ?></small>
                                        <?php endif; ?>
                                        <?php if ($bd['sonraki'] !== ''): ?>
                                            <small class="bk-sonraki">Sonraki: <?= tarihYaz($bd['sonraki']) ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <span class="bk-durum"><?= $bd['yazi'] ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="duzenle.php?id=<?= (int)$hayvan['id'] ?>" class="bk-link">📅 Bakım tarihlerini güncelle</a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>


    <!-- Filtreleme formu: GET yöntemi kullanılır, seçim adres çubuğunda görünür -->
    <h2 class="bolum-baslik" id="ilanlar">Sahiplendirme İlanları</h2>
    <form method="GET" action="index.php#ilanlar" class="filtre">
        <label>Tür
            <select name="tur">
                <option value="">Hepsi</option>
                <?php foreach ($TURLER as $tur): ?>
                    <option value="<?= guvenli($tur) ?>" <?= $secilenTur === $tur ? 'selected' : '' ?>>
                        <?= guvenli($tur) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Durum
            <select name="durum">
                <option value="">Hepsi</option>
                <?php foreach ($DURUMLAR as $durum): ?>
                    <option value="<?= guvenli($durum) ?>" <?= $secilenDurum === $durum ? 'selected' : '' ?>>
                        <?= guvenli($durum) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Şehir
            <select name="sehir">
                <option value="">Hepsi</option>
                <?php foreach ($sehirAdlari as $sehirAdi): ?>
                    <option value="<?= guvenli($sehirAdi) ?>" <?= $secilenSehir === $sehirAdi ? 'selected' : '' ?>><?= guvenli($sehirAdi) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Aşı
            <select name="asi">
                <option value="">Hepsi</option>
                <?php foreach ($ASI_DURUMLARI as $asiAdi): ?>
                    <option value="<?= guvenli($asiAdi) ?>" <?= $secilenAsi === $asiAdi ? 'selected' : '' ?>><?= guvenli($asiAdi) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Sırala
            <select name="sirala">
                <?php foreach ($SIRALAMALAR as $deger => $yazi): ?>
                    <option value="<?= $deger ?>" <?= $siralama === $deger ? 'selected' : '' ?>><?= $yazi ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="arama">Ara
            <input type="text" name="ara" value="<?= guvenli($aramaKelime) ?>" placeholder="🔎 İsim, şehir, sahiplenen...">
        </label>
        <button type="submit" class="buton">Filtrele</button>
        <a href="index.php#ilanlar" class="buton buton-ikincil">Temizle</a>
    </form>

    <p class="sonuc-bilgi">
        <?= count($listelenecek) ?> ilan listeleniyor
        <?php if ($secilenSehir !== ''): ?>
            · 📍 <?= guvenli($secilenSehir) ?> ilanları
        <?php endif; ?>
        <?php if ($secilenAsi !== ''): ?>
            · 💉 <?= guvenli($secilenAsi) ?>
        <?php endif; ?>
        <?php if ($aramaKelime !== ''): ?>
            · "<?= guvenli($aramaKelime) ?>" için arama sonuçları
        <?php endif; ?>
    </p>

    <!-- Hayvan listesi -->
    <?php if (count($listelenecek) === 0): ?>
        <div class="bos">Bu filtreye veya aramaya uygun ilan bulunamadı. 🐾</div>
    <?php else: ?>
        <section class="liste">
            <?php foreach ($listelenecek as $hayvan): ?>
                <article class="kart">
                    <!-- Kartın renkli üst kısmı: türe göre renk değişir -->
                    <?php $foto = hayvanFotosu($hayvan); ?>
                    <div class="kart-gorsel <?= turSinifi($hayvan['tur']) ?> <?= $foto !== null ? 'fotolu' : '' ?>">
                        <?php if ($foto !== null): ?>
                            <!-- Gerçek fotoğraf varsa o gösterilir, küçük tür simgesi köşede kalır -->
                            <a href="detay.php?id=<?= (int)$hayvan['id'] ?>" class="kart-foto-bag" tabindex="-1">
                                <img class="kart-foto" src="<?= guvenli($foto['dosya']) ?>" alt="<?= guvenli($hayvan['ad']) ?> — <?= guvenli($foto['etiket']) ?>" loading="lazy">
                            </a>
                            <span class="foto-simge"><?= turSimgesi($hayvan['tur']) ?></span>
                        <?php else: ?>
                            <span class="sus s1"></span><span class="sus s2"></span><span class="pati-iz">🐾</span>
                            <span class="buyuk-simge"><?= turSimgesi($hayvan['tur']) ?></span>
                        <?php endif; ?>
                        <span class="etiket <?= durumSinifi($hayvan['durum']) ?>"><?= guvenli($hayvan['durum']) ?></span>
                    </div>
                    <div class="kart-govde">
                        <h3><?= guvenli($hayvan['ad']) ?></h3>
                        <div class="ozellikler">
                            <span><?= guvenli($hayvan['tur']) ?></span>
                            <?php if (cinsiGetir($hayvan) !== ''): ?><span class="cins-etiket">🏷️ <?= guvenli(cinsiGetir($hayvan)) ?></span><?php endif; ?>
                            <span class="cinsiyet-etiket"><?= guvenli($hayvan['cinsiyet']) === 'Dişi' ? '♀' : '♂' ?> <?= guvenli($hayvan['cinsiyet']) ?></span>
                            <span class="yas-etiket">🎂 <?= yasYaz(yasAyGetir($hayvan)) ?></span>
                        </div>
                        <?php $asi = asiDurumu($hayvan); ?>
                        <div class="asi-etiket <?= asiSinifi($asi) ?>">
                            <span>💉 Aşı durumu</span>
                            <b><?= asiSimgesi($asi) ?> <?= guvenli($asi) ?></b>
                        </div>
                        <p class="aciklama"><?= guvenli($hayvan['aciklama']) ?></p>

                        <!-- Görüşme ve sahiplenme özeti -->
                        <?php $sahip = sahiplenenGetir($hayvan); $gorusmeSay = count(gorusmeleriGetir($hayvan)); ?>
                        <div class="kart-kisiler">
                            <?php if ($sahip !== null): ?>
                                <span class="kk-sahip">🏡 Sahibi: <b><?= guvenli($sahip['adSoyad']) ?></b></span>
                            <?php endif; ?>
                            <span class="kk-gorusme">💬 <?= $gorusmeSay ?> görüşme</span>
                        </div>
                    </div>
                    <div class="kart-alt">
                        <span>📍 <?= guvenli($hayvan['sehir']) ?> · <?= guvenli($hayvan['tarih']) ?></span>
                        <div class="kart-butonlar">
                            <!-- Detay ve düzenleme sayfalarına id GET ile gönderilir -->
                            <a href="detay.php?id=<?= (int)$hayvan['id'] ?>" class="detay-buton">Detay</a>
                            <a href="duzenle.php?id=<?= (int)$hayvan['id'] ?>" class="duzenle">Düzenle</a>
                            <!-- Silme işlemi POST ile sil.php'ye gönderilir -->
                            <form method="POST" action="sil.php" onsubmit="return confirm('Bu ilan silinsin mi?');">
                                <input type="hidden" name="id" value="<?= (int)$hayvan['id'] ?>">
                                <button type="submit" class="sil">Sil</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <!-- Şehirlere göre ilanlar: her şehir için bir kart -->
    <section class="sehirler" id="sehirler">
        <h2 class="bolum-baslik ortali">Şehirlere göre ilanlar</h2>
        <p class="bolum-alt"><?= count($sehirSayilari) ?> şehirde yuva bekleyen dostlar var. Bir şehre tıkla, oradaki ilanları gör.</p>

        <div class="sehir-liste">
            <?php $sira = 0; ?>
            <?php foreach ($sehirSayilari as $sehirAdi => $sayilar): ?>
                <?php
                    $sira++;
                    // Sahiplendirme oranı: o şehirde yuvasını bulanların yüzdesi
                    $oran = round($sayilar['Sahiplendirildi'] / $sayilar['toplam'] * 100);
                    // Kartın rengi sırayla değişsin diye 1-6 arası bir numara
                    $renk = ($sira - 1) % 6 + 1;
                ?>
                <a href="index.php?sehir=<?= urlencode($sehirAdi) ?>#ilanlar"
                   class="sehir-kart renk<?= $renk ?> <?= $secilenSehir === $sehirAdi ? 'secili' : '' ?>">
                    <?php if ($sira === 1): ?>
                        <span class="sehir-rozet">⭐ En çok ilan</span>
                    <?php endif; ?>
                    <div class="sehir-ust">
                        <span class="sehir-pin">📍</span>
                        <div>
                            <h3><?= guvenli($sehirAdi) ?></h3>
                            <small><?= $sayilar['toplam'] ?> ilan</small>
                        </div>
                        <span class="sehir-sayi"><?= $sayilar['toplam'] ?></span>
                    </div>
                    <ul class="sehir-durumlar">
                        <li><i class="nokta ariyor"></i> Yuva arıyor <b><?= $sayilar['Yuva arıyor'] ?></b></li>
                        <li><i class="nokta gorusuluyor"></i> Görüşülüyor <b><?= $sayilar['Görüşülüyor'] ?></b></li>
                        <li><i class="nokta sahiplendi"></i> Sahiplendirildi <b><?= $sayilar['Sahiplendirildi'] ?></b></li>
                    </ul>
                    <div class="oran">
                        <div class="oran-yazi"><span>Sahiplendirme oranı</span><b>%<?= $oran ?></b></div>
                        <div class="oran-yol"><div class="oran-dolu" style="width: <?= $oran ?>%"></div></div>
                    </div>
                    <span class="sehir-link">İlanları gör →</span>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- İstatistik: türlere göre dağılım (çubuk genişliği PHP ile hesaplanır) -->
    <section class="istatistik">
        <div class="istatistik-baslik">
            <h2 class="bolum-baslik">Türlere göre ilanlar</h2>
            <p>Sistemdeki <?= $toplam ?> ilanın türlere göre dağılımı</p>
        </div>
        <div class="cubuklar">
            <?php foreach ($turSayilari as $tur => $sayi): ?>
                <?php $yuzde = round($sayi / $enBuyuk * 100); ?>
                <div class="cubuk-satir">
                    <span class="cubuk-ad"><?= turSimgesi($tur) ?> <?= guvenli($tur) ?></span>
                    <div class="cubuk-yol">
                        <div class="cubuk <?= turSinifi($tur) ?>" style="width: <?= $yuzde ?>%"></div>
                    </div>
                    <span class="cubuk-sayi"><?= $sayi ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Neden sahiplenmeli? -->
    <section class="neden" id="neden">
        <div class="neden-metin">
            <span class="rozet">🐾 Biliyor muydunuz?</span>
            <h2>Neden <em>sahiplenmelisin?</em></h2>
            <p>Barınaklarda ve sokaklarda binlerce dost bir yuva bekliyor. Sahiplenmek bir canı kurtarmakla kalmaz, hayatına sevgi dolu bir arkadaş katar.</p>
        </div>
        <div class="neden-kartlar">
            <div class="neden-kart k1"><i>❤️</i><h3>Bir can kurtarırsın</h3><p>Sokakta zorlanan bir dosta güvenli bir ev açarsın.</p></div>
            <div class="neden-kart k2"><i>🤝</i><h3>Koşulsuz sevgi</h3><p>Sahiplendiğin dost sana sadakatle bağlanır.</p></div>
            <div class="neden-kart k3"><i>🌿</i><h3>Daha mutlu bir yaşam</h3><p>Evcil hayvanlar stresi azaltır, günlere neşe katar.</p></div>
            <div class="neden-kart k4"><i>💸</i><h3>Ücretsiz</h3><p>Satın almak yerine sahiplenerek üretim çiftliklerini desteklemezsin.</p></div>
        </div>
    </section>

</main>

<footer class="alt">
    <strong>🐾 Tamer Barınağı</strong>
    <p>Her pati bir yuvayı hak eder.</p>
    <small>İnternet Programcılığı I PHP Projesi · 2026</small>
    <small class="foto-not">Hayvan fotoğrafları <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash</a> üzerinden ücretsiz lisansla kullanılmıştır. Fotoğrafçı bilgisi hayvanın detay sayfasında.</small>
</footer>

</body>
</html>
