<?php
/*
 * ust_alan.php — Bütün sayfaların üst bölümü (sıra: logo + site adı → menü → hayvan şeridi).
 * Kullanım: önce $aktifSayfa ('index', 'kisiler', 'ekle' ya da '') tanımlanır, sonra include edilir.
 */
$aktifSayfa = isset($aktifSayfa) ? $aktifSayfa : '';
$menu = [
    'index'   => ['index.php',   'İlanlar'],
    'kisiler' => ['kisiler.php', 'Sahiplenenler &amp; Görüşenler'],
    'ekle'    => ['ekle.php',    'Yeni İlan Ekle'],
];
$temalar = ['beyaz' => 'Beyaz', 'lavanta' => 'Lavanta', 'bordo' => 'Bordo', 'mor' => 'Mor'];
?>
<!-- 1) En üst: logo ve site adı + tema seçici -->
<div class="marka">
    <div class="kapsayici marka-icerik">
        <a href="index.php" class="marka-sol" aria-label="Tamer Barınağı ana sayfa">
            <svg class="marka-logo" viewBox="0 0 64 64" role="img" aria-hidden="true">
                <defs>
                    <linearGradient id="logoGrad" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0" style="stop-color: var(--lavanta)"/>
                        <stop offset="1" style="stop-color: var(--lavanta-koyu)"/>
                    </linearGradient>
                </defs>
                <rect width="64" height="64" rx="19" fill="url(#logoGrad)"/>
                <g fill="#fff">
                    <ellipse cx="32" cy="42" rx="13" ry="10.5"/>
                    <ellipse cx="16.5" cy="31" rx="5.2" ry="6.6" transform="rotate(-18 16.5 31)"/>
                    <ellipse cx="26" cy="20.5" rx="5" ry="6.8" transform="rotate(-6 26 20.5)"/>
                    <ellipse cx="38" cy="20.5" rx="5" ry="6.8" transform="rotate(6 38 20.5)"/>
                    <ellipse cx="47.5" cy="31" rx="5.2" ry="6.6" transform="rotate(18 47.5 31)"/>
                </g>
                <path d="M32 47.5 C26 43.5 26 39 29 38.2 C30.8 37.7 32 39 32 39 C32 39 33.2 37.7 35 38.2 C38 39 38 43.5 32 47.5Z" style="fill: var(--pembe)"/>
            </svg>
            <span>
                <span class="marka-ad">Tamer Barınağı</span>
                <span class="marka-slogan">Her pati bir yuvayı hak eder</span>
            </span>
        </a>

        <!-- Renk teması ve koyu/açık mod (tema.js çalıştırır) -->
        <div class="tema-panel">
            <div class="tema-noktalar" role="group" aria-label="Renk teması">
                <span class="tema-etiket">Tema</span>
                <?php foreach ($temalar as $anahtar => $ad): ?>
                    <button type="button" class="tema-nokta" data-tema="<?= $anahtar ?>" aria-pressed="false"
                            title="<?= $ad ?> tema" aria-label="<?= $ad ?> tema"></button>
                <?php endforeach; ?>
            </div>
            <button type="button" class="mod-dugme" aria-pressed="false" aria-label="Koyu / açık mod">
                <span class="mod-simge" aria-hidden="true"></span><span class="mod-yazi"></span>
            </button>
        </div>
    </div>
</div>

<!-- 2) Menü -->
<header class="ust">
    <div class="kapsayici ust-icerik">
        <nav aria-label="Ana menü">
            <?php foreach ($menu as $anahtar => $bilgi): ?>
                <a href="<?= $bilgi[0] ?>"<?= $aktifSayfa === $anahtar ? ' class="aktif"' : '' ?>><?= $bilgi[1] ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>

<!-- 3) Kayan hayvan şeridi -->
<?php include 'hayvan_seridi.php'; ?>
