/*
 * tema.js — Renk teması ve koyu/açık mod düğmeleri.
 * Seçim localStorage'da saklanır; sayfa açılınca tema_head.php içindeki betik geri yükler.
 */
(function () {
    var kok = document.documentElement;

    function kaydet(anahtar, deger) {
        try { localStorage.setItem(anahtar, deger); } catch (e) {}
    }

    function dugmeleriGuncelle() {
        var tema = kok.getAttribute('data-tema');
        var noktalar = document.querySelectorAll('.tema-nokta');
        for (var i = 0; i < noktalar.length; i++) {
            noktalar[i].setAttribute('aria-pressed', noktalar[i].getAttribute('data-tema') === tema ? 'true' : 'false');
        }
        var modDugme = document.querySelector('.mod-dugme');
        if (modDugme) {
            modDugme.setAttribute('aria-pressed', kok.getAttribute('data-mod') === 'koyu' ? 'true' : 'false');
        }
    }

    document.addEventListener('click', function (olay) {
        var nokta = olay.target.closest ? olay.target.closest('.tema-nokta') : null;
        if (nokta) {
            kok.setAttribute('data-tema', nokta.getAttribute('data-tema'));
            kaydet('mh-tema', nokta.getAttribute('data-tema'));
            dugmeleriGuncelle();
            return;
        }
        var modDugme = olay.target.closest ? olay.target.closest('.mod-dugme') : null;
        if (modDugme) {
            var yeni = kok.getAttribute('data-mod') === 'koyu' ? 'acik' : 'koyu';
            kok.setAttribute('data-mod', yeni);
            kaydet('mh-mod', yeni);
            dugmeleriGuncelle();
        }
    });

    document.addEventListener('DOMContentLoaded', dugmeleriGuncelle);
})();
