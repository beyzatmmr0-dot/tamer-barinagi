/*
 * animasyon.js — Hayvan temalı tıklama animasyonları ve akıcı sayfa geçişleri.
 *  - Tıklayınca patiler / hayvan emojileri etrafa saçılır (hayvana göre değişir).
 *  - Sayfa değişirken sayfa kayarak kapanır, altta patiler koşar.
 *  - Aşağı kaydırdıkça bölümler yumuşakça belirir.
 * "Hareketi azalt" ayarı açıksa efektler kapatılır.
 */
(function () {
    var azalt = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var kok = document.documentElement;

    var TUR_EMOJI = {
        'Kedi': '🐱', 'Köpek': '🐶', 'Kuş': '🐦', 'Tavşan': '🐰', 'Balık': '🐠', 'Hamster': '🐹',
        'Kaplumbağa': '🐢', 'Gine domuzu': '🐹', 'Kirpi': '🦔', 'Şinşilla': '🐭', 'Ferret': '🦦'
    };

    function rastgele(a, b) { return a + Math.random() * (b - a); }

    /* Tıklanan yerden emojiler saçılır */
    function patlat(x, y, liste, adet) {
        if (azalt || !Element.prototype.animate) { return; }
        for (var i = 0; i < adet; i++) {
            var p = document.createElement('span');
            p.className = 'parcacik';
            p.textContent = liste[Math.floor(Math.random() * liste.length)];
            p.style.left = x + 'px';
            p.style.top = y + 'px';
            p.style.fontSize = rastgele(14, 26) + 'px';
            document.body.appendChild(p);
            var aci = rastgele(0, Math.PI * 2);
            var mesafe = rastgele(40, 110);
            var dx = Math.cos(aci) * mesafe;
            var dy = Math.sin(aci) * mesafe - 30;
            var donus = rastgele(-60, 60);
            var anim = p.animate([
                { transform: 'translate(-50%, -50%) scale(.3) rotate(0deg)', opacity: 1 },
                { transform: 'translate(calc(-50% + ' + dx * 0.7 + 'px), calc(-50% + ' + dy * 0.7 + 'px)) scale(1.15) rotate(' + donus / 2 + 'deg)', opacity: 1, offset: 0.55 },
                { transform: 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + (dy + 40) + 'px)) scale(.6) rotate(' + donus + 'deg)', opacity: 0 }
            ], { duration: rastgele(650, 950), easing: 'cubic-bezier(.2,.8,.3,1)', fill: 'forwards' });
            anim.onfinish = (function (el) { return function () { el.remove(); }; })(p);
        }
    }

    /* Tıklanan öğeye göre hangi emojiler çıkacak */
    function efektSec(hedef) {
        var a = hedef.closest('.hs-hayvan');
        if (a) {
            var m = /[?&]tur=([^&#]+)/.exec(a.getAttribute('href') || '');
            var tur = m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : '';
            return { liste: [TUR_EMOJI[tur] || '🐾', '🐾', '✨'], adet: 9 };
        }
        if (hedef.closest('.mod-dugme')) { return { liste: ['🌙', '☀️', '✨'], adet: 8 }; }
        if (hedef.closest('.tema-nokta')) { return { liste: ['🎨', '✨', '💜'], adet: 8 }; }
        if (hedef.closest('.marka-sol')) { return { liste: ['🐾', '🐱', '🐶', '🐰'], adet: 10 }; }
        var sil = hedef.closest('form[action="sil.php"] button, form[action="sil.php"] [type=submit]');
        if (sil) { return { liste: ['💨', '😿'], adet: 6 }; }
        if (hedef.closest('button, .buton, [type=submit]')) { return { liste: ['🐾', '🐾', '💛'], adet: 7 }; }
        if (hedef.closest('.kart')) { return { liste: ['❤️', '🐾', '💕'], adet: 6 }; }
        if (hedef.closest('a')) { return { liste: ['🐾', '✨'], adet: 5 }; }
        return { liste: ['🐾'], adet: 2 };
    }

    /* Renk geçişi: tema/mod değişince bütün yüzeyler yumuşakça döner */
    function renkGecisi() {
        kok.classList.add('renk-gecisi');
        setTimeout(function () { kok.classList.remove('renk-gecisi'); }, 700);
    }

    /* Sayfa geçişi: koşan patiler */
    function patiKosusu() {
        if (azalt) { return; }
        var k = document.createElement('div');
        k.className = 'pati-kosu';
        k.setAttribute('aria-hidden', 'true');
        k.innerHTML = '<span>🐾</span><span>🐾</span><span>🐾</span><span>🐾</span><span>🐾</span>';
        document.body.appendChild(k);
    }

    function icBaglantiMi(a) {
        if (!a || !a.href || a.target === '_blank' || a.hasAttribute('download')) { return false; }
        if (a.origin !== location.origin) { return false; }
        if (a.pathname === location.pathname && a.search === location.search) { return false; } // aynı sayfada # kayması
        return true;
    }

    document.addEventListener('click', function (olay) {
        var hedef = olay.target;
        if (!hedef.closest) { return; }

        var e = efektSec(hedef);
        patlat(olay.clientX, olay.clientY, e.liste, e.adet);

        if (hedef.closest('.tema-nokta, .mod-dugme')) { renkGecisi(); }

        var a = hedef.closest('a');
        if (azalt || !a || olay.defaultPrevented || olay.button !== 0 ||
            olay.ctrlKey || olay.metaKey || olay.shiftKey || olay.altKey || !icBaglantiMi(a)) { return; }

        olay.preventDefault();
        var hayvan = a.closest('.hs-hayvan');
        var bekle = 280;
        if (hayvan) { hayvan.classList.add('zipladi'); bekle = 520; }
        a.classList.add('basildi');
        document.body.classList.add('sayfa-cikis');
        patiKosusu();
        setTimeout(function () { location.href = a.href; }, bekle);
    });

    /* Geri tuşuyla dönülünce eski durumu temizle */
    window.addEventListener('pageshow', function () {
        document.body.classList.remove('sayfa-cikis');
        var k = document.querySelector('.pati-kosu');
        if (k) { k.remove(); }
        var z = document.querySelectorAll('.zipladi, .basildi');
        for (var i = 0; i < z.length; i++) { z[i].classList.remove('zipladi', 'basildi'); }
    });

    /* Kaydırdıkça belirme */
    var HEDEFLER = '.adim, .saglik-kart, .serit-kart, .ozet-kutu, .bo-kutu, .tanitim-metin, .bolum-baslik, .asi-durum, .filtre';
    if (!azalt && 'IntersectionObserver' in window) {
        document.addEventListener('DOMContentLoaded', function () {
            var ogeler = document.querySelectorAll(HEDEFLER);
            var gozlem = new IntersectionObserver(function (girenler) {
                var sira = 0;
                girenler.forEach(function (g) {
                    if (g.isIntersecting) {
                        g.target.style.transitionDelay = (sira++ * 70) + 'ms';
                        g.target.classList.add('gorundu');
                        gozlem.unobserve(g.target);
                    }
                });
            }, { threshold: 0.12 });
            for (var i = 0; i < ogeler.length; i++) {
                ogeler[i].classList.add('belirecek');
                gozlem.observe(ogeler[i]);
            }
        });
    }
})();
