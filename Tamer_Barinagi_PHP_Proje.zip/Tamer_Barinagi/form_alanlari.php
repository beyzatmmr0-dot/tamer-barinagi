<?php
/*
 * form_alanlari.php — Ortak form alanları
 * Hem ekle.php hem duzenle.php bu dosyayı include eder.
 * Böylece form kodu iki kez yazılmaz; yeni bir alan eklemek için sadece burayı değiştirmek yeterli.
 * Kullanmadan önce $veri dizisinin tanımlı olması gerekir.
 */
?>
        <label>Hayvanın adı *
            <input type="text" name="ad" value="<?= guvenli($veri['ad']) ?>" maxlength="30">
        </label>

        <div class="satir">
            <label>Tür *
                <select name="tur">
                    <option value="">Seçiniz</option>
                    <?php foreach ($TURLER as $tur): ?>
                        <option value="<?= guvenli($tur) ?>" <?= $veri['tur'] === $tur ? 'selected' : '' ?>><?= guvenli($tur) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <!-- Yaş yıl ve ay olarak ayrı girilir, PHP'de toplam aya çevrilip saklanır -->
            <div class="yas-alani">
                <span class="alan-baslik">Yaş * <small>(1 yaşından küçükse yıl = 0)</small></span>
                <div class="yas-kutular">
                    <label><input type="number" name="yasYil" value="<?= guvenli($veri['yasYil']) ?>" min="0" max="30" placeholder="0"> <small>yıl</small></label>
                    <label><input type="number" name="yasAy" value="<?= guvenli($veri['yasAy']) ?>" min="0" max="11" placeholder="0"> <small>ay</small></label>
                </div>
            </div>
        </div>

        <!-- Cins isteğe bağlıdır; yazarken önerilen cinsler listelenir (datalist) -->
        <label>Cins <small>(isteğe bağlı, ör. British Shorthair, Fino, Japon balığı)</small>
            <input type="text" name="cins" list="cins-onerileri" value="<?= guvenli($veri['cins']) ?>" maxlength="40">
            <datalist id="cins-onerileri">
                <?php foreach (cinsOnerileri() as $oneri): ?>
                    <option value="<?= guvenli($oneri) ?>">
                <?php endforeach; ?>
            </datalist>
        </label>

        <div class="satir">
            <fieldset>
                <legend>Cinsiyet *</legend>
                <?php foreach ($CINSIYETLER as $c): ?>
                    <label class="radyo">
                        <input type="radio" name="cinsiyet" value="<?= guvenli($c) ?>" <?= $veri['cinsiyet'] === $c ? 'checked' : '' ?>>
                        <?= guvenli($c) ?>
                    </label>
                <?php endforeach; ?>
            </fieldset>

            <label>Şehir *
                <input type="text" name="sehir" value="<?= guvenli($veri['sehir']) ?>">
            </label>
        </div>

        <label>Durum *
            <select name="durum">
                <?php foreach ($DURUMLAR as $durum): ?>
                    <option value="<?= guvenli($durum) ?>" <?= $veri['durum'] === $durum ? 'selected' : '' ?>><?= guvenli($durum) ?></option>
                <?php endforeach; ?>
            </select>
            <small>Görüşme eklenince "Görüşülüyor", sahiplenen bilgisi girilince "Sahiplendirildi" olarak otomatik değişir.</small>
        </label>

        <!--
            Aşı kartı: her tür için ayrı bir grup. Yapılan aşının tarihini gir, yapılmadıysa boş bırak.
            Küçük JavaScript sadece seçili türün grubunu gösterir; asıl kontrol PHP'de yapılır
            (asilariFormdanAl fonksiyonu sadece seçilen türün aşılarını alır).
        -->
        <fieldset class="bakim-alanlari asi-alanlari">
            <legend>💉 Aşı kartı <small>(yapılan aşının tarihini gir, yapılmadıysa boş bırak)</small></legend>
            <?php foreach ($ASI_LISTESI as $asiTur => $asilar): ?>
                <div class="asi-grup" data-tur="<?= guvenli($asiTur) ?>">
                    <b><?= turSimgesi($asiTur) ?> <?= guvenli($asiTur) ?> aşıları</b>
                    <div class="bakim-satir">
                        <?php foreach ($asilar as $anahtar => $asiAdi): ?>
                            <label><?= guvenli($asiAdi) ?>
                                <input type="date" name="asilar[<?= $anahtar ?>]"
                                       value="<?= isset($veri['asilar'][$anahtar]) ? guvenli($veri['asilar'][$anahtar]) : '' ?>"
                                       max="<?= date('Y-m-d') ?>">
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <p class="asi-yok-bilgi">➖ Bu tür için takip edilen zorunlu aşı yok. Veteriner kontrol tarihini aşağıya girebilirsin.</p>
        </fieldset>

        <script>
            // Tür seçimine göre sadece o türün aşılarını göster
            (function () {
                var turSecim = document.querySelector('select[name="tur"]');
                function guncelle() {
                    var gorunen = 0;
                    document.querySelectorAll('.asi-grup').forEach(function (grup) {
                        var goster = grup.dataset.tur === turSecim.value;
                        grup.style.display = goster ? '' : 'none';
                        if (goster) { gorunen++; }
                    });
                    document.querySelector('.asi-yok-bilgi').style.display = (gorunen === 0 && turSecim.value !== '') ? '' : 'none';
                }
                turSecim.addEventListener('change', guncelle);
                guncelle();
            })();
        </script>

        <!-- Bakım kayıtları: boş bırakılırsa "yapılmadı" sayılır. max ile gelecekteki tarih seçilemez. -->
        <fieldset class="bakim-alanlari">
            <legend>🩺 Bakım kayıtları <small>(yapılmadıysa boş bırak)</small></legend>
            <div class="bakim-satir">
                <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                    <label><?= $bilgi['simge'] ?> <?= guvenli($bilgi['baslik']) ?> tarihi
                        <input type="date" name="<?= $alan ?>" value="<?= guvenli($veri[$alan]) ?>" max="<?= date('Y-m-d') ?>">
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <!-- Fotoğraf isteğe bağlı: hazır fotoğraflardan seçilir, PHP türe uyup uymadığını kontrol eder -->
        <label>Fotoğraf <small>(isteğe bağlı, hayvanın türüne uygun olanı seç)</small>
            <select name="foto">
                <option value="">Fotoğraf yok (türün çizimi gösterilir)</option>
                <?php foreach ($FOTO_KAYNAKLARI as $fotoAnahtar => $fotoBilgi): ?>
                    <option value="<?= guvenli($fotoAnahtar) ?>" <?= $veri['foto'] === $fotoAnahtar ? 'selected' : '' ?>>
                        <?= guvenli($fotoBilgi['tur']) ?> — <?= guvenli($fotoBilgi['etiket']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Açıklama * <small>(en az 10 karakter)</small>
            <textarea name="aciklama" rows="4"><?= guvenli($veri['aciklama']) ?></textarea>
        </label>
