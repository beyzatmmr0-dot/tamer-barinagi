<?php
/*
 * tema_head.php — <head> içine eklenir.
 * 1) Küçük satır içi betik, sayfa çizilmeden ÖNCE kayıtlı temayı uygular (yanıp sönme olmaz).
 * 2) assets/tema.js düğmeleri çalıştırır. Tema ve mod tarayıcıda (localStorage) saklanır.
 */
?>
    <script>
        (function () {
            var tema = 'lavanta', mod = 'acik';
            try {
                tema = localStorage.getItem('mh-tema') || tema;
                mod = localStorage.getItem('mh-mod') || (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'koyu' : 'acik');
            } catch (e) {}
            document.documentElement.setAttribute('data-tema', tema);
            document.documentElement.setAttribute('data-mod', mod);
        })();
    </script>
    <script src="assets/tema.js?v=<?= filemtime(__DIR__ . '/assets/tema.js') ?>" defer></script>
    <script src="assets/animasyon.js?v=<?= filemtime(__DIR__ . '/assets/animasyon.js') ?>" defer></script>
