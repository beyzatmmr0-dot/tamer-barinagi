<?php
/*
 * kisiler.php — Sahiplenenler ve görüşmeye gelenler
 * Bütün hayvanlardaki sahiplenen ve görüşme kayıtlarını tek sayfada toplar.
 * Görüşmeler sonuca göre (GET) filtrelenebilir, kişi adına göre aranabilir.
 */
require_once 'functions.php';

$tumHayvanlar  = hayvanlariGetir();
$sahiplenenler = tumSahiplenenler($tumHayvanlar);
$gorusmeler    = tumGorusmeler($tumHayvanlar);

// Filtreler (GET)
$secilenSonuc = isset($_GET['sonuc']) ? $_GET['sonuc'] : '';
$aramaKelime  = isset($_GET['ara']) ? trim($_GET['ara']) : '';
if (!in_array($secilenSonuc, $GORUSME_SONUCLARI)) {
    $secilenSonuc = ''; // listede olmayan değer gelirse filtre uygulanmaz
}

// Sayaçlar (filtreden önce, toplam üzerinden)
$sonucSayilari = [];
foreach ($GORUSME_SONUCLARI as $sonuc) {
    $sonucSayilari[$sonuc] = 0;
}
foreach ($gorusmeler as $g) {
    $sonucSayilari[$g['sonuc']]++;
}

// Görüşmeleri filtrele
$listelenenGorusmeler = [];
foreach ($gorusmeler as $g) {
    if ($secilenSonuc !== '' && $g['sonuc'] !== $secilenSonuc) {
        continue;
    }
    if ($aramaKelime !== '' && mb_stripos($g['ad'] . ' ' . $g['hayvanAd'] . ' ' . $g['telefon'], $aramaKelime, 0, 'UTF-8') === false) {
        continue;
    }
    $listelenenGorusmeler[] = $g;
}

// Sahiplenenlerde de aynı kelimeyle arama yapılır
$listelenenSahipler = [];
foreach ($sahiplenenler as $s) {
    if ($aramaKelime !== '' && mb_stripos($s['adSoyad'] . ' ' . $s['hayvanAd'] . ' ' . $s['sehir'] . ' ' . $s['telefon'], $aramaKelime, 0, 'UTF-8') === false) {
        continue;
    }
    $listelenenSahipler[] = $s;
}

// Görüşme yapıp sonra sahiplenen kişi sayısı (aynı telefon numarası iki listede de varsa)
$sahipTelefonlari = [];
foreach ($sahiplenenler as $s) {
    $sahipTelefonlari[] = str_replace(' ', '', $s['telefon']);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahiplenenler ve Görüşenler — Tamer Barınağı</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?php include 'tema_head.php'; ?>
</head>
<body>

<?php $aktifSayfa = 'kisiler'; include 'ust_alan.php'; ?>

<main class="kapsayici">

    <div class="form-baslik">
        <span class="form-simge">🤝</span>
        <div>
            <h1>Sahiplenenler ve görüşenler</h1>
            <p class="alt-baslik">Dostlarımızla görüşmeye gelen ve onlara yuva olan herkes burada.</p>
        </div>
    </div>

    <!-- Özet sayaçlar -->
    <section class="ozet">
        <a href="#sahiplenenler" class="ozet-kutu sahiplendi"><i>🏡</i><div><span><?= count($sahiplenenler) ?></span>Sahiplenen</div></a>
        <a href="kisiler.php#gorusmeler" class="ozet-kutu <?= $secilenSonuc === '' ? 'secili' : '' ?>"><i>💬</i><div><span><?= count($gorusmeler) ?></span>Toplam görüşme</div></a>
        <a href="kisiler.php?sonuc=<?= urlencode('Olumlu') ?>#gorusmeler" class="ozet-kutu gorusuluyor <?= $secilenSonuc === 'Olumlu' ? 'secili' : '' ?>"><i>👍</i><div><span><?= $sonucSayilari['Olumlu'] ?></span>Olumlu görüşme</div></a>
        <a href="kisiler.php?sonuc=<?= urlencode('Düşünüyor') ?>#gorusmeler" class="ozet-kutu ariyor <?= $secilenSonuc === 'Düşünüyor' ? 'secili' : '' ?>"><i>🤔</i><div><span><?= $sonucSayilari['Düşünüyor'] ?></span>Düşünüyor</div></a>
    </section>

    <form method="GET" action="kisiler.php" class="filtre">
        <label class="arama">Kişi ara
            <input type="text" name="ara" value="<?= guvenli($aramaKelime) ?>" placeholder="🔎 Kişi adı, telefon, hayvan adı...">
        </label>
        <label>Görüşme sonucu
            <select name="sonuc">
                <option value="">Hepsi</option>
                <?php foreach ($GORUSME_SONUCLARI as $sonuc): ?>
                    <option value="<?= guvenli($sonuc) ?>" <?= $secilenSonuc === $sonuc ? 'selected' : '' ?>><?= guvenli($sonuc) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit" class="buton">Filtrele</button>
        <a href="kisiler.php" class="buton buton-ikincil">Temizle</a>
    </form>

    <!-- ===== Sahiplenenler ===== -->
    <section class="detay-kutu genis" id="sahiplenenler">
        <div class="dk-baslik"><h2>🏡 Sahiplenenler (<?= count($listelenenSahipler) ?>)</h2></div>
        <?php if (count($listelenenSahipler) === 0): ?>
            <p class="dk-bos">Bu aramaya uygun sahiplenen bulunamadı.</p>
        <?php else: ?>
            <div class="sahip-izgara">
                <?php foreach ($listelenenSahipler as $s): ?>
                    <article class="sahip-kart">
                        <div class="sahip-avatar"><?= guvenli(mb_substr($s['adSoyad'], 0, 1)) ?></div>
                        <div class="sahip-bilgi">
                            <h3><?= guvenli($s['adSoyad']) ?></h3>
                            <ul>
                                <li>📞 <?= guvenli($s['telefon']) ?></li>
                                <li>✉️ <?= $s['eposta'] !== '' ? guvenli($s['eposta']) : '<i>E-posta yok</i>' ?></li>
                                <li>📍 <?= guvenli($s['sehir']) ?> — <?= guvenli($s['adres']) ?></li>
                                <li>📅 <?= tarihYaz($s['tarih']) ?> (<?= neZamanOnce($s['tarih']) ?>)</li>
                                <?php if ($s['not'] !== ''): ?>
                                    <li>📝 <?= guvenli($s['not']) ?></li>
                                <?php endif; ?>
                            </ul>
                            <a href="detay.php?id=<?= (int)$s['hayvanId'] ?>#sahiplenen" class="sahip-dost">
                                <?= turSimgesi($s['hayvanTur']) ?> Sahiplendiği dost: <b><?= guvenli($s['hayvanAd']) ?></b> →
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== Görüşmeler ===== -->
    <section class="detay-kutu genis" id="gorusmeler">
        <div class="dk-baslik">
            <h2>💬 Görüşmeye gelenler (<?= count($listelenenGorusmeler) ?>)</h2>
            <?php if ($secilenSonuc !== ''): ?>
                <span class="sonuc-rozet <?= sonucSinifi($secilenSonuc) ?>">Filtre: <?= guvenli($secilenSonuc) ?></span>
            <?php endif; ?>
        </div>
        <?php if (count($listelenenGorusmeler) === 0): ?>
            <p class="dk-bos">Bu filtreye uygun görüşme bulunamadı.</p>
        <?php else: ?>
            <div class="tablo-kap">
                <table class="asi-tablo">
                    <thead>
                        <tr><th>Kişi</th><th>Telefon</th><th>Görüştüğü dost</th><th>Tarih</th><th>Sonuç</th><th>Not</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listelenenGorusmeler as $g): ?>
                            <tr>
                                <td>
                                    <b><?= guvenli($g['ad']) ?></b>
                                    <?php if (in_array(str_replace(' ', '', $g['telefon']), $sahipTelefonlari)): ?>
                                        <span class="sahip-oldu" title="Bu kişi bir dostu sahiplendi">🏡</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= guvenli($g['telefon']) ?></td>
                                <td><a href="detay.php?id=<?= (int)$g['hayvanId'] ?>#gorusmeler" class="tablo-link"><?= turSimgesi($g['hayvanTur']) ?> <?= guvenli($g['hayvanAd']) ?></a></td>
                                <td><?= tarihYaz($g['tarih']) ?></td>
                                <td><span class="sonuc-rozet <?= sonucSinifi($g['sonuc']) ?>"><?= guvenli($g['sonuc']) ?></span></td>
                                <td class="not-hucre"><?= $g['not'] !== '' ? guvenli($g['not']) : '—' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="dk-not">🏡 işareti: görüşmeye gelip sonra bir dostu sahiplenen kişi. Yeni görüşme eklemek için hayvanın detay sayfasına git.</p>
        <?php endif; ?>
    </section>

</main>

<footer class="alt">
    <strong>🐾 Tamer Barınağı</strong>
    <p>Her pati bir yuvayı hak eder.</p>
    <small>İnternet Programcılığı I PHP Projesi · 2026</small>
    <small class="foto-not">Hayvan fotoğrafları <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash</a> üzerinden ücretsiz lisansla kullanılmıştır. Fotoğrafçı bilgisi hayvanın detay sayfasında.</small>
</footer>

</body>
</html>
