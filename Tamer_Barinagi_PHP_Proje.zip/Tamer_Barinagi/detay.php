<?php
/*
 * detay.php — Hayvan detay sayfası
 * Bir hayvanın bütün bilgilerini gösterir: genel bilgiler, yaş, aşı kartı, bakım kayıtları,
 * görüşmeye gelen kişiler ve sahiplenen kişinin bilgileri.
 *
 * Sayfa ilk açılışta id'yi adres çubuğundan (GET) alır.
 * Formlar bu sayfanın kendisine POST ile gönderilir. Hangi formun gönderildiğini
 * gizli "islem" alanından anlarız:
 *   gorusme_ekle     → yeni görüşme ekler
 *   gorusme_sil      → görüşmeyi siler
 *   sahiplen         → sahiplenen bilgisini kaydeder (durum "Sahiplendirildi" olur)
 *   sahiplenme_iptal → sahiplenmeyi geri alır
 */
require_once 'functions.php';

// id önce POST'ta, yoksa GET'te aranır
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
} else {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
}

$hayvan = hayvanBul($id);
if ($hayvan === null) {
    mesajKaydet('Aranan hayvan bulunamadı.', 'hata');
    header('Location: index.php');
    exit;
}

// Formların varsayılan (boş) değerleri ve hata listeleri
$gorusmeVeri  = ['ad' => '', 'telefon' => '', 'tarih' => date('Y-m-d'), 'sonuc' => '', 'not' => ''];
$sahipVeri    = ['adSoyad' => '', 'telefon' => '', 'eposta' => '', 'sehir' => '', 'adres' => '', 'tarih' => date('Y-m-d'), 'not' => ''];
$gorusmeHatalar = [];
$sahipHatalar   = [];

// "Bu kişiyi sahiplendir" butonu: görüşen kişinin adı ve telefonu sahiplenme formuna doldurulur (GET)
if (isset($_GET['doldur'])) {
    foreach (gorusmeleriGetir($hayvan) as $g) {
        if ($g['id'] === (int)$_GET['doldur']) {
            $sahipVeri['adSoyad'] = $g['ad'];
            $sahipVeri['telefon'] = $g['telefon'];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $islem = isset($_POST['islem']) ? $_POST['islem'] : '';

    if ($islem === 'gorusme_ekle') {
        foreach ($gorusmeVeri as $alan => $varsayilan) {
            $gorusmeVeri[$alan] = isset($_POST[$alan]) ? trim((string)$_POST[$alan]) : '';
        }
        $gorusmeHatalar = gorusmeDogrula($gorusmeVeri);
        if (count($gorusmeHatalar) === 0) {
            gorusmeEkle($id, $gorusmeVeri);
            mesajKaydet($gorusmeVeri['ad'] . ' ile yapılan görüşme kaydedildi.');
            header('Location: detay.php?id=' . $id . '#gorusmeler');
            exit;
        }

    } elseif ($islem === 'gorusme_sil') {
        $gorusmeId = isset($_POST['gorusme_id']) ? (int)$_POST['gorusme_id'] : 0;
        if (gorusmeSil($id, $gorusmeId)) {
            mesajKaydet('Görüşme kaydı silindi.');
        } else {
            mesajKaydet('Silinecek görüşme bulunamadı.', 'hata');
        }
        header('Location: detay.php?id=' . $id . '#gorusmeler');
        exit;

    } elseif ($islem === 'sahiplen') {
        foreach ($sahipVeri as $alan => $varsayilan) {
            $sahipVeri[$alan] = isset($_POST[$alan]) ? trim((string)$_POST[$alan]) : '';
        }
        $sahipHatalar = sahiplenmeDogrula($sahipVeri);
        if (count($sahipHatalar) === 0) {
            sahiplendir($id, $sahipVeri);
            mesajKaydet('🎉 ' . $hayvan['ad'] . ' yeni yuvasına kavuştu! Sahiplenen: ' . $sahipVeri['adSoyad']);
            header('Location: detay.php?id=' . $id . '#sahiplenen');
            exit;
        }

    } elseif ($islem === 'sahiplenme_iptal') {
        sahiplenmeIptal($id);
        mesajKaydet('Sahiplenme kaydı geri alındı, ' . $hayvan['ad'] . ' tekrar ilanda.');
        header('Location: detay.php?id=' . $id . '#sahiplenen');
        exit;
    }
}

// Ekranda kullanılacak hesaplanmış bilgiler
$yasAy      = yasAyGetir($hayvan);
$asiDurum   = asiDurumu($hayvan);
$asiKarti   = asiKarti($hayvan);
$gorusmeler = gorusmeleriGetir($hayvan);
$sahip      = sahiplenenGetir($hayvan);

// Görüşmeleri en yeniden eskiye sırala
usort($gorusmeler, function ($a, $b) { return strcmp($b['tarih'], $a['tarih']); });

// Görüşme sonuçlarına göre sayaçlar
$sonucSayilari = [];
foreach ($GORUSME_SONUCLARI as $sonuc) {
    $sonucSayilari[$sonuc] = 0;
}
foreach ($gorusmeler as $g) {
    $sonucSayilari[$g['sonuc']]++;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= guvenli($hayvan['ad']) ?> — Tamer Barınağı</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?php include 'tema_head.php'; ?>
</head>
<body>

<?php $aktifSayfa = ''; include 'ust_alan.php'; ?>

<main class="kapsayici">

    <a href="index.php#ilanlar" class="geri-link">← İlanlara dön</a>

    <?php mesajGoster(); ?>

    <!-- ===== Profil ===== -->
    <section class="profil <?= turSinifi($hayvan['tur']) ?>">
        <?php $foto = hayvanFotosu($hayvan); ?>
        <?php if ($foto !== null): ?>
            <div class="profil-simge profil-fotolu">
                <img src="<?= guvenli($foto['dosya']) ?>" alt="<?= guvenli($hayvan['ad']) ?> — <?= guvenli($foto['etiket']) ?>">
                <span class="foto-kaynak">📷 <a href="<?= guvenli($foto['sayfa']) ?>" target="_blank" rel="noopener noreferrer"><?= guvenli($foto['fotografci']) ?></a> · Unsplash</span>
            </div>
        <?php else: ?>
            <div class="profil-simge"><?= turSimgesi($hayvan['tur']) ?></div>
        <?php endif; ?>
        <div class="profil-bilgi">
            <span class="etiket <?= durumSinifi($hayvan['durum']) ?>"><?= guvenli($hayvan['durum']) ?></span>
            <h1><?= guvenli($hayvan['ad']) ?></h1>
            <div class="profil-cipler">
                <span><?= guvenli($hayvan['tur']) ?></span>
                <?php if (cinsiGetir($hayvan) !== ''): ?><span>🏷️ <?= guvenli(cinsiGetir($hayvan)) ?></span><?php endif; ?>
                <span><?= $hayvan['cinsiyet'] === 'Dişi' ? '♀' : '♂' ?> <?= guvenli($hayvan['cinsiyet']) ?></span>
                <span>🎂 <?= yasYaz($yasAy) ?> · <?= yasDonemi($yasAy) ?></span>
                <span>📍 <?= guvenli($hayvan['sehir']) ?></span>
                <span>📅 İlan: <?= tarihYaz($hayvan['tarih']) ?></span>
            </div>
            <p><?= guvenli($hayvan['aciklama']) ?></p>
            <div class="profil-butonlar">
                <a href="duzenle.php?id=<?= (int)$hayvan['id'] ?>" class="buton">✏️ Bilgileri / aşıları düzenle</a>
                <form method="POST" action="sil.php" onsubmit="return confirm('Bu ilan ve bütün kayıtları silinsin mi?');">
                    <input type="hidden" name="id" value="<?= (int)$hayvan['id'] ?>">
                    <button type="submit" class="buton buton-sil">Sil</button>
                </form>
            </div>
        </div>
    </section>

    <div class="detay-izgara">

        <!-- ===== Aşı kartı ===== -->
        <section class="detay-kutu" id="asi-karti">
            <div class="dk-baslik">
                <h2>💉 Aşı kartı</h2>
                <span class="asi-rozet <?= asiSinifi($asiDurum) ?>"><?= asiSimgesi($asiDurum) ?> <?= guvenli($asiDurum) ?></span>
            </div>
            <?php if (count($asiKarti) === 0): ?>
                <p class="dk-bos">➖ <?= guvenli($hayvan['tur']) ?> için takip edilen zorunlu aşı yok. Düzenli veteriner kontrolü yeterli.</p>
            <?php else: ?>
                <ul class="asi-liste">
                    <?php foreach ($asiKarti as $asi): ?>
                        <li class="bk-<?= $asi['kod'] ?>">
                            <span class="bk-ikon">💉</span>
                            <div class="bk-bilgi">
                                <b><?= guvenli($asi['ad']) ?></b>
                                <?php if ($asi['tarih'] === ''): ?>
                                    <small>Henüz yapılmadı</small>
                                <?php else: ?>
                                    <small><?= tarihYaz($asi['tarih']) ?> · <?= neZamanOnce($asi['tarih']) ?></small>
                                    <small class="bk-sonraki">Rapel: <?= tarihYaz($asi['sonraki']) ?></small>
                                <?php endif; ?>
                            </div>
                            <span class="bk-durum"><?= $asi['yazi'] ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <p class="dk-not">Aşıların tekrarı (rapel) yaklaşık <?= ASI_ARALIGI ?> günde bir hatırlatılır.</p>
            <?php endif; ?>
        </section>

        <!-- ===== Bakım kayıtları ===== -->
        <section class="detay-kutu">
            <div class="dk-baslik"><h2>🩺 Bakım kayıtları</h2></div>
            <ul class="asi-liste">
                <?php foreach ($BAKIMLAR as $alan => $bilgi): ?>
                    <?php $tarih = bakimTarihi($hayvan, $alan); $bd = bakimDurumu($hayvan, $alan); ?>
                    <li class="bk-<?= $bd['kod'] ?>">
                        <span class="bk-ikon"><?= $bilgi['simge'] ?></span>
                        <div class="bk-bilgi">
                            <b><?= guvenli($bilgi['baslik']) ?></b>
                            <?php if ($tarih === ''): ?>
                                <small>Henüz yapılmadı</small>
                            <?php else: ?>
                                <small><?= tarihYaz($tarih) ?> · <?= neZamanOnce($tarih) ?></small>
                            <?php endif; ?>
                            <?php if ($bd['sonraki'] !== ''): ?>
                                <small class="bk-sonraki">Sonraki: <?= tarihYaz($bd['sonraki']) ?></small>
                            <?php endif; ?>
                        </div>
                        <span class="bk-durum"><?= $bd['yazi'] ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>

    <!-- ===== Sahiplenen ===== -->
    <section class="detay-kutu genis" id="sahiplenen">
        <div class="dk-baslik"><h2>🏡 Sahiplenen</h2></div>

        <?php if ($sahip !== null): ?>
            <div class="sahip-kart">
                <div class="sahip-avatar"><?= guvenli(mb_substr($sahip['adSoyad'], 0, 1)) ?></div>
                <div class="sahip-bilgi">
                    <h3><?= guvenli($sahip['adSoyad']) ?></h3>
                    <ul>
                        <li>📞 <?= guvenli($sahip['telefon']) ?></li>
                        <li>✉️ <?= $sahip['eposta'] !== '' ? guvenli($sahip['eposta']) : '<i>E-posta yok</i>' ?></li>
                        <li>📍 <?= guvenli($sahip['sehir']) ?> — <?= guvenli($sahip['adres']) ?></li>
                        <li>📅 Sahiplenme tarihi: <?= tarihYaz($sahip['tarih']) ?> (<?= neZamanOnce($sahip['tarih']) ?>)</li>
                        <?php if ($sahip['not'] !== ''): ?>
                            <li>📝 <?= guvenli($sahip['not']) ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <form method="POST" action="detay.php" onsubmit="return confirm('Sahiplenme kaydı geri alınsın mı?');">
                    <input type="hidden" name="id" value="<?= (int)$id ?>">
                    <input type="hidden" name="islem" value="sahiplenme_iptal">
                    <button type="submit" class="sil">Sahiplenmeyi geri al</button>
                </form>
            </div>

        <?php else: ?>
            <p class="dk-not">
                <?php if ($hayvan['durum'] === 'Sahiplendirildi'): ?>
                    ⚠️ Bu hayvan "Sahiplendirildi" olarak işaretli ama sahiplenen bilgisi girilmemiş. Aşağıdan ekleyebilirsin.
                <?php else: ?>
                    <?= guvenli($hayvan['ad']) ?> henüz sahiplenilmedi. Sahiplenen kişinin bilgilerini girince durum otomatik olarak "Sahiplendirildi" olur.
                <?php endif; ?>
            </p>

            <?php if (count($sahipHatalar) > 0): ?>
                <div class="mesaj mesaj-hata">
                    <strong>Lütfen aşağıdaki hataları düzeltin:</strong>
                    <ul>
                        <?php foreach ($sahipHatalar as $hata): ?>
                            <li><?= guvenli($hata) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="detay.php#sahiplenen" class="form kucuk-form" novalidate>
                <input type="hidden" name="id" value="<?= (int)$id ?>">
                <input type="hidden" name="islem" value="sahiplen">
                <div class="satir">
                    <label>Ad soyad *
                        <input type="text" name="adSoyad" value="<?= guvenli($sahipVeri['adSoyad']) ?>" maxlength="50">
                    </label>
                    <label>Telefon *
                        <input type="tel" name="telefon" value="<?= guvenli($sahipVeri['telefon']) ?>" placeholder="0532 111 22 33">
                    </label>
                </div>
                <div class="satir">
                    <label>E-posta <small>(isteğe bağlı)</small>
                        <input type="email" name="eposta" value="<?= guvenli($sahipVeri['eposta']) ?>" placeholder="ad@ornek.com">
                    </label>
                    <label>Şehir *
                        <input type="text" name="sehir" value="<?= guvenli($sahipVeri['sehir']) ?>">
                    </label>
                </div>
                <label>Adres *
                    <textarea name="adres" rows="2"><?= guvenli($sahipVeri['adres']) ?></textarea>
                </label>
                <div class="satir">
                    <label>Sahiplenme tarihi *
                        <input type="date" name="tarih" value="<?= guvenli($sahipVeri['tarih']) ?>" max="<?= date('Y-m-d') ?>">
                    </label>
                    <label>Not <small>(isteğe bağlı)</small>
                        <input type="text" name="not" value="<?= guvenli($sahipVeri['not']) ?>" maxlength="200">
                    </label>
                </div>
                <div class="form-butonlar">
                    <button type="submit" class="buton">🏡 Sahiplendir</button>
                </div>
            </form>
        <?php endif; ?>
    </section>

    <!-- ===== Görüşmeler ===== -->
    <section class="detay-kutu genis" id="gorusmeler">
        <div class="dk-baslik">
            <h2>💬 Görüşmeye gelenler (<?= count($gorusmeler) ?>)</h2>
            <div class="sonuc-sayaclar">
                <?php foreach ($sonucSayilari as $sonuc => $sayi): ?>
                    <span class="sonuc-rozet <?= sonucSinifi($sonuc) ?>"><?= guvenli($sonuc) ?>: <?= $sayi ?></span>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if (count($gorusmeler) === 0): ?>
            <p class="dk-bos">Henüz kimse <?= guvenli($hayvan['ad']) ?> ile görüşmeye gelmedi.</p>
        <?php else: ?>
            <div class="tablo-kap">
                <table class="asi-tablo">
                    <thead>
                        <tr><th>Kişi</th><th>Telefon</th><th>Tarih</th><th>Sonuç</th><th>Not</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gorusmeler as $g): ?>
                            <tr>
                                <td><b><?= guvenli($g['ad']) ?></b></td>
                                <td><?= guvenli($g['telefon']) ?></td>
                                <td><?= tarihYaz($g['tarih']) ?></td>
                                <td><span class="sonuc-rozet <?= sonucSinifi($g['sonuc']) ?>"><?= guvenli($g['sonuc']) ?></span></td>
                                <td class="not-hucre"><?= $g['not'] !== '' ? guvenli($g['not']) : '—' ?></td>
                                <td class="islem-hucre">
                                    <?php if ($sahip === null && $g['sonuc'] === 'Olumlu'): ?>
                                        <a href="detay.php?id=<?= (int)$id ?>&amp;doldur=<?= (int)$g['id'] ?>#sahiplenen" class="tablo-link">🏡 Sahiplendir</a>
                                    <?php endif; ?>
                                    <form method="POST" action="detay.php" onsubmit="return confirm('Bu görüşme kaydı silinsin mi?');">
                                        <input type="hidden" name="id" value="<?= (int)$id ?>">
                                        <input type="hidden" name="islem" value="gorusme_sil">
                                        <input type="hidden" name="gorusme_id" value="<?= (int)$g['id'] ?>">
                                        <button type="submit" class="sil">Sil</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <h3 class="alt-form-baslik">+ Yeni görüşme ekle</h3>

        <?php if (count($gorusmeHatalar) > 0): ?>
            <div class="mesaj mesaj-hata">
                <strong>Lütfen aşağıdaki hataları düzeltin:</strong>
                <ul>
                    <?php foreach ($gorusmeHatalar as $hata): ?>
                        <li><?= guvenli($hata) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="detay.php#gorusmeler" class="form kucuk-form" novalidate>
            <input type="hidden" name="id" value="<?= (int)$id ?>">
            <input type="hidden" name="islem" value="gorusme_ekle">
            <div class="satir">
                <label>Görüşen kişi *
                    <input type="text" name="ad" value="<?= guvenli($gorusmeVeri['ad']) ?>" maxlength="50">
                </label>
                <label>Telefon *
                    <input type="tel" name="telefon" value="<?= guvenli($gorusmeVeri['telefon']) ?>" placeholder="0532 111 22 33">
                </label>
            </div>
            <div class="satir">
                <label>Görüşme tarihi *
                    <input type="date" name="tarih" value="<?= guvenli($gorusmeVeri['tarih']) ?>" max="<?= date('Y-m-d') ?>">
                </label>
                <label>Sonuç *
                    <select name="sonuc">
                        <option value="">Seçiniz</option>
                        <?php foreach ($GORUSME_SONUCLARI as $sonuc): ?>
                            <option value="<?= guvenli($sonuc) ?>" <?= $gorusmeVeri['sonuc'] === $sonuc ? 'selected' : '' ?>><?= guvenli($sonuc) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <label>Not <small>(isteğe bağlı, en fazla 200 karakter)</small>
                <input type="text" name="not" value="<?= guvenli($gorusmeVeri['not']) ?>" maxlength="200">
            </label>
            <div class="form-butonlar">
                <button type="submit" class="buton">💬 Görüşmeyi kaydet</button>
            </div>
        </form>
    </section>

</main>

<footer class="alt">
    <strong>🐾 Tamer Barınağı</strong>
    <p>Her pati bir yuvayı hak eder.</p>
    <small>İnternet Programcılığı I PHP Projesi · 2026</small>
    <small class="foto-not">Hayvan fotoğrafları <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash</a> üzerinden ücretsiz lisansla kullanılmıştır. Fotoğrafçı bilgisi hayvanın detay sayfasında.</small>
</footer>

</body>
</html>
