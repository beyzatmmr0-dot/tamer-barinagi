<?php
/*
 * ekle.php — Yeni ilan ekleme sayfası
 * Form POST ile bu sayfanın kendisine gönderilir, PHP tarafında doğrulanır.
 * Hata yoksa kayıt eklenir ve ana sayfaya yönlendirilir.
 */
require_once 'functions.php';

$hatalar = [];

// Formun ilk açılışta boş görünmesi için varsayılan değerler
$veri = ['ad' => '', 'tur' => '', 'yasYil' => '', 'yasAy' => '', 'cinsiyet' => '', 'cins' => '', 'sehir' => '', 'aciklama' => '', 'durum' => 'Yuva arıyor', 'foto' => '',
          'parazit' => '', 'kisir' => '', 'kontrol' => ''];

// Form gönderildiyse (POST) çalışır
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Gelen metin verilerini alıyoruz, baştaki/sondaki boşlukları trim ile temizliyoruz
    foreach ($veri as $alan => $varsayilan) {
        $veri[$alan] = isset($_POST[$alan]) ? trim((string)$_POST[$alan]) : '';
    }
    // Aşı tarihleri dizi olarak gelir (asilar[kedi_kuduz] gibi); sadece seçilen türünkiler alınır
    $veri['asilar'] = asilariFormdanAl($veri['tur']);

    $hatalar = formuDogrula($veri);

    if (count($hatalar) === 0) {
        $yeniId = hayvanEkle($veri);
        mesajKaydet($veri['ad'] . ' için ilan başarıyla eklendi.');
        header('Location: detay.php?id=' . $yeniId); // Ekledikten sonra hayvanın detay sayfasına git
        exit;
    }
    // Hata varsa sayfa aşağıda hatalarla birlikte tekrar gösterilir,
    // kullanıcının yazdıkları kaybolmaz.
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni İlan — Tamer Barınağı</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?php include 'tema_head.php'; ?>
</head>
<body>

<?php $aktifSayfa = 'ekle'; include 'ust_alan.php'; ?>

<main class="kapsayici form-duzen">
<div class="form-sol">

    <div class="form-baslik">
        <span class="form-simge">🐾</span>
        <div>
            <h1>Yeni sahiplendirme ilanı</h1>
            <p class="alt-baslik">Bir dostun yeni yuvasını bulmasına yardım et. Yıldızlı (*) alanlar zorunludur.</p>
        </div>
    </div>

    <?php if (count($hatalar) > 0): ?>
        <div class="mesaj mesaj-hata">
            <strong>Lütfen aşağıdaki hataları düzeltin:</strong>
            <ul>
                <?php foreach ($hatalar as $hata): ?>
                    <li><?= guvenli($hata) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- novalidate: tarayıcı kontrolünü kapatır, böylece PHP doğrulaması test edilebilir -->
    <form method="POST" action="ekle.php" class="form" novalidate>

        <?php include 'form_alanlari.php'; ?>


        <div class="form-butonlar">
            <button type="submit" class="buton">İlanı Kaydet</button>
            <a href="index.php" class="buton buton-ikincil">Vazgeç</a>
        </div>
    </form>
</div>

    <!-- Sağ taraftaki bilgi paneli -->
    <aside class="ipucu">
        <img src="assets/img/hero.svg" alt="">
        <h3>İyi bir ilan için ipuçları</h3>
        <ul>
            <li><i>📸</i> Hayvanın karakterini anlatan kısa bir açıklama yaz.</li>
            <li><i>💉</i> Aşı ve kısırlaştırma bilgisini belirt.</li>
            <li><i>🏠</i> Nasıl bir ev ortamına uygun olduğunu ekle.</li>
            <li><i>✅</i> Sahiplendirilince ilanın durumunu güncelle.</li>
        </ul>
    </aside>

</main>

<footer class="alt">
    <strong>🐾 Tamer Barınağı</strong>
    <p>Her pati bir yuvayı hak eder.</p>
    <small>İnternet Programcılığı I PHP Projesi · 2026</small>
    <small class="foto-not">Hayvan fotoğrafları <a href="https://unsplash.com/license" target="_blank" rel="noopener noreferrer">Unsplash</a> üzerinden ücretsiz lisansla kullanılmıştır. Fotoğrafçı bilgisi hayvanın detay sayfasında.</small>
</footer>

</body>
</html>
