# 🐾 Tamer Barınağı — Evcil Hayvan Sahiplendirme Kayıt ve Takip Sistemi

**Ders:** İnternet Programcılığı I (PHP) · 3 Haftalık Bireysel Proje
**Teslim:** 8 Kasım 2026

## Projenin amacı

Tamer Barınağı; kedi, köpek, kuş, tavşan ve diğer evcil hayvanlar için sahiplendirme ilanlarının kaydedildiği ve takip edildiği bir PHP web uygulamasıdır. Kullanıcı yeni ilan ekleyebilir, ilanları düzenleyebilir, arayabilir, sıralayabilir, türe ve duruma göre filtreleyebilir, yuvasını bulan hayvanları "Sahiplendirildi" olarak takip edebilir ve ilanları silebilir.

## Özellikler

| Özellik | Nasıl yapıldı |
|---|---|
| Ana sayfa | Uygulama adı, tanıtım metni, menü (`index.php`) |
| Kayıt listeleme | `foreach` döngüsüyle kart görünümünde listeleme. Her kayıtta 12 alan var: ad, tür, yaş, cinsiyet, şehir, açıklama, durum, aşı durumu, parazit bakımı tarihi, kısırlaştırma tarihi, kontrol tarihi, ilan tarihi |
| Yeni kayıt ekleme | HTML formu, **POST** yöntemi (`ekle.php`) |
| Veri doğrulama | Boş alan, yaş aralığı (0–30), açıklama uzunluğu ve geçerli seçenek kontrolü PHP tarafında yapılıyor. Hatalar liste halinde gösteriliyor, girilen veriler kaybolmuyor |
| Kayıt silme | Her kartta **POST** ile çalışan "Sil" butonu (`sil.php`). Silmeden önce onay soruluyor |
| Filtreleme | Tür ve durum filtresi, **GET** yöntemiyle |
| Özet bilgiler | Toplam ilan ile "Yuva arıyor", "Görüşülüyor" ve "Sahiplendirildi" sayaçları |
| Güvenli çıktı | Kullanıcı girdileri `htmlspecialchars()` ile gösteriliyor (`guvenli()` fonksiyonu) |
| Kalıcılık | Kayıtlar `$_SESSION` içinde tutuluyor, sayfa yenilendiğinde korunuyor |
| Bilgi mesajları | Ekleme, düzenleme ve silme sonrası tek seferlik başarılı/hata mesajı |
| **Kayıt düzenleme** *(ek)* | Her kartta "Düzenle" butonu; `duzenle.php` formu mevcut bilgilerle doldurur, POST ile günceller |
| **Arama** *(ek)* | Ad, tür, şehir ve açıklamada büyük/küçük harf duyarsız arama (GET) |
| **Sıralama** *(ek)* | En yeni, en eski, en genç, isme göre (`usort`) |
| **Şehirlere göre ilanlar** *(ek)* | Her şehir için kart: ilan sayısı, durum dağılımı, sahiplendirme oranı çubuğu. Karta tıklayınca o şehrin ilanları açılır. Filtrede şehir seçeneği de var |
| **Şehir adı düzeltme** *(ek)* | "tokat", "TOKAT" gibi yazımlar "Tokat" olarak kaydedilir, böylece aynı şehir tek kartta toplanır (Türkçe i/İ, ı/I dahil) |
| **Tıklanabilir sayaçlar** *(ek)* | Sayaç kutularına tıklayınca o durumdaki ilanlar listelenir |
| **Bilgi şeridi** *(ek)* | Üstteki 4 kart tıklanınca ilgili bölüme kayar; alt yazılar (şehir sayısı, tür sayısı, sahiplendirilen sayısı) PHP ile hesaplanır |
| **Sağlık rehberi** *(ek)* | Aşı, parazit, kısırlaştırma ve kontrol kartları ile kedi/köpek temel aşı listeleri; içerik PHP dizilerinden `foreach` ile üretilir |
| **Aşı durumu** *(ek)* | Her ilana "Aşıları tam / Kısmen aşılı / Aşısız" alanı eklendi: formda seçilir, PHP'de doğrulanır, kartta renkli etiketle görünür, filtrede seçilebilir |
| **Aşı tablosu** *(ek)* | Sağlık rehberinde "Hangi dostun aşısı var?" tablosu, tıklanabilir aşı sayaçları ve aşı oranı çubuğu |
| **Bakım kayıtları** *(ek)* | Her ilana parazit bakımı, kısırlaştırma ve veteriner kontrolü tarihi eklendi. Formda `type="date"` ile girilir; PHP'de `checkdate` ile gerçek tarih mi ve gelecekte değil mi diye kontrol edilir. Boş bırakılırsa "yapılmadı" sayılır |
| **Bakım takvimi** *(ek)* | Her hayvan için kart: ne zaman yapıldı, kaç gün önce, sonraki tarih ve Güncel / Zamanı geçti / Yapılmadı durumu. Parazit bakımı 90, kontrol 365 günde bir hatırlatılır. Sekmelerle sadece o bakımı eksik olanlar listelenir (GET) |
| **Canlı sağlık kartları** *(ek)* | Aşılar, parazit, kısırlaştırma ve kontrol kartlarında "4/9 güncel" gibi istatistik ve oran çubuğu; tıklanınca ilgili listeye gider |
| **İstatistik** *(ek)* | Türlere göre ilan dağılımı çubuk grafiği (genişlikler PHP ile hesaplanıyor) |

## 2. aşama geliştirmeleri (12 Kasım 2026)

| Özellik | Nasıl yapıldı |
|---|---|
| **Yaş ay/yıl olarak** | Formda yaş "yıl" ve "ay" kutularına ayrı girilir (ay 0–11). PHP'de toplam aya çevrilip `yasAy` alanında saklanır (`toplamAy`). Ekranda "8 aylık", "2 yaşında", "4 yıl 2 ay" gibi yazılır (`yasYaz`) ve yavru/genç/yetişkin/yaşlı dönemi gösterilir (`yasDonemi`). "En genç" sıralaması aya göre yapılır |
| **Aşı kartı** | Her tür için gerekli aşılar `$ASI_LISTESI` dizisinde (kedi: karma, kuduz, lösemi; köpek: karma, kuduz, bronşit; tavşan: miksomatozis, RHD). Formda her aşının yapıldığı tarih girilir. Aşı durumu ("Aşıları tam / Kısmen aşılı / Aşısız / Aşı gerekmiyor") artık elle seçilmiyor, yapılan aşılara bakılarak **PHP ile hesaplanıyor** (`asiDurumu`). Her aşının bir yıl sonraki rapel tarihi ve "Rapel zamanı geçti" uyarısı gösteriliyor (`asiKarti`) |
| **Hayvan detay sayfası** | `detay.php?id=…` (GET): profil, yaş, aşı kartı, bakım kayıtları, görüşmeler ve sahiplenen bilgisi tek sayfada |
| **Görüşmeye gelenler** | Detay sayfasından kişi adı, telefon, tarih, sonuç (Olumlu / Düşünüyor / Olumsuz) ve not ile görüşme eklenir ve silinir (POST). Ad, telefon (10–11 hane), tarih ve sonuç PHP'de doğrulanır. İlk görüşme eklenince durum otomatik "Görüşülüyor" olur |
| **Sahiplenen bilgileri** | Ad soyad, telefon, e-posta (isteğe bağlı, `filter_var` ile kontrol), şehir, adres, sahiplenme tarihi ve not (POST). Kaydedilince durum otomatik "Sahiplendirildi" olur. "Sahiplenmeyi geri al" ile ilan tekrar açılır. Olumlu görüşmedeki "🏡 Sahiplendir" bağlantısı kişinin adını ve telefonunu forma doldurur (GET) |
| **Sahiplenenler & Görüşenler sayfası** | `kisiler.php`: bütün sahiplenenler kart olarak, bütün görüşmeler tablo olarak listelenir. Sayaçlar, sonuca göre filtre ve kişi araması (GET) var. Görüşmeye gelip sonra sahiplenen kişiler 🏡 ile işaretlenir |
| **Arama** | Ana sayfadaki arama artık sahiplenen ve görüşen kişilerin adlarında da arıyor |
| **Gerçek fotoğraflar** | Örnek hayvanların fotoğrafları Unsplash'ten alındı (ücretsiz lisans). Kartlarda ve detay sayfasında gösterilir (`hayvanFotosu` fonksiyonu). Ekle/düzenle formunda hazır fotoğraflardan biri seçilebilir; PHP, seçilen fotoğrafın hayvanın türüne uyup uymadığını kontrol eder. Fotoğraf seçilmezse türün çizimi gösterilir. Fotoğrafçı adı detay sayfasında, lisans bilgisi sayfa altında yazar |
| **Hayvan şeridi** | `hayvan_seridi.php` bütün sayfaların en üstüne eklenir. Hayvanlar bir PHP dizisinden `foreach` ile oluşturulur. Her hayvanın iki SVG resmi var (`assets/img/hayvanlar/`); fare üstüne gelince CSS `:hover` ile normal resim gizlenip mutlu resim görünür ve konuşma balonu çıkar. Hayvanlar kendi kendine zıplar ve göz kırpar (CSS animasyonu). Tıklanınca o türün ilanları filtrelenir |

Bir hayvanın kaydı artık şöyle görünüyor:

```php
['id' => 4, 'ad' => 'Fındık', 'tur' => 'Tavşan', 'yasAy' => 14, ...,
 'asilar'     => ['tavsan_miksomatozis' => '2026-08-24'],
 'gorusmeler' => [ ['id' => 3, 'ad' => 'Zeynep Demir', 'telefon' => '...', 'tarih' => '...', 'sonuc' => 'Olumlu', 'not' => '...'] ],
 'sahiplenen' => ['adSoyad' => 'Zeynep Demir', 'telefon' => '...', 'eposta' => '...', 'sehir' => 'Tokat', 'adres' => '...', 'tarih' => '...', 'not' => '...']]
```

### Kullanıcı tanımlı fonksiyonlar (`functions.php`)

- `cinsiGetir()`, `cinsOnerileri()`, `ornekCinsleri()`: Hayvanın cinsi (isteğe bağlı alan, aramada da geçer)
- `ornekKayitlariYukle()`: İlk açılışta 9 örnek kaydı oturuma yükler
- `hayvanlariGetir()`: Bütün kayıtları döndürür
- `formuDogrula($veri)`: Form verilerini kontrol eder, hata dizisi döndürür
- `hayvanEkle($veri)`: Yeni kaydı ekler
- `hayvanSil($id)`: Kaydı siler
- `hayvanBul($id)`: id'ye göre tek kaydı döndürür
- `hayvanGuncelle($id, $veri)`: Kaydı günceller (id ve tarih korunur)
- `hayvanlariAra($liste, $kelime)`: Kelime araması yapar
- `hayvanlariSirala($liste, $siralama)`: Seçilen ölçüte göre sıralar
- `turleriSay($liste)`: Her türden kaç ilan olduğunu sayar
- `sehirleriSay($liste)`: Her şehirdeki toplam ve duruma göre ilan sayılarını hesaplar, en çok ilanı olan şehri başa alır
- `asiDurumu($hayvan)`: Kaydın aşı durumunu döndürür (alan yoksa "Bilinmiyor")
- `asiSay($liste, $asi)`: Belirli aşı durumundaki hayvanları sayar
- `asiSinifi()`, `asiSimgesi()`: Aşı etiketinin rengi ve simgesi
- `tarihGecerliMi($tarih)`: Tarih boşsa ya da geçerli ve bugünden ileri değilse true döndürür (`checkdate` kullanır)
- `gecenGun($tarih)`, `neZamanOnce($tarih)`, `tarihYaz($tarih)`: Gün farkı, "3 ay önce" gibi yazı ve 08.11.2026 biçimi
- `bakimDurumu($hayvan, $alan)`: Bir bakımın durumunu (güncel / gecikmiş / yapılmadı / yapıldı) ve sonraki tarihi hesaplar
- `bakimOzeti($liste)`: Her bakım türünde kaç hayvanın tamam, gecikmiş veya yapılmadı olduğunu sayar
- `bakimGerekenler($liste, $alan)`: Seçilen bakımı eksik olan hayvanları döndürür
- `sehirDuzenle($sehir)`: Şehir adını "Tokat" biçiminde düzgün yazar
- `hayvanlariFiltrele($liste, $tur, $durum, $sehir, $asi)`: Türe, duruma, şehre ve aşı durumuna göre filtreler
- `durumSay($liste, $durum)`: Belirli durumdaki kayıtları sayar
- `guvenli($metin)`: `htmlspecialchars` ile güvenli çıktı üretir
- `durumSinifi()`, `turSinifi()`, `turSimgesi()`: Arayüz yardımcıları (etiket rengi, kart rengi, simge)
- `mesajKaydet()`, `mesajGoster()`: Tek seferlik bilgi mesajları

**2. aşamada eklenenler:**

- `toplamAy($yil, $ay)`, `yasAyGetir($hayvan)`, `yasYaz($ay)`, `yasDonemi($ay)`: Yaş hesaplama ve yazdırma
- `gerekliAsilar($tur)`, `yapilanAsilar($hayvan)`, `asiKarti($hayvan)`, `rapelGecenSay($hayvan)`, `asilariFormdanAl($tur)`: Aşı kartı
- `asiDurumu($hayvan)`: Aşı durumunu yapılan aşılardan hesaplar
- `telefonGecerliMi($telefon)`: Telefon numarası kontrolü
- `gorusmeDogrula()`, `gorusmeEkle()`, `gorusmeSil()`, `gorusmeleriGetir()`: Görüşme işlemleri
- `sahiplenmeDogrula()`, `sahiplendir()`, `sahiplenmeIptal()`, `sahiplenenGetir()`: Sahiplenme işlemleri
- `tumGorusmeler($liste)`, `tumSahiplenenler($liste)`: Kişiler sayfası için bütün kayıtları toplar
- `sonucSinifi($sonuc)`: Görüşme sonucu etiket rengi

## Klasör yapısı

```
proje/
├── index.php          → Ana sayfa: sayaçlar, filtre/arama/sıralama, ilan listesi, istatistik
├── ekle.php           → Yeni ilan formu ve kayıt ekleme işlemi
├── duzenle.php        → İlan düzenleme (güncelleme) işlemi
├── detay.php          → Hayvan detayı: aşı kartı, bakım, görüşme ekle/sil, sahiplendir/geri al
├── kisiler.php        → Bütün sahiplenenler ve görüşmeye gelenler
├── hayvan_seridi.php  → Sayfaların en üstündeki hareketli hayvan şeridi
├── form_alanlari.php  → Ekleme ve düzenlemede ortak kullanılan form alanları
├── sil.php            → Kayıt silme işlemi (yalnızca POST)
├── functions.php      → Oturum başlatma, sabit diziler ve bütün fonksiyonlar
├── assets/
│   ├── style.css      → Pastel arayüz tasarımı (mobil uyumlu)
│   └── img/
│       ├── foto/      → Unsplash hayvan fotoğrafları (JPG)
│       ├── hero.svg   → Kedi-köpek illüstrasyonu (SVG)
│       └── hayvanlar/ → Şeritteki hayvanların normal ve mutlu resimleri (SVG)
├── ekran_goruntuleri/ → Uygulama ekran görüntüleri
└── README.md
```

## XAMPP üzerinde çalıştırma

1. XAMPP Control Panel'i açın ve **Apache**'yi başlatın.
2. Proje klasörünü `C:\xampp\htdocs\` içine kopyalayın (örnek: `C:\xampp\htdocs\tamerbarinagi`).
3. Tarayıcıda `http://localhost/tamerbarinagi/` adresini açın.
4. Kayıtlar 30 gün geçerli oturum çerezinde ve `data/kayitlar.json` yedeğinde tutulur. Örnek kayıtlara sıfırlamak için `data/kayitlar.json` dosyasını silip çerezleri temizleyin.

MySQL gerekmez. Veriler bu sürümde `$_SESSION` ile tutuluyor.

## Ekran görüntüleri

`ekran_goruntuleri/` klasöründe:

1. `1_ana_sayfa_listeleme.png`: Ana sayfa ve kayıt listeleme
2. `2_yeni_ilan_formu.png`: Yeni kayıt ekleme ekranı
3. `3_hatali_giris_kontrolu.png`: Boş form gönderildiğinde hata mesajları
4. `4_basarili_kayit.png`: Başarılı kayıt sonrası liste
5. `5_filtreleme.png`: Tür = Kedi, Durum = Yuva arıyor filtresi
6. `6_kayit_silme.png`: Kayıt silme sonrası mesaj
7. `7_ilan_duzenleme.png`: İlan düzenleme formu
8. `8_arama_siralama_istatistik.png`: "kedi" araması, en gence göre sıralama ve tür istatistiği
9. `9_sehirlere_gore_ilanlar.png`: Şehir kartları (Tokat seçili)
10. `10_saglik_rehberi.png`: Sağlık rehberi bölümü
11. `11_asi_durumu_tablosu.png`: Hangi dostun aşısı var? tablosu
12. `12_bakim_takvimi.png`: Bakım takvimi, "Parazit bakımı gerekenler" sekmesi seçili

## Bilinen eksikler

- Asıl depo `$_SESSION`'dır; oturum kaybolursa kayıtlar `data/kayitlar.json` yedeğinden geri yüklenir. (Sonraki aşamada MySQL'e taşınacak.)
- Kendi fotoğrafını yükleme yok; fotoğraf hazır listeden seçiliyor (seçilmezse tür çizimi gösterilir).
- İsme göre sıralamada Ç, Ş, Ü gibi Türkçe harfler alfabenin sonuna düşebilir (PHP'nin `strcmp` fonksiyonu Türkçe alfabe sırasını bilmez).

## Sonraki geliştirme planı

- MySQL + PDO ile kalıcı veri
- Kullanıcı girişi (ilan veren / sahiplenen)
- Yetkilendirme: barınak yöneticisi bütün ilanları yönetir, kullanıcı yalnızca kendi ilanlarını yönetir
- Fotoğraf yükleme
- Aylık sahiplendirme istatistikleri

## Fotoğraf kaynakları

Bütün fotoğraflar [Unsplash](https://unsplash.com/license) üzerinden alınmıştır. Unsplash lisansı, fotoğrafların ücretsiz kullanılmasına izin verir; yine de fotoğrafçıların adları aşağıda verilmiştir (ücretli "Unsplash+" fotoğrafları kullanılmadı).

| Dosya | Fotoğrafçı | Sayfa |
|---|---|---|
| pamuk.jpg | AcidFern | https://unsplash.com/photos/5AmkWHXlkO0 |
| duman.jpg | Milada Vigerova | https://unsplash.com/photos/0TPAlZ87mzk |
| boncuk.jpg | Tim van der Kuip | https://unsplash.com/photos/mdRJhxlsuGM |
| karabas.jpg | Samantha Fortney | https://unsplash.com/photos/IdYm0gyohkw |
| zeytin.jpg | mtsjrdl | https://unsplash.com/photos/5yAhL8ViUVg |
| pasa.jpg | Linoleum Creative Collective | https://unsplash.com/photos/ZQu-3viOINA |
| mavis.jpg | Tawhid Khan | https://unsplash.com/photos/5f8uEucFP6w |
| findik.jpg | Waranya Mooldee | https://unsplash.com/photos/Efj0HGPdPKs |
| tosbik.jpg | Wexor Tmg | https://unsplash.com/photos/L-2p8fapOA8 |
| mirmir.jpg | Loan | https://unsplash.com/photos/7AIDE8PrvA0 |
| tarcin.jpg | Amber Kipp | https://unsplash.com/photos/75715CVEJhI |
| limon.jpg | Alvan Nee | https://unsplash.com/photos/ZCHj_2lJP00 |
| comar.jpg | Victor G | https://unsplash.com/photos/N04FIfHhv_k |
| fistik.jpg | Florian Schindler | https://unsplash.com/photos/2LHLhMLqeIQ |
| max.jpg | Baptist Standaert | https://unsplash.com/photos/mx0DEnfYxic |
| lokum.jpg | Alvan Nee | https://unsplash.com/photos/eoqnr8ikwFE |
| pirpir.jpg | Ray Hennessy | https://unsplash.com/photos/MH_psben7HE |
| civil.jpg | FloatFlower Huang | https://unsplash.com/photos/6GHL995JYNU |
| pofuduk.jpg | Janan | https://unsplash.com/photos/302xfiIGOfE |
| bulut.jpg | Satyabratasm | https://unsplash.com/photos/u_kMWN-BWyU |
| gidik.jpg | Ricky Kharawala | https://unsplash.com/photos/adK3Vu70DEQ |
| kirpi.jpg | Sierra NiCole Narvaeth | https://unsplash.com/photos/D09Nooc3XQw |
| zipzip.jpg | Jaroslaw Slodkiewicz | https://unsplash.com/photos/SDIIfq6nhFU |
| pamuk2.jpg | hang niu | https://unsplash.com/photos/Tn8DLxwuDMA |
| lord.jpg | Sergey Semin | https://unsplash.com/photos/ff6MD1lIMaQ |
| prenses.jpg | Sergey Semin | https://unsplash.com/photos/Y0WXj3xqJz0 |
| baypasa.jpg | Lukáš Parničan | https://unsplash.com/photos/XnIi9M6__is |
| karamel.jpg | Lukáš Parničan | https://unsplash.com/photos/WI5OBsJoXEc |
| sutlac.jpg | ello | https://unsplash.com/photos/--jx3LMBlWY |
| aslan.jpg | Mikhail Volkov | https://unsplash.com/photos/YqcVdYpjgLo |
| mia.jpg | Alex Meier | https://unsplash.com/photos/KGiQFgF7dkc |
| sirin.jpg | Rana Sawalha | https://unsplash.com/photos/X7UR0BDz-UY |
| fino.jpg | Morgan Marinoni | https://unsplash.com/photos/_fFUW-ScTok |
| minnos.jpg | Kateryna Kamenieva | https://unsplash.com/photos/cBbd4KskaEQ |
| rex.jpg | Ash | https://unsplash.com/photos/v0_MCllHY9M |
| boo.jpg | Mariia Novikova | https://unsplash.com/photos/TQzvZJzIUMw |
| ciko.jpg | Noémi Macavei-Katócz | https://unsplash.com/photos/c7bUIRBqapA |
| pako.jpg | OSMAN ESPINOZA FRANCO | https://unsplash.com/photos/85XqQOx4dyg |
| seker.jpg | Lesya Tyutrina, Andrey Biyanov | https://unsplash.com/photos/HR5p3Ve6IkI |
| sosis.jpg | Max Bvp | https://unsplash.com/photos/ohwEkkpuNms |
| altin.jpg | fishy fishy | https://unsplash.com/photos/zxdn0PGevRo |
| kizil.jpg | Likhith Raj | https://unsplash.com/photos/GQG-cBPcmGs |
| pembe.jpg | Nellie Adamyan | https://unsplash.com/photos/zJD6UVVW_Ck |
| melek.jpg | Luan Fonseca | https://unsplash.com/photos/kWAxFa--bLU |
| cevizli.jpg | Juliya Sidorova | https://unsplash.com/photos/FOxMZK1VQS8 |
| misir.jpg | Zhaoli JIN | https://unsplash.com/photos/ntpFNTy_XzY |
| kara.jpg | Chandler Cruttenden | https://unsplash.com/photos/sqyMHTeaW84 |
| kabak.jpg | Smithsonian | https://unsplash.com/photos/bWNkJGOPPfE |
| diken.jpg | Nikola Tomašić | https://unsplash.com/photos/A8nXliyqWKs |
| tuylu.jpg | Nikolett Emmert | https://unsplash.com/photos/OXHJlKPrnBY |
| fisilti.jpg | Nikolett Emmert | https://unsplash.com/photos/WP8KvAMjCxs |
| cin.jpg | Nikolett Emmert | https://unsplash.com/photos/0wb-NhKMupk |
| misil.jpg | Nikolett Emmert | https://unsplash.com/photos/BLjhfYyfyIk |

## Yapay zekâ kullanımı

- **Kullanılan araç:** Claude (Anthropic)
- **Kullanım amaçları:** Proje konusunun belirlenmesi, PHP kodlarının oluşturulması, arayüz tasarımı (CSS), kodların açıklanması ve README hazırlanması
- **Örnek istem:** "İnternet Programcılığı dersi için PHP ile evcil hayvan sahiplendirme kayıt ve takip sistemi yap. Listeleme, POST ile ekleme, doğrulama, silme, GET ile filtreleme, sayaçlar ve htmlspecialchars olsun; veriler $_SESSION'da tutulsun."
- **Kendi katkım:**
  - Önerilen konular arasından projenin konusunu (evcil hayvan sahiplendirme) seçtim.
  - Arayüzün göze hitap etmesini, soft (pastel) renkler kullanılmasını ve sayfaların görsellerle daha dolu olmasını istedim; tasarımı bu yönde iki kez geliştirttim.
  - Projeyi kendi bilgisayarımda XAMPP üzerinde çalıştırıp kontrol ettim.
  - 2. aşamada barınak gibi çalışması için aşıların tek tek takibini, yaşın ay/yıl olarak girilmesini, görüşmeye gelenlerin ve sahiplenenlerin bilgilerinin tutulmasını istedim.
- **2. aşama örnek istem:** "Hayvan barınağı yapmak istiyorum adı da Pati Yuva olsun; aşıları her şeyi olsun, kaç ay-yıl olduğu, görüşenlerin ve sahiplenenlerin her şeyi içinde olsun." 
## Hayvan şeridi (kayan görünüm)

Sayfanın en üstündeki şerit 11 hayvan çeşidini (kedi, köpek, tavşan, kuş, balık, hamster, gine domuzu, kirpi, şinşilla, ferret, kaplumbağa) sonsuz döngüyle soldan sağa kaydırır. Fare şeridin üstüne gelince kayma durur, hayvan mutlu resmine geçer. Hayvana tıklayınca ilanlar o türe göre filtrelenir (GET). Kayma tamamen CSS ile (`@keyframes hs-kay`) yapılmıştır.

## Arayüz: geniş yerleşim, temalar ve koyu mod

- **Yerleşim:** İçerik ekranın tamamına yayılır; en üstte logo ve site adı, altında menü, onun altında kayan hayvan şeridi gelir (`ust_alan.php` bütün sayfalarda ortak kullanılır).
- **Renk temaları:** Beyaz, Lavanta, Bordo, Mor. Renkler `assets/style.css` başındaki CSS değişkenleriyle (`--t1`…`--t4`) tanımlıdır; tema `<html data-tema="...">` ile değişir.
- **Koyu / açık mod:** `<html data-mod="koyu">`. İlk açılışta bilgisayarın ayarı (`prefers-color-scheme`) kullanılır.
- **Seçimin saklanması:** `assets/tema.js` tercihi tarayıcının `localStorage` alanına yazar; `tema_head.php` sayfa çizilmeden önce geri yükler (yanıp sönme olmaz). Sunucu tarafında veri tutulmaz.
